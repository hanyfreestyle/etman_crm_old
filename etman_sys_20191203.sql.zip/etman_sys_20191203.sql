-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 25, 2023 at 11:26 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 5.6.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `etman_sys_20191203`
--

-- --------------------------------------------------------

--
-- Table structure for table `config`
--

CREATE TABLE `config` (
  `id` int(11) NOT NULL,
  `web_config` text COLLATE utf8_unicode_ci NOT NULL,
  `contact_config` text COLLATE utf8_unicode_ci NOT NULL,
  `register_config` text COLLATE utf8_unicode_ci NOT NULL,
  `active_config` text COLLATE utf8_unicode_ci NOT NULL,
  `forget_config` text COLLATE utf8_unicode_ci NOT NULL,
  `user_per` text COLLATE utf8_unicode_ci NOT NULL,
  `header_photo` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `photo_logo` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `photo_logo_en` varchar(200) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config`
--

INSERT INTO `config` (`id`, `web_config`, `contact_config`, `register_config`, `active_config`, `forget_config`, `user_per`, `header_photo`, `photo_logo`, `photo_logo_en`) VALUES
(1, 'a:23:{s:8:\"webstate\";s:1:\"1\";s:4:\"date\";i:1521064800;s:13:\"webstate_open\";s:1:\"0\";s:9:\"rightmode\";s:1:\"0\";s:4:\"name\";s:55:\"شركة الكرمة للإستثمار العقارى\";s:7:\"name_en\";s:39:\"Al Karma Real Estate Investment Company\";s:6:\"weburl\";s:27:\"https://www.bluerock-eg.com\";s:13:\"webstate_mass\";s:300:\"زوار موقعنا الكرام ... تلبية لرغبتكم الكريمة فى تطوير الموقع ... وليرتقى للمستوى العالمى فى تقديم كل ما يهمكم ... نحن بصدد تطوير الموقع كليا ليتناسب معكم ..\r\nادارة الموقع \";s:16:\"webstate_mass_en\";s:234:\"Dear visitors to our site ... To meet your desire in the development of the site ... and to rise to the world level in providing everything that interests you ... We are developing the site entirely to suit you ..\r\nSite Administration\";s:9:\"weblang_s\";s:1:\"1\";s:12:\"weblang_kind\";s:1:\"1\";s:10:\"currency_s\";s:1:\"1\";s:13:\"currency_kind\";s:1:\"0\";s:9:\"usd_value\";s:4:\"18.6\";s:12:\"addthis_cont\";s:1:\"1\";s:8:\"facebook\";s:40:\"https://www.facebook.com/blue.rock.egypt\";s:7:\"twitter\";s:35:\"https://twitter.com/Blue_Rock_Egypt\";s:7:\"youtube\";s:1:\"#\";s:11:\"google_plus\";s:49:\"https://plus.google.com/u/0/109452351285459927939\";s:9:\"instagram\";s:41:\"https://www.instagram.com/bluerock_egypt/\";s:8:\"linkedin\";s:79:\"https://www.linkedin.com/company/blue-rock-real-estate-marketing-and-investment\";s:10:\"google_api\";s:1:\"#\";s:2:\"B1\";s:10:\"تعديل\";}', 'a:17:{s:4:\"info\";s:881:\"<div class=\"Info\">\r\n	<p class=\"Ptitel P_Home\">\r\n		25 ش <span data-scayt_word=\"فوزي\" data-scaytid=\"1\">فوزي</span> <span data-scayt_word=\"معاذ\" data-scaytid=\"2\">معاذ</span></p>\r\n	<p>\r\n		برج <span data-scayt_word=\"صفوة\" data-scaytid=\"3\">صفوة</span> <span data-scayt_word=\"رجال\" data-scaytid=\"4\">رجال</span> <span data-scayt_word=\"الاعمال\" data-scaytid=\"5\">الاعمال</span></p>\r\n	<p>\r\n		<span data-scayt_word=\"الاسكندرية\" data-scaytid=\"6\">الاسكندرية</span> - مصر</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_phone\">\r\n		02 03 4257111</p>\r\n	<p>\r\n		02 03 4245352</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_mobile\">\r\n		02 010 02592358</p>\r\n	<p>\r\n		02 012 79417943</p>\r\n	<p>\r\n		02 012 72245899</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_Email\">\r\n		info@sama-inv.com</p>\r\n</div>\r\n\";s:7:\"info_en\";s:862:\"<div class=\"Info\">\r\n	<p class=\"Ptitel P_Home\">\r\n		25 ش <span data-scayt_word=\"فوزي\" data-scaytid=\"7\">فوزي</span> <span data-scayt_word=\"معاذ\" data-scaytid=\"8\">معاذ</span></p>\r\n	<p>\r\n		برج <span data-scayt_word=\"صفوة\" data-scaytid=\"9\">صفوة</span> <span data-scayt_word=\"رجال\" data-scaytid=\"10\">رجال</span> <span data-scayt_word=\"الاعمال\" data-scaytid=\"11\">الاعمال</span></p>\r\n	<p>\r\n		<span data-scayt_word=\"الاسكندرية\" data-scaytid=\"12\">الاسكندرية</span> - مصر</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_phone\">\r\n		002 03 4257111</p>\r\n	<p>\r\n		002 03 4245352</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_mobile\">\r\n		002 010 02592358</p>\r\n	<p>\r\n		002 012 79417943</p>\r\n</div>\r\n<div class=\"Info num\">\r\n	<p class=\"Ptitel P_Email\">\r\n		info[at]sama-inv.com</p>\r\n</div>\r\n\";s:9:\"googlemap\";s:1:\"1\";s:13:\"googlemaptype\";s:1:\"1\";s:8:\"latitude\";s:9:\"31.209801\";s:9:\"longitude\";s:9:\"29.936175\";s:8:\"email_id\";s:1:\"1\";s:7:\"mail_to\";s:17:\"info@sama-inv.com\";s:7:\"captcha\";s:1:\"0\";s:11:\"replaystate\";s:1:\"1\";s:12:\"mail_subject\";s:28:\"اتصال من الموقع\";s:14:\"replay_subject\";s:43:\"تم استلام رسالتك Sama-inv.com\";s:4:\"mass\";s:1326:\"<p style=\"text-align: right;\">\r\n	<span data-scayt_word=\"عميلنا\" data-scaytid=\"13\">عميلنا</span> <span data-scayt_word=\"العزيز\" data-scaytid=\"14\">العزيز</span> ..<br />\r\n	<br />\r\n	<span data-scayt_word=\"نشكرك\" data-scaytid=\"15\">نشكرك</span> على <span data-scayt_word=\"تواصلك\" data-scaytid=\"16\">تواصلك</span> <span data-scayt_word=\"معنا\" data-scaytid=\"17\">معنا</span> ..<br />\r\n	<br />\r\n	&nbsp;<span data-scayt_word=\"سيقوم\" data-scaytid=\"18\">سيقوم</span> <span data-scayt_word=\"المسئول\" data-scaytid=\"19\">المسئول</span> <span data-scayt_word=\"عن\" data-scaytid=\"20\">عن</span> <span data-scayt_word=\"تلقي\" data-scaytid=\"21\">تلقي</span> <span data-scayt_word=\"رسائلك\" data-scaytid=\"22\">رسائلك</span> <span data-scayt_word=\"بالرد\" data-scaytid=\"23\">بالرد</span> على <span data-scayt_word=\"رسالتك\" data-scaytid=\"24\">رسالتك</span> <span data-scayt_word=\"في\" data-scaytid=\"25\">في</span> <span data-scayt_word=\"اقرب\" data-scaytid=\"26\">اقرب</span> وقت ..<br />\r\n	<br />\r\n	<span data-scayt_word=\"تقبل\" data-scaytid=\"41\">تقبل</span> منا <span data-scayt_word=\"كل\" data-scaytid=\"42\">كل</span> <span data-scayt_word=\"الود\" data-scaytid=\"43\">الود</span><br />\r\n	&nbsp;</p>\r\n\";s:15:\"mail_subject_en\";s:28:\"اتصال من الموقع\";s:17:\"replay_subject_en\";s:43:\"تم استلام رسالتك Sama-inv.com\";s:7:\"mass_en\";s:1326:\"<p style=\"text-align: right;\">\r\n	<span data-scayt_word=\"عميلنا\" data-scaytid=\"27\">عميلنا</span> <span data-scayt_word=\"العزيز\" data-scaytid=\"28\">العزيز</span> ..<br />\r\n	<br />\r\n	<span data-scayt_word=\"نشكرك\" data-scaytid=\"29\">نشكرك</span> على <span data-scayt_word=\"تواصلك\" data-scaytid=\"30\">تواصلك</span> <span data-scayt_word=\"معنا\" data-scaytid=\"31\">معنا</span> ..<br />\r\n	<br />\r\n	&nbsp;<span data-scayt_word=\"سيقوم\" data-scaytid=\"32\">سيقوم</span> <span data-scayt_word=\"المسئول\" data-scaytid=\"33\">المسئول</span> <span data-scayt_word=\"عن\" data-scaytid=\"34\">عن</span> <span data-scayt_word=\"تلقي\" data-scaytid=\"35\">تلقي</span> <span data-scayt_word=\"رسائلك\" data-scaytid=\"36\">رسائلك</span> <span data-scayt_word=\"بالرد\" data-scaytid=\"37\">بالرد</span> على <span data-scayt_word=\"رسالتك\" data-scaytid=\"38\">رسالتك</span> <span data-scayt_word=\"في\" data-scaytid=\"39\">في</span> <span data-scayt_word=\"اقرب\" data-scaytid=\"40\">اقرب</span> وقت ..<br />\r\n	<br />\r\n	<span data-scayt_word=\"تقبل\" data-scaytid=\"44\">تقبل</span> منا <span data-scayt_word=\"كل\" data-scaytid=\"45\">كل</span> <span data-scayt_word=\"الود\" data-scaytid=\"46\">الود</span><br />\r\n	&nbsp;</p>\r\n\";s:2:\"B1\";s:10:\"تعديل\";}', 'a:22:{s:9:\"reg_state\";s:1:\"1\";s:10:\"reg_Ustate\";s:1:\"0\";s:12:\"reg_SendCode\";s:1:\"1\";s:8:\"reg_mass\";s:448:\"عذرا .. قامت شركة All-in-Call بوقف تسجيل عضويات الأعضاء الجدد على موقعها الإلكتروني فى الوقت الراهن وبشكل مؤقت .\r\nيمكنك استخدام نظام مراسلة الموقع لطلب تسجيل عضوية من خلال قائمة (إتصل بنا) .\r\nسيتم اعادة تشغيل تسجيل العضويات عاجلا .\r\n\r\nتقبلوا منا وافر التحية\";s:11:\"reg_mass_en\";s:195:\"Sorry the site manager clasps registration of members for the time being\r\nYou can use the site messaging system to request a membership registration\r\nWill be re-registered members soon\r\nGreetings\";s:11:\"req_captcha\";s:1:\"1\";s:10:\"req_forget\";s:1:\"1\";s:10:\"req_repeat\";s:1:\"1\";s:11:\"req_tream_v\";s:1:\"1\";s:11:\"req_country\";s:1:\"1\";s:11:\"req_address\";s:1:\"0\";s:9:\"req_ukind\";s:1:\"0\";s:13:\"req_barthdate\";s:1:\"0\";s:9:\"req_phone\";s:1:\"1\";s:10:\"req_mobile\";s:1:\"1\";s:9:\"req_photo\";s:1:\"0\";s:13:\"req_fromwhere\";s:1:\"1\";s:2:\"B1\";s:10:\"تعديل\";s:9:\"req_tream\";s:0:\"\";s:12:\"req_forget_q\";s:0:\"\";s:12:\"req_tream_en\";s:0:\"\";s:15:\"req_forget_q_en\";s:0:\"\";}', 'a:12:{s:8:\"sitename\";s:47:\"(All-in-Call) للإتصالات الدولية\";s:9:\"masstitel\";s:91:\"رسالة تفعيل عضويتك بموقع All-in-Call للإتصالات الدولية\";s:11:\"sitename_en\";s:37:\"(All-in-Call) For International Calls\";s:12:\"masstitel_en\";s:56:\"Activation message of your subscription @All-in-Call.com\";s:7:\"siteurl\";s:19:\"www.all-in-call.com\";s:10:\"send_count\";s:1:\"2\";s:8:\"wait_day\";s:2:\"60\";s:9:\"done_mass\";s:110:\"تم تفعيل عضويتك بنجاح ,\r\nيمكنك الآن تسجيل الدخول الى الموقع .\r\n\";s:9:\"wait_mass\";s:336:\"نرحب بتسجيل عضويتك مع (All-in-Call) للإتصالات الدولية ,\r\nتم إرسال رابط تفعيل العضوية على بريدك الإلكتروني المسجل لدينا ,\r\nإشتراكك لن يعمل إلا بعد تفعيله من خلال تتبع رابط التفعيل السابق ذكره .\r\n\";s:12:\"done_mass_en\";s:75:\"Your membership is successfully activated, \r\nYou can proceed to Login page.\";s:12:\"wait_mass_en\";s:300:\"نرحب بتسجيل عضويتك مع (All-in-Call) ,\r\nتم إرسال رابط تفعيل العضوية على بريدك الإلكتروني المسجل لدينا ,\r\nإشتراكك لن يعمل إلا بعد تفعيله من خلال تتبع رابط التفعيل السابق ذكره .\";s:2:\"B1\";s:10:\"تعديل\";}', 'a:7:{s:11:\"login_state\";s:1:\"1\";s:10:\"login_mass\";s:273:\"عذرا .. \r\nتم إغلاق تسجيل الدخول للأعضاء بسبب تطوير حالي سينتهي خلال عدة ساعات على الأكثر ..\r\nبرجاء إعادة محاولة تسجيل الدخول في وقت لاحق .. \r\nنشكر تعاونكم ..\";s:13:\"login_mass_en\";s:273:\"عذرا .. \r\nتم إغلاق تسجيل الدخول للأعضاء بسبب تطوير حالي سينتهي خلال عدة ساعات على الأكثر ..\r\nبرجاء إعادة محاولة تسجيل الدخول في وقت لاحق .. \r\nنشكر تعاونكم ..\";s:12:\"forget_state\";s:1:\"1\";s:13:\"remmber_state\";s:1:\"1\";s:14:\"forget_captcha\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}', 'a:10:{s:4:\"mass\";s:28:\"يسبسيبسيبسيبسي\";s:7:\"article\";s:1:\"1\";s:5:\"photo\";s:1:\"1\";s:5:\"video\";s:1:\"1\";s:3:\"faq\";s:1:\"1\";s:8:\"lastnews\";s:1:\"1\";s:4:\"poll\";s:1:\"1\";s:6:\"writer\";s:1:\"1\";s:5:\"pages\";s:1:\"1\";s:2:\"B1\";s:10:\"تعديل\";}', 'odyssia_03.jpg', 'odyssia_07.jpg', 'odyssia_01.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `config_cat`
--

CREATE TABLE `config_cat` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `des` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config_cat`
--

INSERT INTO `config_cat` (`id`, `cat_id`, `des`) VALUES
(1, 'adminmneu_config', 'a:9:{s:11:\"perpage_cat\";s:2:\"30\";s:12:\"order_by_cat\";s:1:\"2\";s:15:\"catadd_redirect\";s:1:\"1\";s:16:\"catedit_redirect\";s:1:\"2\";s:12:\"perpage_unit\";s:2:\"20\";s:13:\"order_by_unit\";s:1:\"2\";s:16:\"unitadd_redirect\";s:1:\"1\";s:17:\"unitedit_redirect\";s:1:\"2\";s:2:\"B1\";s:10:\"تعديل\";}'),
(2, 'adminlang_config', 'a:11:{s:11:\"perpage_cat\";i:60;s:12:\"order_by_cat\";s:1:\"2\";s:15:\"catadd_redirect\";s:1:\"2\";s:16:\"catedit_redirect\";s:1:\"1\";s:12:\"perpage_unit\";s:2:\"30\";s:13:\"order_by_unit\";s:1:\"1\";s:16:\"unitadd_redirect\";s:1:\"1\";s:17:\"unitedit_redirect\";s:1:\"3\";s:10:\"deletetype\";s:1:\"1\";s:9:\"tab_state\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}'),
(3, 'weblang_config', 'a:11:{s:11:\"perpage_cat\";s:2:\"15\";s:12:\"order_by_cat\";s:1:\"2\";s:15:\"catadd_redirect\";s:1:\"1\";s:16:\"catedit_redirect\";s:1:\"1\";s:12:\"perpage_unit\";s:2:\"20\";s:13:\"order_by_unit\";s:1:\"2\";s:16:\"unitadd_redirect\";s:1:\"1\";s:17:\"unitedit_redirect\";s:1:\"2\";s:10:\"deletetype\";s:1:\"0\";s:9:\"tab_state\";s:1:\"0\";s:2:\"B1\";s:4:\"Edit\";}'),
(6, 'google_config', 'a:17:{s:12:\"perpage_unit\";i:30;s:13:\"order_by_unit\";s:1:\"2\";s:16:\"unitadd_redirect\";s:1:\"1\";s:17:\"unitedit_redirect\";s:1:\"1\";s:8:\"resize_p\";s:1:\"6\";s:8:\"resize_t\";s:1:\"6\";s:5:\"color\";s:7:\"#FFFFFF\";s:5:\"width\";s:3:\"300\";s:6:\"height\";s:3:\"450\";s:7:\"width_t\";s:3:\"150\";s:8:\"height_t\";s:3:\"220\";s:10:\"file_width\";s:4:\"1024\";s:11:\"file_height\";s:4:\"1024\";s:9:\"file_size\";s:3:\"500\";s:10:\"deletetype\";s:1:\"0\";s:9:\"tab_state\";s:1:\"0\";s:2:\"B1\";s:4:\"Edit\";}'),
(25, 'project_config', 'a:8:{s:12:\"perpage_unit\";i:20;s:13:\"order_by_unit\";s:1:\"1\";s:16:\"unitadd_redirect\";s:1:\"2\";s:17:\"unitedit_redirect\";s:1:\"1\";s:10:\"deletetype\";s:1:\"0\";s:9:\"tab_state\";s:1:\"0\";s:8:\"but_name\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}'),
(28, 'contract_config', 'a:7:{s:12:\"perpage_unit\";s:2:\"20\";s:13:\"order_by_unit\";s:1:\"2\";s:16:\"unitadd_redirect\";s:1:\"2\";s:17:\"unitedit_redirect\";s:1:\"1\";s:10:\"deletetype\";s:1:\"0\";s:9:\"tab_state\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}'),
(29, 'customer_config', 'a:15:{s:12:\"perpage_cust\";s:2:\"20\";s:10:\"order_cust\";s:1:\"1\";s:14:\"datatabel_cust\";s:1:\"1\";s:12:\"datamax_cust\";s:3:\"500\";s:11:\"filter_cont\";s:1:\"0\";s:10:\"c_lead_cat\";s:1:\"1\";s:13:\"c_ticket_cust\";s:1:\"1\";s:5:\"c_jop\";s:1:\"1\";s:6:\"c_kind\";s:1:\"1\";s:8:\"c_social\";s:1:\"1\";s:6:\"c_live\";s:1:\"1\";s:11:\"nationality\";s:1:\"1\";s:12:\"country_live\";s:1:\"1\";s:6:\"c_city\";s:1:\"1\";s:2:\"B1\";s:10:\"تعديل\";}'),
(30, 'managedate_config', 'a:4:{s:12:\"perpage_unit\";s:2:\"25\";s:13:\"order_by_unit\";s:1:\"1\";s:9:\"datatabel\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}'),
(31, 'custserv_config', 'a:6:{s:15:\"perpage_custsrv\";s:3:\"100\";s:13:\"order_custsrv\";s:1:\"1\";s:17:\"datatabel_custsrv\";s:1:\"1\";s:15:\"datamax_custsrv\";s:4:\"1500\";s:13:\"report_period\";s:1:\"2\";s:2:\"B1\";s:10:\"تعديل\";}'),
(32, 'hotline_config', 'a:5:{s:15:\"perpage_hotline\";s:2:\"10\";s:13:\"order_hotline\";s:1:\"1\";s:17:\"datatabel_hotline\";s:1:\"0\";s:15:\"datamax_hotline\";s:3:\"500\";s:2:\"B1\";s:10:\"تعديل\";}'),
(33, 'leads_config', 'a:14:{s:13:\"perpage_leads\";s:3:\"120\";s:11:\"order_leads\";s:1:\"2\";s:15:\"datatabel_leads\";s:1:\"1\";s:13:\"datamax_leads\";s:3:\"500\";s:9:\"data_type\";s:1:\"1\";s:11:\"ajex_delete\";s:1:\"0\";s:16:\"perpage_facebook\";s:2:\"10\";s:11:\"import_name\";s:1:\"B\";s:12:\"import_email\";s:1:\"E\";s:13:\"import_mobile\";s:1:\"C\";s:15:\"import_mobile_2\";s:1:\"F\";s:10:\"import_jop\";s:1:\"D\";s:11:\"import_area\";s:1:\"A\";s:2:\"B1\";s:10:\"تعديل\";}'),
(34, 'salesdep_config', 'a:10:{s:13:\"perpage_slaes\";s:2:\"10\";s:11:\"order_slaes\";s:1:\"1\";s:15:\"datatabel_slaes\";s:1:\"1\";s:13:\"datamax_slaes\";s:4:\"1200\";s:13:\"report_period\";s:1:\"2\";s:16:\"perpage_transfer\";s:2:\"10\";s:14:\"order_transfer\";s:1:\"1\";s:18:\"datatabel_transfer\";s:1:\"1\";s:16:\"datamax_transfer\";s:3:\"500\";s:2:\"B1\";s:10:\"تعديل\";}'),
(35, 'report_config', 'a:20:{s:16:\"cust_chart_count\";s:2:\"10\";s:9:\"sales_cat\";s:1:\"2\";s:13:\"report_period\";s:1:\"2\";s:11:\"filter_cont\";s:1:\"0\";s:9:\"datatabel\";s:1:\"0\";s:13:\"c_ticket_cust\";s:1:\"1\";s:10:\"c_lead_cat\";s:1:\"1\";s:6:\"c_city\";s:1:\"1\";s:11:\"nationality\";s:1:\"1\";s:6:\"c_live\";s:1:\"1\";s:12:\"country_live\";s:1:\"1\";s:5:\"c_jop\";s:1:\"1\";s:6:\"c_kind\";s:1:\"1\";s:8:\"c_social\";s:1:\"1\";s:8:\"c_cashid\";s:1:\"1\";s:8:\"cdate_id\";s:1:\"1\";s:9:\"unit_area\";s:1:\"0\";s:9:\"unit_type\";s:1:\"1\";s:8:\"pro_area\";s:1:\"1\";s:2:\"B1\";s:10:\"تعديل\";}'),
(36, 'lppage_config', 'a:22:{s:12:\"perpage_unit\";s:2:\"25\";s:13:\"order_by_unit\";s:1:\"1\";s:9:\"datatabel\";s:1:\"0\";s:11:\"group_photo\";s:1:\"1\";s:8:\"resize_p\";s:1:\"6\";s:8:\"resize_t\";s:1:\"6\";s:5:\"color\";s:7:\"#FFFFFF\";s:5:\"width\";s:3:\"250\";s:6:\"height\";s:3:\"250\";s:7:\"width_t\";s:3:\"500\";s:8:\"height_t\";s:3:\"500\";s:11:\"ph_resize_p\";s:1:\"1\";s:11:\"ph_resize_t\";s:1:\"1\";s:8:\"ph_color\";s:7:\"#CC0099\";s:8:\"ph_width\";s:3:\"640\";s:9:\"ph_height\";s:3:\"420\";s:10:\"ph_width_t\";s:3:\"400\";s:11:\"ph_height_t\";s:3:\"300\";s:10:\"file_width\";s:5:\"15000\";s:11:\"file_height\";s:5:\"15000\";s:9:\"file_size\";s:5:\"15000\";s:2:\"B1\";s:10:\"تعديل\";}'),
(37, 'sendsms_config', 'a:20:{s:12:\"perpage_unit\";s:2:\"10\";s:13:\"order_by_unit\";s:1:\"1\";s:13:\"report_period\";s:1:\"2\";s:8:\"username\";s:6:\"diar11\";s:8:\"password\";s:8:\"Sms12345\";s:10:\"sendername\";s:4:\"DIAR\";s:8:\"en_count\";s:1:\"1\";s:8:\"ar_count\";s:1:\"1\";s:9:\"datatabel\";s:1:\"0\";s:11:\"filter_cont\";s:1:\"0\";s:10:\"c_lead_cat\";s:1:\"1\";s:13:\"c_ticket_cust\";s:1:\"1\";s:5:\"c_jop\";s:1:\"1\";s:6:\"c_kind\";s:1:\"1\";s:8:\"c_social\";s:1:\"1\";s:6:\"c_live\";s:1:\"1\";s:11:\"nationality\";s:1:\"1\";s:12:\"country_live\";s:1:\"1\";s:6:\"c_city\";s:1:\"1\";s:2:\"B1\";s:10:\"تعديل\";}'),
(38, 'closedticket_config', 'a:5:{s:20:\"perpage_closedticket\";s:2:\"10\";s:18:\"order_closedticket\";s:1:\"1\";s:22:\"datatabel_closedticket\";s:1:\"1\";s:20:\"datamax_closedticket\";s:4:\"1500\";s:2:\"B1\";s:10:\"تعديل\";}'),
(39, 'salesfollow_config', 'a:5:{s:15:\"perpage_custsrv\";s:3:\"100\";s:13:\"order_custsrv\";s:1:\"1\";s:17:\"datatabel_custsrv\";s:1:\"1\";s:15:\"datamax_custsrv\";s:4:\"1850\";s:2:\"B1\";s:10:\"تعديل\";}'),
(40, 'config_config', 'a:9:{s:14:\"perpage_banner\";s:2:\"10\";s:12:\"order_banner\";s:1:\"2\";s:15:\"defphoto_banner\";s:1:\"5\";s:16:\"datatabel_banner\";s:1:\"0\";s:17:\"perpage_developer\";s:2:\"10\";s:15:\"order_developer\";s:1:\"1\";s:18:\"defphoto_developer\";s:1:\"6\";s:19:\"datatabel_developer\";s:1:\"0\";s:2:\"B1\";s:4:\"Edit\";}'),
(41, 'permission_config', 'a:15:{s:17:\"perpage_catconfig\";s:2:\"10\";s:15:\"order_catconfig\";s:1:\"1\";s:19:\"datatabel_catconfig\";s:1:\"0\";s:17:\"datamax_catconfig\";s:3:\"100\";s:19:\"perpage_regulations\";s:2:\"20\";s:17:\"order_regulations\";s:1:\"1\";s:21:\"datatabel_regulations\";s:1:\"0\";s:19:\"datamax_regulations\";s:2:\"20\";s:18:\"perpage_userconfig\";s:2:\"20\";s:16:\"order_userconfig\";s:1:\"1\";s:20:\"datatabel_userconfig\";s:1:\"0\";s:18:\"datamax_userconfig\";s:3:\"100\";s:21:\"activemode_userconfig\";s:1:\"0\";s:14:\"userphoto_view\";s:1:\"0\";s:2:\"B1\";s:10:\"تعديل\";}');

-- --------------------------------------------------------

--
-- Table structure for table `config_data`
--

CREATE TABLE `config_data` (
  `id` int(11) NOT NULL,
  `s_id` int(11) DEFAULT '0',
  `cat_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `old_id` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config_data`
--

INSERT INTO `config_data` (`id`, `s_id`, `cat_id`, `name`, `name_en`, `old_id`, `count`, `state`) VALUES
(1, 0, 'f_kind', 'ذكر', 'Male', 1, 0, 1),
(2, 0, 'f_kind', 'انثى', 'Female', 2, 0, 1),
(3, 0, 'f_social', 'متزوج', 'Married', 1, 0, 1),
(4, 0, 'f_social', 'اعزب', 'Single', 2, 0, 1),
(5, 0, 'f_jop', 'مهندس', 'Engineer', 1, 0, 1),
(6, 0, 'f_jop', 'طبيب بشري', 'Human doctor', 2, 0, 1),
(7, 0, 'f_jop', 'محاسب', 'Accountant', 3, 0, 1),
(8, 0, 'f_jop', 'ظابط شرطة', 'Police officer', 4, 0, 1),
(9, 0, 'f_jop', 'محلل نظم و معلومات', 'Systems and Information Analyst', 5, 0, 1),
(10, 0, 'f_jop', 'طيار مدني', 'Civilian pilot', 6, 0, 1),
(11, 0, 'f_jop', 'مضيف جوي', 'Air host', 7, 0, 1),
(12, 0, 'f_jop', 'مدرس', 'Teacher', 8, 0, 1),
(13, 0, 'f_jop', 'صيدلي', 'Pharmacist', 9, 0, 1),
(14, 0, 'f_jop', 'دكتور جامعة', 'University doctor', 10, 0, 1),
(15, 0, 'f_jop', 'موارد بشرية', 'Human resources', 11, 0, 1),
(16, 0, 'f_jop', 'أعمال حرة', 'free businees', 12, 0, 1),
(17, 0, 'f_jop', 'ربة منزل', 'House wife', 13, 0, 1),
(18, 0, 'f_jop', 'طالب', 'Student', 14, 0, 1),
(19, 0, 'f_jop', 'ملحق دبلوماسي', 'Diplomatic Annex', 15, 0, 1),
(20, 0, 'f_jop', 'مذيع - مذيعة', 'Announcer - broadcaster', 16, 0, 1),
(21, 0, 'f_jop', 'محامي', 'Lawyer', 17, 0, 1),
(22, 0, 'f_jop', 'مستشار', 'مستشار', 18, 0, 1),
(23, 0, 'f_jop', 'صحفي', 'Journalist', 19, 0, 1),
(24, 0, 'f_jop', 'مسئول مبيعات', 'Sales Officer', 20, 0, 1),
(25, 0, 'f_jop', 'موظف بنك', 'Banker', 21, 0, 1),
(26, 0, 'f_jop', 'موظف في شركة طيران', 'Employee in an airline', 22, 0, 1),
(27, 0, 'f_jop', 'موظف في شركة اتصالات', 'موظف في شركة اتصالات', 23, 0, 1),
(28, 0, 'f_jop', 'ممثل', 'ممثل', 24, 0, 1),
(29, 0, 'f_jop', 'موظف حكومي', 'government employee', 25, 0, 1),
(30, 0, 'f_jop', 'رجل اعمال', 'رجل اعمال', 26, 0, 1),
(31, 0, 'f_jop', 'سياحة وفنادق', 'سياحة وفنادق', 27, 0, 1),
(32, 0, 'f_jop', 'ضابط قوات مسلحة', 'ضابط قوات مسلحة', 28, 0, 1),
(33, 0, 'f_jop', 'موظف في شركة بترول', 'موظف في شركة بترول', 29, 0, 1),
(34, 0, 'f_jop', 'بكالوريس ادارة أعمال', 'بكالوريس ادارة أعمال', 30, 0, 1),
(35, 0, 'f_jop', 'طبيب أسنان', 'dentist', 31, 0, 1),
(36, 0, 'f_jop', 'حاصل علي بكالوريس / ليسانس', 'حاصل علي بكالوريس / ليسانس', 32, 0, 1),
(37, 0, 'f_jop', 'غير محدد', 'undefined', 33, 0, 1),
(38, 0, 'f_jop', 'تاجر', 'تاجر', 34, 0, 1),
(39, 0, 'f_jop', 'دكتور', 'Doctor', 35, 0, 1),
(40, 0, 'f_jop', 'ظابط جيش', 'ظابط جيش', 38, 0, 1),
(41, 0, 'f_jop', 'موظف ضرائب', 'موظف ضرائب', 39, 0, 1),
(42, 0, 'f_jop', 'سكرتير تنفيذي', 'Executive Secretary', 40, 0, 1),
(43, 0, 'f_jop', 'مهندس زراعي', 'Agriculture Engineer', 41, 0, 1),
(44, 0, 'f_jop', 'مدير عمليات', 'Operations Manager', 42, 0, 1),
(45, 0, 'f_jop', 'مدير ادارة', 'مدير ادارة', 43, 0, 1),
(46, 0, 'f_jop', 'جزار', 'butcher', 44, 0, 1),
(47, 0, 'f_jop', 'استيراد و تصدير', 'Import and Export', 45, 0, 1),
(48, 0, 'f_jop', 'ظابط ( غير محدد )', 'Officer', 46, 0, 1),
(49, 0, 'f_jop', 'مساح - رسام', 'مساح - رسام', 47, 0, 1),
(50, 0, 'f_jop', 'خريج كلية فنون', 'خريج كلية فنون', 48, 0, 1),
(51, 0, 'f_jop', 'موظف في فندق', 'موظف في فندق', 49, 0, 1),
(52, 0, 'f_jop', 'موظف في التلفزيون', 'موظف في التلفزيون', 50, 0, 1),
(53, 0, 'f_jop', 'مدير عام', 'مدير عام', 51, 0, 1),
(54, 0, 'f_jop', 'حلاق - Hair stylist', 'حلاق - Hair stylist', 52, 0, 1),
(55, 0, 'f_jop', 'علاقات عامة', 'public relations', 53, 0, 1),
(56, 0, 'f_jop', 'موظف بشركة عقارات', 'موظف بشركة عقارات', 54, 0, 1),
(57, 0, 'f_jop', 'تسويق', 'تسويق', 55, 0, 1),
(58, 0, 'f_jop', 'سائق', 'Driver', 56, 0, 1),
(90, 0, 'f_area', '100 الى 150 م', '100 الى 150 م', 1, 0, 1),
(91, 0, 'f_area', '150 الى 200 م', '150 الى 200 م', 2, 0, 1),
(92, 0, 'f_area', '200 الى 250 م', '200 الى 250 م', 3, 0, 1),
(93, 0, 'f_area', 'غير محدد', 'غير محدد', 4, 0, 1),
(94, 0, 'f_area', 'من 80 : 120 م', 'من 80 : 120 م', 5, 0, 1),
(95, 0, 'f_cash', 'كاش', 'Cash', 1, 0, 1),
(96, 0, 'f_cash', 'تقسيط', 'Installment', 2, 0, 1),
(97, 0, 'f_cash', 'تقسيط او كاش', 'Cash or Installment', 3, 0, 1),
(98, 0, 'f_cash', 'تمويل عقاري', 'تمويل عقاري', 4, 0, 1),
(99, 0, 'f_date', 'استلام فورى', 'Receive immediately', 1, 0, 1),
(100, 0, 'f_date', 'استلام بعد 6 اشهر', 'Receipt after 6 months', 2, 0, 1),
(101, 0, 'f_date', 'استلام بعد سنة', '1 Year', 3, 0, 1),
(102, 0, 'f_date', 'استلام بعد سنتين', '2 Years', 4, 0, 1),
(103, 0, 'f_date', 'استلام 3 سنوات', '3 Years', 5, 0, 1),
(104, 0, 'f_date', 'استلام 4 سنوات', '4 Years', 6, 0, 1),
(105, 0, 'f_date', 'غير محدد', 'غير محدد', 7, 0, 1),
(106, 0, 'f_unit_type', 'أرضي', 'أرضي', 1, 0, 1),
(107, 0, 'f_unit_type', 'متكرر', 'متكرر', 2, 0, 1),
(108, 0, 'f_unit_type', 'دوبلكس', 'دوبلكس', 3, 0, 1),
(109, 0, 'f_unit_type', 'بنتهاوس', 'Benthouse', 4, 0, 1),
(110, 0, 'f_unit_type', 'توين هاوس', 'Twinhouse', 5, 0, 1),
(111, 0, 'f_unit_type', 'رووف', 'Roof', 6, 0, 1),
(112, 0, 'f_bestcall', 'مكالمة هاتفية', 'Phone Call', 1, 0, 1),
(113, 0, 'f_bestcall', 'رسالة نصية', 'SMS Message', 2, 0, 1),
(114, 0, 'f_bestcall', 'رسالة واتساب', 'Whatsapp Message', 3, 0, 1),
(115, 0, 'f_bestcall', 'ايميل', 'Email', 4, 0, 1),
(116, 0, 'f_call_time', '9 AM', '9 AM', 1, 0, 1),
(117, 0, 'f_call_time', '10 AM', '10 AM', 2, 0, 1),
(118, 0, 'f_call_time', '11 AM', '11 AM', 3, 0, 1),
(119, 0, 'f_call_time', '12', '12', 4, 0, 1),
(120, 0, 'f_call_time', '1 PM', '1 PM', 5, 0, 1),
(121, 0, 'f_call_time', '2 PM', '2 PM', 6, 0, 1),
(122, 0, 'f_call_time', '3 PM', '3 PM', 7, 0, 1),
(123, 0, 'f_call_time', 'صباحاً', 'Morning', 8, 0, 1),
(124, 0, 'f_call_time', 'ظهراً', 'ظهراً', 9, 0, 1),
(125, 0, 'f_call_time', 'عصراً', 'عصراً', 10, 0, 1),
(126, 0, 'f_call_time', 'مساءً', 'Night', 11, 0, 1),
(127, 0, 'f_call_time', 'غير محدد', 'غير محدد', 12, 0, 1),
(128, 0, 'f_follow_type', 'مكالمة ', 'Phone Call', 1, 0, 1),
(129, 0, 'f_follow_type', 'رسالة واتساب', 'رسالة واتساب', 2, 0, 1),
(130, 0, 'f_follow_type', 'رسالة نصية ', 'رسالة نصية ', 3, 0, 1),
(131, 0, 'f_follow_type', 'إيميل ', 'إيميل ', 4, 0, 1),
(132, 0, 'f_follow_type', 'زيارة الشركة ', 'زيارة الشركة ', 5, 0, 1),
(133, 0, 'f_follow_type', 'اجتماع للحجز', 'اجتماع للحجز', 6, 0, 1),
(137, 0, 'f_reason_t', 'متابعة عادية', 'Just follow up', 0, 0, 1),
(143, 0, 'f_jop', 'استشاري', 'Consultant', 0, 0, 1),
(147, 0, 'f_jop', 'مُبرمج كمبيوتر', 'مُبرمج كمبيوتر', 0, 0, 1),
(148, 0, 'f_jop', 'موظف بمصنع', 'موظف بمصنع', 0, 0, 1),
(149, 0, 'f_jop', 'موظف بشركة مقاولات', 'موظف بشركة مقاولات', 0, 0, 1),
(150, 0, 'f_jop', 'موظف بشركة أدوية', 'موظف بشركة أدوية', 0, 0, 1),
(155, 0, 'f_jop', 'مصمم أزياء', 'Fashion Designer', 0, 0, 1),
(157, 0, 'f_jop', 'قبطان بحري', 'Commander', 0, 0, 1),
(160, 0, 'f_jop', 'خدمة عملاء', 'customer service', 0, 0, 1),
(169, 0, 'f_jop', 'شيف', 'Chief', 0, 0, 1),
(178, 0, 'f_jop', 'مترجم', 'translator', 0, 0, 1),
(179, 0, 'f_jop', 'مدير فرع', 'branch manager', 0, 0, 1),
(180, 0, 'f_jop', 'مدير العقود والمشتريات', 'مدير العقود والمشتريات', 0, 0, 1),
(181, 0, 'f_jop', 'مدير مالي', 'financial manager', 0, 0, 1),
(182, 0, 'f_jop', 'مندوب طبي', 'medical representative', 0, 0, 1),
(185, 0, 'f_jop', 'مدير مشروع', 'project manager', 0, 0, 1),
(186, 0, 'f_jop', 'رئيس مجلس ادارة', 'رئيس مجلس ادارة', 0, 0, 1),
(188, 0, 'f_jop', 'كاتب/شاعر', 'writer/poet', 0, 0, 1),
(209, 0, 'f_area', '250 : 500', '250 : 500', 0, 0, 1),
(212, 0, 'f_social', 'مُطلق', 'مُطلق', 0, 0, 1),
(213, 0, 'f_social', 'أرمل', 'أرمل', 0, 0, 1),
(230, 0, 'f_reason_t', 'طلب بيع', 'طلب بيع', 0, 0, 1),
(237, 0, 'f_reason_t', 'طلب تعديل', 'طلب تعديل', 0, 0, 1),
(269, 0, 'f_jop', 'مدير المبيعات', 'sales manager', 0, 0, 1),
(270, 0, 'f_jop', 'مدير التسويق', 'marketing manager', 0, 0, 1),
(273, 0, 'f_jop', 'طبيب بيطري', 'طبيب بيطري', 0, 0, 1),
(274, 0, 'f_jop', 'مدير المشتريات', 'مدير المشتريات', 0, 0, 1),
(285, 0, 'f_lead_cat', 'غير محدد', 'غير محدد', 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `config_meta`
--

CREATE TABLE `config_meta` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `g_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8_unicode_ci,
  `g_key` text COLLATE utf8_unicode_ci,
  `g_name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_des_en` text COLLATE utf8_unicode_ci,
  `g_key_en` text COLLATE utf8_unicode_ci,
  `postion` int(11) DEFAULT '0',
  `header_h3` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_h6` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_h3_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_h6_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `header_photo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `banner_catid` int(11) DEFAULT '0',
  `banner_id` int(11) DEFAULT '0',
  `banner_state` int(11) DEFAULT '0',
  `photo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_t` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config_meta`
--

INSERT INTO `config_meta` (`id`, `cat_id`, `g_name`, `g_des`, `g_key`, `g_name_en`, `g_des_en`, `g_key_en`, `postion`, `header_h3`, `header_h6`, `header_h3_en`, `header_h6_en`, `header_photo`, `banner_catid`, `banner_id`, `banner_state`, `photo`, `photo_t`, `state`) VALUES
(1, 0, 'Etman Group', 'تابع معنا علي الصفحة الرئيسية لشركة سما للاستثمار والتنمية العقارية كل ماهو جديد عن الشركة وأحدث المشروعات بأرقي أحياء الأسكندريه', 'شركة سما للاستثمار والتنمية العقارية , شركة استثمار عقارى بالاسكندرية  , شركات عقارية بالاسكندرية  , استثمار عقارى مصر  , شركات التمويل العقارى بالاسكندرية  , ابراج العقارية للاستثمار والتنمية , شقق تمليك بالاسكندرية  , شقق للبيع بالاسكندرية', 'Etman Group', 'About Us written overview of the site here write here write about us about us here write here write about us about us here write here', 'Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged , Tagged  ,Tagged , Tagged ,asda sad,sad', 0, '', '', '', '', '', 3, 0, 0, NULL, NULL, 0),
(2, 0, 'Etman Group', 'نتشرف بخدمة عملائنا .. اتصل بنا الان واحصل على كافة التفاصيل الخاصة بمشروعاتنا المتوفرة بارقى احياء عروس البحر الابيض المتوسط الاسكندرية', 'اتصل بنا , شركة ابراج العقارية  , شركة ابراج للاستثمار والتنمية العقارية  , شركة استثمار عقارى بالاسكندرية  , شركات عقارية بالاسكندرية  , شركات التسويق العقاري  , استثمار عقارى الاسكندرية  , افضل استثمار  , اعلانات شقق للبيع  , اعلانات بيع شقق ', 'Etman Group', 'We are honored to serve our clients .. Contact us now and get all the details of the project hotline 19791', 'We are honored to serve our clients .. Contact us now and get all the details of the project hotline 19791We are honored to serve our clients .. Contact us now and get all the details of the project hotline 19791', 0, '', '', 'Contact Us', 'We are honored to serve our clients .. Contact us now and get all the details of the project hotline 19791', 'untitled_2.jpg', 0, 0, 0, NULL, NULL, 0),
(5, 0, 'Etman Group', 'تابع معنا اخر الاخبار والعروض المقدمة من شركة سما للأستثمار والتنمية العقارية ومراحل تنفيذ مشروعاتنا المتوفرة فى ارقى احياء الاسكندرية', 'اخر الاخبار  , اعلانات عقارات مصر  , اعلانات بيع عقارات  , اعلان شقق للبيع  , اعلان بيع شقق  , شركة استثمار عقارى بالاسكندرية  , شركات عقارية بالاسكندرية  , شركات التسويق العقاري  , شركة استثمار عقارى بمصر  , ابراج للاستثمار والتنمية العقارية , اخبار', 'Etman Group', 'تابع معنا اخر الاخبار والعروض المقدمة من شركة سما للأستثمار والتنمية العقارية ومراحل تنفيذ مشروعاتنا المتوفرة فى ارقى احياء الاسكندرية', 'اخر الاخبار  , اعلانات عقارات مصر  , اعلانات بيع عقارات  , اعلان شقق للبيع  , اعلان بيع شقق  , شركة استثمار عقارى بالاسكندرية  , شركات عقارية بالاسكندرية  , شركات التسويق العقاري  , شركة استثمار عقارى بمصر  , ابراج للاستثمار والتنمية العقارية , اخبار', 0, '', '', 'Last News', 'Continued us the latest project news and advertisements and special offers provided to our customers', 'con_001.jpg', 0, 0, 0, NULL, NULL, 0),
(10, 0, 'Etman Group', 'تابع معنا اخر الصور الحية ومراحل التنفيذ التى يتم اضافتها لمشروعاتنا المتوفرة بارقى احياء عروس البحر الابيض المتوسط الاسكندرية', 'البوم الصور  , شركة استثمار عقارى بالاسكندرية  , افضل استثمار  , استثمار عقارى الاسكندرية  , شركة ابراج العقارية  , شركة ابراج الاسكندرية  , ابراج العقارية الاسكندرية  , شقق تمليك بالتقسيط السيوف  , شقق تمليك بالتقسيط سيدى بشر ', 'Etman Group', 'Follow us live images that are added to the project in order to follow up with us stages of development of the project and what has been accomplished', ' Kambond Kamel facilities and services, real estate investment company in Alexandria, Apartments for sale in Alexandria Agamy, residential apartments and Msifa in Ajmi', 0, '', '', '', '', '', 0, 0, 0, NULL, NULL, 0),
(11, 0, 'Etman Group', 'تابع معنا اخر الفيديوهات التى يتم اضافتها لمشروعتنا لكى تتابع معنا مراحل التنفيذ وما تم انجازة على ارض الواقع لارقى مشروعات سكنية بالاسكندرية', 'شركة استثمار عقارى بالاسكندرية , البوم الفيديو  , شركات الاستثمار العقارى بالاسكندرية  , استثمار عقارى الاسكندرية  , شركات عقارية بمصر  , ابراج العقارية  , شركة سما العقارية  , شركة سما للاستثمار والتنمية العقارية  , سوق الاسكندرية العقارى , سما اسكندريه', 'Etman Group', 'تابع معنا اخر الفيديوهات التى يتم اضافتها لمشروعتنا لكى تتابع معنا مراحل التنفيذ وما تم انجازة على ارض الواقع لارقى مشروعات سكنية بالاسكندرية', 'Video Album  , Real estate investment company   , Real estate investment companies   , Real estate investment company in Egypt   , Investment substance   , Apartments for sale in Alexandria   , Full compound facilities in Alexandria  ', 0, '', '', '', '', '', 0, 0, 0, NULL, NULL, 0),
(12, 0, 'Etman Group', 'تابع معنا الصفحات الفرعية علي الموقع الخاص بشركتنا شركة سما للاستثمار والتنمية العقاريه بالاسكندريه والتي تشمل كل مايخص الشركة والمشاريع', 'الصفحات الفرعية , شقق تمليك بالاسكندرية تشطيب سوبر لوكس  , تسويق عقارات  , الاعلان عن شقق للبيع  , شركات الاستثمار العقارى بالاسكندرية  , شركة سما العقاريه  , سوق الاسكندرية العقارى  , شركة سما للإستثمار والتنمية العقارية  , اعلانات بيع شقق ', 'Etman Group', 'تابع معنا الصفحات الفرعية علي الموقع الخاص بشركتنا شركة سما للاستثمار والتنمية العقاريه بالاسكندريه والتي تشمل كل مايخص الشركة والمشاريع', 'الصفحات الفرعية , شقق تمليك بالاسكندرية تشطيب سوبر لوكس  , تسويق عقارات  , الاعلان عن شقق للبيع  , شركات الاستثمار العقارى بالاسكندرية  , شركة سما العقاريه  , سوق الاسكندرية العقارى  , شركة سما للإستثمار والتنمية العقارية  , اعلانات بيع شقق ', 0, '', '', '', '', '', 0, 0, 0, NULL, NULL, 0),
(18, 0, 'Etman Group', 'المشروعات الحالية لشركة سما العقارية مشروعات سكنية ومصيفية بارقى احياء الاسكندرية شركة سما للاستثمار والتنمية العقاريه', 'سما العقارية للاستثمار والتنمية , المشروعات الحالية , الاسكندرية , شقق تمليك بالتقسيط ميامي , شقق تمليك بالتقسيط ستانلى , شقق تمليك بالتقسيط زيزينيا , شقق تمليك بالتقسيط جليم , شقق تمليك بالتقسيط السيوف , شقق تمليك بالتقسيط الاقبال , مشروعات سما', 'Etman Group', 'المشروعات الحالية لشركة سما العقارية مشروعات سكنية ومصيفية بارقى احياء الاسكندرية شركة سما للاستثمار والتنمية العقاريه', 'سما العقارية للاستثمار والتنمية , المشروعات الحالية , الاسكندرية , شقق تمليك بالتقسيط ميامي , شقق تمليك بالتقسيط ستانلى , شقق تمليك بالتقسيط زيزينيا , شقق تمليك بالتقسيط جليم , شقق تمليك بالتقسيط السيوف , شقق تمليك بالتقسيط الاقبال , مشروعات سما', 0, '', '', '', '', '', 0, 0, 0, NULL, NULL, 0),
(19, 0, 'Etman Group', 'سابقة اعمال شركة سما العقارية للاستثمار والتنمية  والتى تضم مجموعة من المشروعات السكنية بارقى احياء الاسكندرية والتى قامت الشركة بتسويقها خلال الاعوام السابقة', 'مشروعات سابقة , سابقة الاعمال , شقق تمليك بالتقسيط ميامي , شقق تمليك بالتقسيط ستانلى , شقق تمليك بالتقسيط زيزينيا , شقق تمليك بالتقسيط الاقبال , شقق تمليك بالتقسيط بولكلى , شقق تمليك بالتقسيط جليم , شقق تمليك بالتقسيط سيدى بشر , شركة سما العقارية اسكندريه', 'Etman Group', 'سابقة اعمال شركة سما العقارية للاستثمار والتنمية  والتى تضم مجموعة من المشروعات السكنية بارقى احياء الاسكندرية والتى قامت الشركة بتسويقها خلال الاعوام السابقة', 'مشروعات سابقة , سابقة الاعمال , شقق تمليك بالتقسيط ميامي , شقق تمليك بالتقسيط ستانلى , شقق تمليك بالتقسيط زيزينيا , شقق تمليك بالتقسيط الاقبال , شقق تمليك بالتقسيط بولكلى , شقق تمليك بالتقسيط جليم , شقق تمليك بالتقسيط سيدى بشر , شركة سما العقارية اسكندريه', 0, '', '', '', '', '', 0, 0, 0, NULL, NULL, 0),
(21, 0, 'Etman Group', 'شركة سما للاستثمار والتنمية العقارية - قم بزيارة صفحة عن الشركة بالموقع حيث يوجد بها تعريف عن الشركة فيما يخص  مجال التنمية العقارية والسياحية', 'شركة سما للاستثمار والتنمية العقارية , شركات التسويق العقاري  , شقق تمليك بالاسكندرية تشطيب سوبر لوكس  , شقق سكني ومصيفي في الاسكندرية  , سما العقارية  , شركة استثمار عقارى بمصر  , اعلان بيع شقق  , سما العقارية الاسكندرية , عن الشركة , عن الشركه ', 'Etman Group', 'شركة سما للاستثمار والتنمية العقارية - قم بزيارة صفحة عن الشركة بالموقع حيث يوجد بها تعريف عن الشركة فيما يخص  مجال التنمية العقارية والسياحية', 'شركة سما للاستثمار والتنمية العقارية , شركات التسويق العقاري  , شقق تمليك بالاسكندرية تشطيب سوبر لوكس  , شقق سكني ومصيفي في الاسكندرية  , سما العقارية  , شركة استثمار عقارى بمصر  , اعلان بيع شقق  , سما العقارية الاسكندرية , عن الشركة , عن الشركه ', 0, '', '', '', '', 'about.jpg', 0, 0, 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_photo`
--

CREATE TABLE `config_photo` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `file_rename` int(11) NOT NULL,
  `resize_p` int(11) NOT NULL,
  `width` int(11) NOT NULL,
  `height` int(11) NOT NULL,
  `resize_t` int(11) NOT NULL,
  `width_t` int(11) NOT NULL,
  `height_t` int(11) NOT NULL,
  `mark` int(11) NOT NULL,
  `mark_text` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `mark_color` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `mark_back` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `png_state` int(11) NOT NULL,
  `photo` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `mark_position` int(11) NOT NULL,
  `color` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `m_size` int(11) NOT NULL,
  `m_width` int(11) NOT NULL,
  `m_height` int(11) NOT NULL,
  `quality` int(11) NOT NULL,
  `state` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `config_photo`
--

INSERT INTO `config_photo` (`id`, `name`, `file_rename`, `resize_p`, `width`, `height`, `resize_t`, `width_t`, `height_t`, `mark`, `mark_text`, `mark_color`, `mark_back`, `png_state`, `photo`, `mark_position`, `color`, `m_size`, `m_width`, `m_height`, `quality`, `state`) VALUES
(1, 'Don\\&#8217;t Change Size', 1, 1, 100, 100, 6, 200, 200, 0, 'wwww', '#ffffff', '#000000', 0, '', 1, '#FFFFFF', 1500, 1024, 1024, 70, 1),
(2, 'Landing Page Banner 1440x675', 1, 6, 1440, 675, 6, 300, 141, 0, 'wwww', '#ffffff', '#000000', 0, 'bluerock-logo.png', 1, '#FFFFFF', 1500, 1500, 1500, 70, 1),
(3, 'Landing Page Photo Album 1024x768', 1, 3, 1024, 768, 6, 450, 295, 0, 'www', '#ffffff', '#000000', 0, '', 1, '#FFFFFF', 1500, 2500, 2500, 70, 1),
(4, 'Landing Page PagePhoto 600x280', 1, 6, 600, 280, 6, 450, 211, 0, 'www.bluerok.com', '#ffffff', '#000000', 0, 'bluerock-logo_1.png', 1, '#FFFFFF', 2000, 2000, 2000, 70, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `add_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_sours` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_cat` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_type` int(11) DEFAULT '0',
  `c_type_2` int(11) DEFAULT '0',
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT '0',
  `countrylive_id` int(11) DEFAULT '0',
  `birth_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_day` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jop_id` int(11) DEFAULT '0',
  `social_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `religion` int(11) DEFAULT '0',
  `live_id` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `sub_count` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `date_add`, `user_id`, `add_id`, `lead_sours`, `lead_type`, `lead_cat`, `name`, `c_type`, `c_type_2`, `mobile`, `mobile_2`, `phone`, `email`, `city_id`, `country_id`, `countrylive_id`, `birth_date`, `birth_day`, `birth_month`, `id_no`, `jop_id`, `social_id`, `kind_id`, `religion`, `live_id`, `notes`, `address`, `state`, `sub_count`) VALUES
(1, '1570485600', 8, NULL, 2, 2, 0, 'مصنع الوقاية لتصنيع الادوية المتخصصة', 1, 1, '01117272995', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(2, '1570485600', 7, NULL, 2, 2, 0, 'اللواء للتجارة والتوزيع لمواد التعبئة والتغليف', 1, 1, '01098844011', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 'الاستفسار عن \r\nالفويل – اكواب ساخن \r\nالاسكوتش \r\nالاسترتش المنزلى والمستورد والمصرى \r\nاطباق الفويل \r\nالملاعق والشوك', NULL, 1, 0),
(3, '1570572000', 1, NULL, 1, 1, 0, 'حماده ماجور', 2, 0, '01002272683', '', '', '', 24, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(4, '1570572000', 1, NULL, 2, 1, 0, 'مايكل', 4, 3, '01277948492', '', '', '', 5, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(5, '1570572000', 1, NULL, 1, 1, 0, 'محمود محي', 4, 9, '01011536020', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(6, '1570572000', 1, NULL, 1, 1, 0, 'احمد كمال', 2, 0, '01016560092', '', '', '', 26, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(7, '1570572000', 1, NULL, 1, 1, 0, 'ايمان', 4, 3, '01154006829', '', '', '', 27, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(8, '1570572000', 1, NULL, 1, 1, 0, 'محمود الغزالى', 2, 0, '01066811110', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(9, '1570572000', 7, NULL, 2, 2, 0, 'شركة تمارا للدعاية والاعلان', 3, 7, '01141413419', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(10, '1570572000', 1, NULL, 1, 1, 0, 'ابراهيم ابو عرب', 2, 0, '01006432224', '', '', '', 24, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(11, '1570572000', 1, NULL, 1, 1, 0, '‎حماده رمضان‎', 3, 6, '01200666106', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(12, '1570572000', 1, NULL, 1, 1, 0, '‎الحسيني الفداوي‎', 4, 4, '01005533224', '', '', '', 14, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(13, '1570658400', 1, NULL, 1, 1, 0, 'منة ابو سنة', 4, 5, '01274225512', '', '', '', 18, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(14, '1570831200', 1, NULL, 1, 1, 0, 'خالد الميلادي', 4, 3, '01227304296', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(15, '1570831200', 1, NULL, 1, 1, 0, 'احمد عثمان', 2, 0, '01097050616', '', '', '', 6, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(16, '1570831200', 1, NULL, 1, 1, 0, 'احمد حسين', 1, 6, '01010206090', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 'تم', NULL, 1, 0),
(17, '1570831200', 8, NULL, 2, 2, 0, 'محمد ابو جبل', 4, 9, '01144400647', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(18, '1570831200', 1, NULL, 1, 1, 0, 'اشرف محمد‎', 4, 3, '01150020158', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(19, '1570831200', 8, NULL, 2, 2, 0, 'شركة كواليتى ترايد', 1, 0, '01145025239', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(20, '1570831200', 1, NULL, 1, 1, 0, 'احمد ناصر', 3, 6, '01006599166', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(21, '1570831200', 1, NULL, 1, 1, 0, 'Hamoda AboHashem', 2, 0, '01000292012', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(22, '1570917600', 1, NULL, 1, 1, 0, 'عمرو أحمد فرج', 2, 1, '01271232412', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(23, '1570917600', 7, NULL, 2, 2, 0, 'استاذ عمرو', 3, 6, '01022557047', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(24, '1570917600', 7, NULL, 2, 2, 0, 'استاذة ياسمين', 4, 3, '01095561879', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(25, '1570917600', 7, NULL, 2, 2, 0, 'محمود جلال', 1, 0, '01009874476', '', '', '', 14, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(26, '1571004000', 7, NULL, 2, 2, 0, 'ثلاجة الوفاء للاسماء المجمدة', 1, 0, '01125000059', '01007866587', '', '', 11, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(27, '1571004000', 7, NULL, 2, 2, 0, 'شريف عزت', 4, 8, '01224040459', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(28, '1571004000', 1, NULL, 1, 1, 0, 'لؤي عثمان', 2, 0, '01002725405', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(29, '1571004000', 1, NULL, 1, 1, 0, 'ايمن السويدي', 4, 3, '01006959458', '01146190688', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(30, '1571004000', 1, NULL, 1, 1, 0, 'عبدالله سيد', 2, 0, '01002679581', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(31, '1571004000', 1, NULL, 1, 1, 0, 'علاء الدين', 4, 9, '01009698365', '', '', '', 6, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(32, '1571004000', 1, NULL, 1, 1, 0, 'محمد عبد الرحمن', 4, 9, '01003855474', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(33, '1571004000', 1, NULL, 1, 1, 0, 'السيد حمزة', 2, 0, '01093961963', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(34, '1571004000', 1, NULL, 1, 1, 0, 'عبدالموجود عبدالمعطي', 4, 9, '01001390111', '', '', '', 23, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(35, '1571004000', 1, NULL, 1, 1, 0, 'زاهر الدبيكي', 4, 3, '01006657040', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(36, '1571090400', 1, NULL, 1, 1, 0, 'طارق ناصر', 2, 0, '01014158555', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(37, '1571090400', 1, NULL, 1, 1, 0, '‎وليد حشمت‎', 4, 9, '01092333911', '', '', '', 27, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(38, '1571090400', 1, NULL, 1, 1, 0, '‎محمد العدوى‎', 3, 6, '01062946415', '', '', '', 26, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(39, '1571176800', 7, NULL, 2, 2, 0, 'استاذ طارق', 4, 9, '01006333323', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(40, '1571176800', 7, NULL, 2, 2, 0, 'أ/ احمد هيكل شركة براند موف', 3, 6, '01060018347', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(41, '1571176800', 7, NULL, 2, 2, 0, 'أ / محمد ابراهيم', 4, 9, '01210857747', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(42, '1571522400', 7, NULL, 2, 2, 0, 'اسلام الرفاعى', 2, 0, '01001052579', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(43, '1571522400', 7, NULL, 2, 2, 0, 'محمود محمد', 2, 0, '01005513801', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(44, '1571522400', 7, NULL, 2, 2, 0, 'احمد شفيق', 2, 0, '01005614143', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(45, '1571608800', 7, NULL, 2, 2, 0, 'مصطفى حمدى', 4, 9, '01008575643', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(46, '1571608800', 7, NULL, 2, 2, 0, 'استاذ اياد', 4, 5, '01098105311', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(47, '1571781600', 7, NULL, 2, 2, 0, 'حلوانى دريس', 3, 6, '01200000000', '', '034861432', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(48, '1572127200', 7, NULL, 2, 2, 0, 'عمر اسامة', 2, 0, '01024578088', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(49, '1572213600', 7, NULL, 2, 2, 0, 'اسلام بدوى', 1, 0, '011111160107', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(50, '1572213600', 1, NULL, 1, 1, 0, 'حسين العطار', 2, 0, '01111000684', '01115599290', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(51, '1572300000', 7, NULL, 2, 2, 0, 'احمد مصطفى الزفتاوى', 3, 6, '01118339333', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(52, '1572300000', 1, NULL, 1, 1, 0, '‎محمد عيسى', 4, 5, '01001193686', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(53, '1572300000', 1, NULL, 1, 1, 0, 'م صفيه حليم', 2, 0, '01223182310', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(54, '1572300000', 1, NULL, 1, 1, 0, 'محمد ربيع', 2, 0, '01000171408', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(55, '1572386400', 1, NULL, 1, 1, 0, 'عمر والي', 2, 0, '01094356155', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(56, '1572386400', 7, NULL, 2, 2, 0, 'محمد اسماعيل', 3, 6, '01027060113', '', '', '', 14, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(57, '1572386400', 7, NULL, 2, 2, 0, 'احمد لاشين', 4, 3, '01000619517', '', '', '', 18, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(58, '1572386400', 1, NULL, 1, 1, 0, 'محمود عبدالكريم', 2, 0, '01011393864', '', '', '', 10, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(59, '1572386400', 1, NULL, 1, 1, 0, 'السيد حجازي', 2, 0, '01010251200', '01222607490', '', '', 24, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(60, '1572386400', 1, NULL, 1, 1, 0, 'محمد علي محمود', 2, 0, '01128168200', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(61, '1572386400', 1, NULL, 1, 1, 0, 'محمدعبدالدايم', 3, 6, '01012793200', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(62, '1572386400', 1, NULL, 1, 1, 0, 'احمد يوسف', 2, 0, '01004999261', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(63, '1572386400', 1, NULL, 1, 1, 0, 'باسم خفاجي', 4, 4, '01150001630', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(64, '1572386400', 1, NULL, 1, 1, 0, '‎صبرى السنجابى', 2, 0, '01005619390', '01060694623', '', '', 18, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(65, '1572386400', 1, NULL, 1, 1, 0, 'إبرام فرج', 2, 0, '01286093129', '', '', '', 27, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(66, '1572472800', 1, NULL, 1, 1, 0, 'مصطفى العجمي', 2, 0, '01288099900', '', '', '', 8, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(67, '1572645600', 1, NULL, 1, 1, 0, 'ابراهيم شرف', 4, 9, '01275257598', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(68, '1572645600', 1, NULL, 1, 1, 0, '‎العمده الاصلي ابو كريم‎', 2, 0, '01113044777', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(69, '1572732000', 7, NULL, 2, 2, 0, 'محمد رزق', 3, 6, '01156865595', '', '', '', 20, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(70, '1572732000', 7, NULL, 2, 2, 0, 'عصام احمد', 2, 0, '01223429286', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(71, '1572645600', 1, NULL, 1, 1, 0, 'ادهم خطاب', 4, 9, '01024242703', '', '', '', 25, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(72, '1572732000', 1, NULL, 1, 1, 0, 'محمد محمود', 2, 0, '01009265303', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(73, '1572818400', 7, NULL, 2, 2, 0, 'محمد سيد اليداك', 2, 0, '01006243910', '01065753888', '', '', 6, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(74, '1572818400', 7, NULL, 2, 2, 0, 'حمادة صلاح عيادة', 2, 0, '01006156356', '01204088460', '', '', 26, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(75, '1572818400', 1, NULL, 1, 1, 0, 'محمد السيد رزق', 2, 0, '01069409517', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(76, '1572818400', 1, NULL, 1, 1, 0, 'علاء ابو خطوة', 1, 0, '01288629077', '', '', '', 6, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(77, '1572818400', 1, NULL, 1, 1, 0, 'اسلام الترزاوي', 2, 0, '01012000017', '', '', '', 18, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(78, '1573336800', 1, NULL, 1, 1, 0, 'احمد بدوي', 4, 9, '01221186411', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(79, '1573336800', 1, NULL, 1, 1, 0, 'سراج على', 2, 0, '01002011115', '', '', '', 14, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(81, '1573941600', 7, NULL, 2, 2, 0, 'عبد المعطى كامل المحمدى', 4, 9, '01146174881', '', '', '', 13, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(82, '1573941600', 1, NULL, 1, 1, 0, 'محمود ابوغريب', 4, 3, '01001594698', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(83, '1574028000', 7, NULL, 2, 2, 0, 'أ / على', 4, 9, '01153561331', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(84, '1574114400', 7, NULL, 2, 2, 0, 'أ / عماد', 1, 0, '01220416636', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(85, '1574114400', 7, NULL, 2, 2, 0, 'محمد سيف', 4, 3, '01275767247', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(86, '1574460000', 1, NULL, 1, 1, 0, 'محمد مدحت', 2, 0, '01202070066', '', '', '', 4, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(87, '1574460000', 1, NULL, 1, 1, 0, 'أحمد يوسف', 2, 0, '01141166677', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(88, '1574460000', 7, NULL, 2, 2, 0, 'شركة مصر الفراعنة', 2, 0, '01128999222', '', '', '', 22, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(89, '1574460000', 7, NULL, 2, 2, 0, 'محمد مرجان ابو عوض', 2, 0, '01280308547', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(90, '1574460000', 1, NULL, 1, 1, 0, 'Ahmed Khlifa', 2, 0, '01207851151', '', '', '', 15, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(91, '1574460000', 1, NULL, 1, 1, 0, 'عامر محمد عبد العزيز الحمصاني', 3, 6, '01001597756', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(92, '1574460000', 1, NULL, 1, 1, 0, 'Mohamed Hamdy', 2, 0, '01111185140', '', '', '', 10, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(93, '1574892000', 7, NULL, 2, 2, 0, 'شركة مبادرة', 4, 8, '01005482855', '', '', '', 3, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(94, '1574892000', 7, NULL, 2, 2, 0, 'أ / نجوى عصمت', 2, 0, '01019260206', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(95, '1575064800', 1, NULL, 1, 1, 0, 'مؤمن مانو', 2, 0, '01093990281', '', '', '', 9, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(96, '1575064800', 1, NULL, 1, 1, 0, 'احمد حسن', 2, 0, '01226498860', '', '', '', 11, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0),
(97, '1695592800', 1, NULL, 1, 1, 0, 'هانى محمد محمد درويش', 3, 7, '01221563252', '', '', '', 2, 0, 0, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, '', NULL, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `customer_notes`
--

CREATE TABLE `customer_notes` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust_id` int(11) DEFAULT '100',
  `user_id` int(11) DEFAULT '100',
  `user_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `customer_sub`
--

CREATE TABLE `customer_sub` (
  `id` int(11) NOT NULL,
  `cust_id` int(11) DEFAULT '0',
  `rel` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_2` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cust_ticket`
--

CREATE TABLE `cust_ticket` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `reason_id` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `admin_id` int(11) DEFAULT '0',
  `follow_state` int(11) DEFAULT '0',
  `follow_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_id` int(11) DEFAULT '0',
  `close_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `close_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cust_ticket_des`
--

CREATE TABLE `cust_ticket_des` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `cust_id` int(11) DEFAULT '0',
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_id` int(11) DEFAULT '0',
  `follow_type` int(11) DEFAULT '0',
  `follow_state` int(11) DEFAULT '0',
  `des` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT '0',
  `user_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `c_leads`
--

CREATE TABLE `c_leads` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT '0',
  `add_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_sours` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_cat` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `c_type` int(11) DEFAULT '0',
  `c_type_2` int(11) DEFAULT '0',
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT '0',
  `countrylive_id` int(11) DEFAULT '0',
  `birth_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_day` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `birth_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `id_no` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jop_id` int(11) DEFAULT '0',
  `social_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `religion` int(11) DEFAULT '0',
  `live_id` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `address` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `sub_count` int(11) DEFAULT '0',
  `hotline` int(11) DEFAULT '0',
  `sales_man` int(11) DEFAULT '0',
  `ch` int(11) DEFAULT '0',
  `ch_2` int(11) DEFAULT '0',
  `cust` int(11) DEFAULT '0',
  `id_1` int(11) DEFAULT '0',
  `id_2` int(11) DEFAULT '0',
  `id_3` int(11) DEFAULT '0',
  `id_4` int(11) DEFAULT '0',
  `id_5` int(11) DEFAULT '0',
  `id_6` int(11) DEFAULT '0',
  `id_7` int(11) DEFAULT '0',
  `id_8` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `facebook_data`
--

CREATE TABLE `facebook_data` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_sours` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_cat` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `fi_city`
--

CREATE TABLE `fi_city` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fi_city`
--

INSERT INTO `fi_city` (`id`, `name`, `name_en`, `count`, `state`) VALUES
(1, 'خارج مصر', 'Out Of Egypt', 0, 1),
(2, 'القاهرة', 'Cairo', 9, 1),
(3, 'الاسكندرية', 'Alexandria', 3, 1),
(4, 'الاسماعيلية', 'Ismailia', 0, 1),
(5, 'اسوان', 'Aswan', 1, 1),
(6, 'اسيوط', 'Asyut', 2, 1),
(7, 'الاقصر', 'Luxor', 0, 1),
(8, 'البحر الاحمر', 'Red Sea', 0, 1),
(9, 'البحيرة', 'Beheira ', 4, 1),
(10, 'بني سويف', 'Beni Suef', 0, 1),
(11, 'بورسعيد', 'Port Said', 1, 1),
(12, 'جنوب سيناء', 'South Sinai', 0, 1),
(13, 'الجيزة', 'Giza', 4, 1),
(14, 'الدقهلية', 'Dakahlia', 2, 1),
(15, 'دمياط', 'Damietta', 3, 1),
(16, 'سوهاج', 'Sohag', 0, 1),
(17, 'السويس', 'Suez', 0, 1),
(18, 'الشرقية', 'Sharqia', 1, 1),
(19, 'شمال سيناء', 'North Sinai', 0, 1),
(20, 'الغربية', 'Gharbia', 3, 1),
(21, 'الفيوم', 'Faiyum', 0, 1),
(22, 'القليوبية', 'Qalyubia', 4, 1),
(23, 'قنا', 'Qena', 1, 1),
(24, 'كفر الشيخ', 'Kafr El Sheikh', 2, 1),
(25, 'مطروح', 'Matruh', 0, 1),
(26, 'المنوفية', 'Monufia', 2, 1),
(27, 'المنيا', 'Minya', 2, 1),
(28, 'الوادى الجديد', 'New Valley', 0, 1),
(29, 'غير محدد', 'undefined', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fi_country`
--

CREATE TABLE `fi_country` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `count_live` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fi_country`
--

INSERT INTO `fi_country` (`id`, `name`, `name_en`, `code`, `state`, `count`, `count_live`) VALUES
(1, 'اثيوبيا', 'Ethiopia', '+251', 1, 0, 0),
(2, 'اذربيجان', 'Azerbaijan', '+994', 1, 0, 0),
(3, 'ارمينيا', 'Armenia', '+374', 1, 0, 0),
(4, 'اروبا', 'Aruba', '+297', 1, 0, 0),
(5, 'استراليا', 'Australia', '+61', 1, 0, 0),
(6, 'اندورا', 'Andorra', '+376', 1, 0, 0),
(7, 'البانيا', 'Albania', '+355', 1, 0, 0),
(8, 'المانيا', 'Germany', '+49', 1, 0, 1),
(9, 'انتاركتيكا', 'Antarctica', '+672', 1, 0, 0),
(10, 'انتيغوا وباربودا', 'Antigua and Barbuda', '+1268', 1, 0, 0),
(11, 'انجولا', 'Angola', '+244', 1, 0, 0),
(12, 'الامارات العربية المتحدة', 'United Arab Emirates', '+971', 1, 0, 22),
(13, 'انجويلا', 'Anguilla', '+1264', 1, 0, 0),
(14, 'اوروجواي', 'Uruguay', '+598', 1, 0, 0),
(15, 'اوزبكستان', 'Uzbekistan', '+998', 1, 0, 0),
(16, 'اوغندا', 'Uganda', '+256', 1, 0, 0),
(17, 'اوكرانيا', 'Ukraine', '+380', 1, 0, 0),
(18, 'ايرلندا', 'Ireland', '+353', 1, 0, 0),
(19, 'ايسلندا', 'Iceland', '+354', 1, 0, 0),
(20, 'اريتريا', 'Eritrea', '+291', 1, 0, 0),
(21, 'اسبانيا', 'Spain', '+34', 1, 0, 0),
(22, 'استونيا', 'Estonia', '+372', 1, 0, 0),
(23, 'اسرائيل', 'Israel', '+972', 1, 0, 0),
(24, 'اندونيسيا', 'Indonesia', '+62', 1, 0, 0),
(25, 'ايران', 'Iran', '+98', 1, 0, 0),
(26, 'ايطاليا', 'Italy', '+39', 1, 0, 12),
(27, 'اتحاد ولايات ميكرونيزيا', 'Federated States Of Micronesia', '+691', 1, 0, 0),
(28, 'الارجنتين', 'Argentina', '+54', 1, 0, 0),
(29, 'الاردن', 'Jordan', '+962', 1, 0, 2),
(30, 'الاكوادور', 'Ecuador', '+593', 1, 0, 0),
(31, 'افغانستان', 'Afghanistan', '+93', 1, 0, 0),
(32, 'البحرين', 'Bahrain', '+973', 1, 0, 2),
(33, 'البرازيل', 'Brazil', '+55', 1, 0, 0),
(34, 'البرتغال', 'Portugal', '+351', 1, 0, 0),
(35, 'البوسنة والهرسك', 'Bosnia and Herzegovina', '+387', 1, 0, 0),
(36, 'الجزائر', 'Algeria', '+213', 1, 0, 0),
(37, 'الدنمارك', 'Denmark', '+45', 1, 0, 0),
(38, 'الراس الاخضر', 'Cape Verde', '+238', 1, 0, 0),
(39, 'السلفادور', 'El Salvador', '+503', 1, 0, 0),
(40, 'السنغال', 'Senegal', '+221', 1, 0, 0),
(41, 'السودان', 'Sudan', '+249', 1, 0, 2),
(42, 'السويد', 'Sweden', '+46', 1, 0, 0),
(43, 'الصرب', 'Serbia', '+381', 1, 0, 0),
(44, 'الصومال', 'Somalia', '+252', 1, 0, 0),
(45, 'الصين', 'China', '+86', 1, 0, 0),
(46, 'العراق', 'Iraq', '+964', 1, 0, 0),
(47, 'الغابون', 'Gabon', '+241', 1, 0, 0),
(48, 'الفليبين', 'Philippines', '+63', 1, 0, 0),
(49, 'الكاميرون', 'Cameroon', '+237', 1, 0, 0),
(50, 'الكونغو', 'Congo', '+242', 1, 0, 0),
(51, 'الكويت', 'Kuwait', '+965', 1, 0, 52),
(52, 'المارتينيك', 'Martinique', '+596', 1, 0, 0),
(53, 'المجر', 'Hungary', '+36', 1, 0, 0),
(54, 'المغرب', 'Morocco', '+212', 1, 0, 0),
(55, 'المكسيك', 'Mexico', '+52', 1, 0, 0),
(56, 'المملكة العربية السعودية', 'Saudi Arabia', '+966', 1, 0, 47),
(57, 'المملكة المتحدة', 'United Kingdom', '+44', 1, 0, 0),
(58, 'النرويج', 'Norway', '+47', 1, 0, 0),
(59, 'النمسا', 'Austria', '+43', 1, 0, 0),
(60, 'النيجر', 'Niger', '+227', 1, 0, 0),
(61, 'الهند', 'India', '+91', 1, 0, 0),
(62, 'الولايات المتحدة', 'United States', '+1', 1, 0, 0),
(63, 'اليابان', 'Japan', '+81', 1, 0, 0),
(64, 'اليمن', 'Yemen', '+967', 1, 0, 0),
(65, 'اليونان', 'Greece', '+30', 1, 0, 0),
(66, 'بابوا غينيا الجديدة', 'Papua New Guinea', '+675', 1, 0, 0),
(67, 'باراجواي', 'Paraguay', '+595', 1, 0, 0),
(68, 'باكستان', 'Pakistan', '+92', 1, 0, 0),
(69, 'بالاو', 'Palau', '+680', 1, 0, 0),
(70, 'بتسوانا', 'Botswana', '+267', 1, 0, 0),
(71, 'بربادوس', 'Barbados', '+1246', 1, 0, 0),
(72, 'برمودا', 'Bermuda', '+1441', 1, 0, 0),
(73, 'بروناي', 'Brunei', '+673', 1, 0, 0),
(74, 'بلجيكا', 'Belgium', '+32', 1, 0, 0),
(75, 'بلغاريا', 'Bulgaria', '+359', 1, 0, 0),
(76, 'بليز', 'Belize', '+501', 1, 0, 0),
(77, 'بنجلاديش', 'Bangladesh', '+880', 1, 0, 0),
(78, 'بنما', 'Panama', '+507', 1, 0, 0),
(79, 'بنين', 'Benin', '+229', 1, 0, 0),
(80, 'بوتان', 'Bhutan', '+975', 1, 0, 0),
(81, 'بورتوريكو', 'Puerto Rico', '+1787', 1, 0, 0),
(82, 'بوركينا فاسو', 'Burkina Faso', '+226', 1, 0, 0),
(83, 'بوروندي', 'Burundi', '+257', 1, 0, 0),
(84, 'بولندا', 'Poland', '+48', 1, 0, 0),
(85, 'بوليفيا', 'Bolivia', '+591', 1, 0, 0),
(86, 'بولينيزيا الفرنسية', 'French Polynesia', '+689', 1, 0, 0),
(87, 'بيرو', 'Peru', '+51', 1, 0, 0),
(88, 'بيلاروس', 'Belarus', '+375', 1, 0, 0),
(89, 'تايلاند', 'Thailand', '+66', 1, 0, 0),
(90, 'تايوان', 'Taiwan', '+886', 1, 0, 0),
(91, 'تركمانستان', 'Turkmenistan', '+993', 1, 0, 0),
(92, 'تركيا', 'Turkey', '+90', 1, 0, 0),
(93, 'ترينيداد وتوباجو', 'Trinidad and Tobago', '+1868', 1, 0, 0),
(94, 'تشاد', 'Chad', '+235', 1, 0, 0),
(95, 'تنزانيا', 'Tanzania', '+255', 1, 0, 0),
(96, 'توجو', 'Togo', '+228', 1, 0, 0),
(97, 'توفالو', 'Tuvalu', '+688', 1, 0, 0),
(98, 'توكيلو', 'Tokelau', '+690', 1, 0, 0),
(99, 'تونجا', 'Tonga', '+676', 1, 0, 0),
(100, 'تونس', 'Tunisia', '+216', 1, 0, 0),
(101, 'تيمور الشرقية', 'East Timor', '+670', 1, 0, 0),
(102, 'جامايكا', 'Jamaica', '+1876', 1, 0, 0),
(103, 'جبل طارق', 'Gibraltar', '+350', 1, 0, 0),
(104, 'جرينلاند', 'Greenland', '+299', 1, 0, 0),
(105, 'جزر الانتيل الهولندية', 'Netherlands Antilles', '+599', 1, 0, 0),
(106, 'جزر الباهاما', 'Bahamas', '+1242', 1, 0, 0),
(107, 'جزر العذراء الامريكية', 'Virgin Islands, US', '+1340', 1, 0, 0),
(108, 'جزر العذراء البريطانية', 'Virgin Islands, British', '+1284', 1, 0, 0),
(109, 'جزر القمر', 'Comoros', '+269', 1, 0, 0),
(110, 'جزر المالديف', 'Malawi', '+265', 1, 0, 0),
(111, 'جزر تركس وكايكوس', 'Turks and Caicos Islands', '+1649', 1, 0, 0),
(112, 'جزر ساموا الامريكية', 'American Samoa', '+1684', 1, 0, 0),
(113, 'جزر سليمان', 'Solomon Islands', '+677', 1, 0, 0),
(114, 'جزر فارو', 'Faroe Islands', '+298', 1, 0, 0),
(115, 'جزر فوكلاند (مالفينس)', 'Falkland Islands (Malvinas)', '+500', 1, 0, 0),
(116, 'جزر كايمن', 'Cayman Islands', '+1345', 1, 0, 0),
(117, 'جزر كوك', 'Cook Islands', '+682', 1, 0, 0),
(118, 'جزر مارشال', 'Marshall Islands', '+692', 1, 0, 0),
(119, 'جزر نورثرن ماريانا', 'Northern Mariana Islands', '+1670', 1, 0, 0),
(120, 'جمهورية افريقيا الوسطى', 'Central African Republic', '+236', 1, 0, 0),
(121, 'جمهورية التشيك', 'Czech Republic', '+420', 1, 0, 0),
(122, 'جمهورية الدومينيكان', 'Dominican Republic', '+18', 1, 0, 0),
(123, 'جمهورية الكونغو الديمقراطية', 'Congo, The Democratic Republic of the', '+243', 1, 0, 0),
(124, 'جنوب افريقيا', 'South Africa', '+27', 1, 0, 0),
(125, 'جواتيمالا', 'Guatemala', '+502', 1, 0, 0),
(126, 'جورجيا', 'Georgia', '+995', 1, 0, 0),
(127, 'جويانا', 'Guyana', '+592', 1, 0, 0),
(128, 'جيبوتي', 'Djibouti', '+253', 1, 0, 0),
(129, 'دولة الفاتيكان', 'Vatican City State (Holy See)', '+3', 1, 0, 0),
(130, 'دومينيكا', 'Dominica', '+1767', 1, 0, 0),
(131, 'رواندا', 'Rwanda', '+250', 1, 0, 0),
(132, 'روسيا', 'Russia', '+7', 1, 0, 0),
(133, 'رومانيا', 'Romania', '+40', 1, 0, 0),
(134, 'جزيرة ريونيون', 'Reunion Island', '+262', 1, 0, 0),
(135, 'زامبيا', 'Zambia', '+260', 1, 0, 0),
(136, 'زيمبابوي', 'Zimbabwe', '+263', 1, 0, 0),
(137, 'ساحل العاج', 'Cote D’Ivoire', '+225', 1, 0, 0),
(138, 'ساموا', 'Samoa', '+685', 1, 0, 0),
(139, 'سان مارينو', 'San Marino', '+378', 1, 0, 0),
(140, 'سانت بيير وميكولون', 'Saint Pierre and Miquelon', '+508', 1, 0, 0),
(141, 'سانت فينسنت وغرينادينز', 'Saint Vincent and the Grenadines', '+1784', 1, 0, 0),
(142, 'سانت كيتس ونيفيس', 'Saint Kitts and Nevis', '+1869', 1, 0, 0),
(143, 'سانت لوتشيا', 'Saint Lucia', '+1758', 1, 0, 0),
(144, 'سانت هيلينا', 'Saint Helena', '+290', 1, 0, 0),
(145, 'ساو توم وبرينسيب', 'Sao Tome and Principe', '+239', 1, 0, 0),
(146, 'سريلانكا', 'Sri Lanka', '+94', 1, 0, 0),
(147, 'سلوفاكيا', 'Slovakia', '+421', 1, 0, 0),
(148, 'سلوفينيا', 'Slovenia', '+386', 1, 0, 0),
(149, 'سنغافورة', 'Singapore', '+65', 1, 0, 0),
(150, 'سوازيلاند', 'Swaziland', '+268', 1, 0, 0),
(151, 'سوريا', 'Syria', '+963', 1, 0, 0),
(152, 'سورينام', 'Suriname', '+597', 1, 0, 0),
(153, 'سويسرا', 'Switzerland', '+41', 1, 0, 0),
(154, 'سيراليون', 'Sierra Leone', '+232', 1, 0, 0),
(155, 'سيشل', 'Seychelles', '+248', 1, 0, 0),
(156, 'شيلي', 'Chile', '+56', 1, 0, 0),
(157, 'طاجيكستان', 'Tajikistan', '+992', 1, 0, 0),
(158, 'عُمان', 'Oman', '+968', 1, 0, 0),
(159, 'غامبيا', 'Gambia', '+220', 1, 0, 0),
(160, 'غانا', 'Ghana', '+233', 1, 0, 0),
(161, 'غرينادا', 'Grenada', '+1473', 1, 0, 0),
(162, 'غواديلوب', 'Guadeloupe', '+590', 1, 0, 0),
(163, 'غوام', 'Guam', '+1671', 1, 0, 0),
(164, 'غيانا الفرنسية', 'French Guiana', '+594', 1, 0, 0),
(165, 'غينيا', 'Guinea', '+224', 1, 0, 0),
(166, 'غينيا الاستوائية', 'Equatorial Guinea', '+240', 1, 0, 0),
(167, 'غينيا-بيساو', 'Guinea-Bissau', '+245', 1, 0, 0),
(168, 'فانواتو', 'Vanuatu', '+678', 1, 0, 0),
(169, 'فرنسا', 'France', '+33', 1, 0, 5),
(170, 'فنزويلا', 'Venezuela', '+58', 1, 0, 0),
(171, 'فنلندا', 'Finland', '+358', 1, 0, 0),
(172, 'فيتنام', 'Vietnam', '+84', 1, 0, 0),
(173, 'فيجي', 'Fiji', '+679', 1, 0, 0),
(174, 'قبرص', 'Cyprus', '+357', 1, 0, 0),
(175, 'قطر', 'Qatar', '+974', 1, 0, 18),
(176, 'قيرغيستان', 'Kyrgyzstan', '+996', 1, 0, 0),
(177, 'كازاخستان', 'Kazakhstan', '+7', 1, 0, 0),
(178, 'كرواتيا', 'Croatia', '+385', 1, 0, 0),
(179, 'كمبوديا', 'Cambodia', '+855', 1, 0, 0),
(180, 'كندا', 'Canada', '+1', 1, 0, 0),
(181, 'كوبا', 'Cuba', '+53', 1, 0, 0),
(182, 'كوريا الجنوبية', 'Korea, South', '+82', 1, 0, 0),
(183, 'كوريا الشمالية', 'Korea, North', '+850', 1, 0, 0),
(184, 'كوستاريكا', 'Costa Rica', '+506', 1, 0, 0),
(185, 'كولومبيا', 'Colombia', '+57', 1, 0, 0),
(186, 'كيريباتي', 'Kiribati', '+686', 1, 0, 0),
(187, 'كينيا', 'Kenya', '+254', 1, 0, 0),
(188, 'لاتفيا', 'Latvia', '+371', 1, 0, 0),
(189, 'لاوس', 'Laos', '+856', 1, 0, 0),
(190, 'لبنان', 'Lebanon', '+961', 1, 0, 1),
(191, 'لوكسمبورج', 'Luxembourg', '+352', 1, 0, 0),
(192, 'ليبريا', 'Liberia', '+231', 1, 0, 0),
(193, 'ليبيا', 'Libya', '+218', 1, 0, 0),
(194, 'ليتوانيا', 'Lithuania', '+370', 1, 0, 0),
(195, 'ليخنشتاين', 'Liechtenstein', '+423', 1, 0, 0),
(196, 'ليسوتو', 'Lesotho', '+266', 1, 0, 0),
(197, 'ماكاو', 'Macao', '+853', 1, 0, 0),
(198, 'مالاوي', 'Maldives', '+960', 1, 0, 0),
(199, 'مالطا', 'Malta', '+356', 1, 0, 1),
(200, 'مالي', 'Mali', '+223', 1, 0, 0),
(201, 'ماليزيا', 'Malaysia', '+60', 1, 0, 0),
(202, 'مايوتي', 'Mayotte', '+269', 1, 0, 0),
(203, 'مدغشقر', 'Madagascar', '+261', 1, 0, 0),
(204, 'مصر', 'Egypt', '+20', 1, 0, 359),
(205, 'مقدونيا', 'Macedonia', '+389', 1, 0, 0),
(206, 'منغوليا', 'Mongolia', '+976', 1, 0, 0),
(207, 'موريتانيا', 'Mauritania', '+222', 1, 0, 0),
(208, 'موريشيوس', 'Mauritius', '+230', 1, 0, 0),
(209, 'موزمبيق', 'Mozambique', '+258', 1, 0, 0),
(210, 'مولدوفا', 'Moldova', '+373', 1, 0, 0),
(211, 'موناكو', 'Monaco', '+377', 1, 0, 0),
(212, 'مونت سيرات', 'Montserrat', '+1664', 1, 0, 0),
(213, 'جمهورية الجبل الاسود', 'Montenegro', '+382', 1, 0, 0),
(214, 'ميانمار (بورما)', 'Myanmar (Burma)', '+95', 1, 0, 0),
(215, 'ناميبيا', 'Namibia', '+264', 1, 0, 0),
(216, 'ناورو', 'Nauru', '+674', 1, 0, 0),
(217, 'نيبال', 'Nepal', '+977', 1, 0, 0),
(218, 'نيجيريا', 'Nigeria', '+234', 1, 0, 1),
(219, 'نيكاراجوا', 'Nicaragua', '+505', 1, 0, 0),
(220, 'نيوزيلندا', 'New Zealand', '+64', 1, 0, 0),
(221, 'نيوكاليدونيا', 'New Caledonia', '+687', 1, 0, 0),
(222, 'نيوي', 'Niue', '+683', 1, 0, 0),
(223, 'هايتي', 'Haiti', '+509', 1, 0, 0),
(224, 'هندوراس', 'Honduras', '+504', 1, 0, 0),
(225, 'هولندا', 'Netherlands', '+31', 1, 0, 0),
(226, 'هونج كونج', 'Hong Kong S.A.R., China', '+852', 1, 0, 0),
(227, 'والس وفوتونا', 'Wallis and Futuna', '+681', 1, 0, 0),
(228, 'جزيرة اسينشين', 'ASCENSION ISLAND', '+247', 1, 0, 0),
(233, 'القمر الصناعي امسات (خطوط الثريا) 882+', 'THURAYA (SATELLITE EMSAT) +882', '+882', 1, 0, 0),
(235, 'خدمة الهاتف المجاني الدولي', 'INTERNATIONAL FREEPHONE SERVICE', '+800', 1, 0, 0),
(236, 'دييجو جارسيا', 'DIEGO GARCIA', '+246', 1, 0, 0),
(237, 'فلسطين', 'Palestine', '+970', 1, 0, 0),
(238, 'جزيرة نورفولك', 'NORFOLK ISLANDS', '+672', 1, 0, 0),
(239, 'زنجبار', 'ZANZIBAR', '+255', 1, 0, 0),
(240, 'القمر الصناعي (انمارسات) 87+', 'SATELLITE (INMARSAT) +87', '0087', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fs_lead_sours`
--

CREATE TABLE `fs_lead_sours` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_lead_sours`
--

INSERT INTO `fs_lead_sours` (`id`, `name`, `name_en`, `count`, `state`) VALUES
(1, 'فيس بوك', 'فيس بوك', 27, 1),
(2, 'اتصال مباشر', 'اتصال مباشر', 17, 1),
(3, 'اعادة توجيه', 'اعادة توجيه', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fs_lead_type`
--

CREATE TABLE `fs_lead_type` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_lead_type`
--

INSERT INTO `fs_lead_type` (`id`, `name`, `name_en`, `count`, `state`) VALUES
(1, 'تعليق', 'تعليق', 28, 1),
(2, 'اتصال', 'اتصال', 16, 1),
(3, 'اعادة توجيه', 'اعادة توجيه', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `fs_report_chart`
--

CREATE TABLE `fs_report_chart` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cat_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `val` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_date_m` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `color` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_report_chart`
--

INSERT INTO `fs_report_chart` (`id`, `name`, `name_en`, `cat_id`, `val`, `f_date`, `f_date_m`, `color`) VALUES
(1, 'الزيارات', 'الزيارات', 't_visits', 'visit_s', 'visit_date', 'visit_month', '#5ab1ef'),
(2, 'الحجوزات', 'الحجوزات', 't_visits', 'rev_s', 'rev_date', 'rev_month', '#f5994e'),
(3, 'التعاقدات', 'التعاقدات', 't_visits', 'contract_s', 'contract_date', 'cancel_month', '#7cbf62'),
(4, 'الغاء الحجز', 'Cancellation', 't_visits', 'cancel_s', 'cancel_date', 'contract_month', '#f35839');

-- --------------------------------------------------------

--
-- Table structure for table `fs_ticket_closed`
--

CREATE TABLE `fs_ticket_closed` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_ticket_closed`
--

INSERT INTO `fs_ticket_closed` (`id`, `name`, `name_en`, `state`, `count`) VALUES
(1, 'تعاقد', 'Contract', 0, 9),
(2, 'ارشفة', 'Archive', 0, 14),
(3, 'خسارة', 'Loss', 0, 31);

-- --------------------------------------------------------

--
-- Table structure for table `fs_ticket_cust`
--

CREATE TABLE `fs_ticket_cust` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_ticket_cust`
--

INSERT INTO `fs_ticket_cust` (`id`, `name`, `name_en`, `state`, `count`) VALUES
(1, 'عميل جديد', 'New Customer ', 1, 0),
(2, 'عميل سابق ', 'Old Customer ', 1, 0),
(3, 'اعادة توجيه', 'Reopen Ticket ', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `fs_ticket_state`
--

CREATE TABLE `fs_ticket_state` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `fs_ticket_state`
--

INSERT INTO `fs_ticket_state` (`id`, `name`, `name_en`, `state`) VALUES
(1, 'قيد المراجعة ', 'Under Review', 1),
(2, 'تذكرة مفتوحة', 'Open Ticket ', 1),
(3, 'تعاقد معلق', 'تعاقد معلق', 1),
(4, 'مغلق للمراجعة', 'مغلق للمراجعة', 1),
(5, 'مغلقة', 'مغلقة', 1);

-- --------------------------------------------------------

--
-- Table structure for table `f_cust_subtype`
--

CREATE TABLE `f_cust_subtype` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `f_cust_subtype`
--

INSERT INTO `f_cust_subtype` (`id`, `cat_id`, `name`, `name_en`, `count`, `state`) VALUES
(1, 2, 'مهتم', 'مهتم', 4, 1),
(2, 2, 'غير مهتم', 'غير مهتم', 0, 1),
(3, 4, 'باحث عن سعر فقط', 'باحث عن سعر فقط', 5, 1),
(4, 4, 'منافس', 'منافس', 0, 1),
(5, 4, 'امكانية ضعيفة', 'امكانية ضعيفة', 0, 1),
(6, 3, 'يمكن متابعتها لاحقا', 'يمكن متابعتها لاحقا', 0, 1),
(7, 3, 'المنتج غير متوفر حاليا', 'المنتج غير متوفر حاليا', 1, 1),
(8, 4, 'تسجيل بيانات بالخطأ', 'تسجيل بيانات بالخطأ', 1, 1),
(9, 4, 'غير جاد - لايرد على الاتصال', 'غير جاد - لايرد على الاتصال', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `f_cust_type`
--

CREATE TABLE `f_cust_type` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `url` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `f_cust_type`
--

INSERT INTO `f_cust_type` (`id`, `name`, `name_en`, `url`, `count`, `state`) VALUES
(1, 'عميل', 'Customer', 'Current', 9, 1),
(2, 'عميل محتمل', 'Potential Customer', 'Possible', 43, 1),
(3, 'عميل مؤرشف ', 'Archived client', 'Archived', 12, 1),
(4, 'عميل تم خسارته ', 'Client has been lost', 'Loss', 31, 1),
(5, 'عميل جديد', 'New Customer', 'NewCust', 0, 1),
(6, 'عميل تعاقد', 'Contract Customer', 'ContractCust', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `f_live`
--

CREATE TABLE `f_live` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `f_live`
--

INSERT INTO `f_live` (`id`, `name`, `name_en`, `count`, `state`) VALUES
(1, 'مصرى يقيم فى مصر ', 'Egyptian live in Egypt', 36, 1),
(2, 'مصرى يقيم فى الخارج', 'Egyptian living abroad', 13, 1),
(3, 'غير مصرى يقيم فى مصر ', 'Non-Egyptian live in Egypt', 1, 1),
(4, 'غير مصرى يقيم فى الخارج', 'Non-Egyptian residing abroad', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `landpage`
--

CREATE TABLE `landpage` (
  `id` int(11) NOT NULL,
  `lead_cat` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_sours` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_m` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci,
  `g_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8_unicode_ci,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_m_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des_en` text COLLATE utf8_unicode_ci,
  `g_name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_des_en` text COLLATE utf8_unicode_ci,
  `photo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_t` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mob_state` int(11) DEFAULT '0',
  `mob_num` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mob_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mob_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mob_des` text COLLATE utf8_unicode_ci,
  `mob_des_en` text COLLATE utf8_unicode_ci,
  `face_code` text COLLATE utf8_unicode_ci,
  `google_code` text COLLATE utf8_unicode_ci,
  `google_code_thanks` text COLLATE utf8_unicode_ci,
  `face_code_thanks` text COLLATE utf8_unicode_ci,
  `thanks_title` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thanks_title_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thanks_des` text COLLATE utf8_unicode_ci,
  `thanks_des_en` text COLLATE utf8_unicode_ci,
  `website_url` text COLLATE utf8_unicode_ci,
  `thanks_mob` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_config` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landpage_block`
--

CREATE TABLE `landpage_block` (
  `id` int(11) NOT NULL,
  `type` int(11) DEFAULT '0',
  `cat_id` int(11) DEFAULT '0',
  `var` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `block_style` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `menu_s` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landpage_data`
--

CREATE TABLE `landpage_data` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_cat` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_sours` int(11) DEFAULT '0',
  `unit_type` int(11) DEFAULT '0',
  `service_type_id` int(11) DEFAULT '0',
  `district_id` int(11) DEFAULT '0',
  `project_id` int(11) DEFAULT '0',
  `name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `f_url` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_ip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landpage_photo`
--

CREATE TABLE `landpage_photo` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci,
  `des_en` text COLLATE utf8_unicode_ci,
  `photo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo_t` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `landpage_photo_cat`
--

CREATE TABLE `landpage_photo_cat` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci,
  `des_en` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project`
--

CREATE TABLE `project` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `pro_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `area_id` int(11) DEFAULT '0',
  `crunt` int(11) DEFAULT '0',
  `floor_count` int(11) DEFAULT '0',
  `unit_count` int(11) DEFAULT '0',
  `rev` int(11) DEFAULT '0',
  `rev_c` int(11) DEFAULT '0',
  `con` int(11) DEFAULT '0',
  `con_c` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_area`
--

CREATE TABLE `project_area` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_floor`
--

CREATE TABLE `project_floor` (
  `id` int(11) NOT NULL,
  `pro_id` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `f_code` int(11) DEFAULT '0',
  `unit` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_floor_name`
--

CREATE TABLE `project_floor_name` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_price`
--

CREATE TABLE `project_price` (
  `id` int(11) NOT NULL,
  `pro_id` int(11) DEFAULT '0',
  `count` int(11) DEFAULT '0',
  `last_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `total_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_m_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `reser_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contract_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monthly_price` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `monthly_des` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `st_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `end_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_data` text COLLATE utf8_unicode_ci,
  `t_data` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `project_unit`
--

CREATE TABLE `project_unit` (
  `id` int(11) NOT NULL,
  `price_id` int(11) DEFAULT '0',
  `pro_id` int(11) DEFAULT '0',
  `floor_id` int(11) DEFAULT '0',
  `f_code` int(11) DEFAULT '0',
  `u_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `p_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_num` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `u_area` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `g_area` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `rev_id` int(11) DEFAULT '0',
  `avtive` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `id` int(11) NOT NULL,
  `type` int(11) DEFAULT '0',
  `ref` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(11) DEFAULT '0',
  `pro_id` int(11) DEFAULT '0',
  `floor_id` int(11) DEFAULT '0',
  `rev_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cont_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_id` int(11) DEFAULT '0',
  `cust_id` int(11) DEFAULT '0',
  `cust2_id` int(11) DEFAULT '0',
  `cust3_id` int(11) DEFAULT '0',
  `unit_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pro_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `floor_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `emp_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust2_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cust3_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_num` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `new_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ref_num_2` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notes_2` text COLLATE utf8_unicode_ci,
  `dell_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dell_num` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dell_notes` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sales_ticket`
--

CREATE TABLE `sales_ticket` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lead_sours` int(11) DEFAULT '0',
  `lead_type` int(11) DEFAULT '0',
  `lead_cat` int(11) DEFAULT '0',
  `ticket_cust` int(11) DEFAULT '0',
  `cust_id` int(11) DEFAULT '0',
  `user_id` int(11) DEFAULT '0',
  `notes` text COLLATE utf8_unicode_ci,
  `admin_id` int(11) DEFAULT '0',
  `cash_id` int(11) DEFAULT '0',
  `unit_id` int(11) DEFAULT '0',
  `date_id` int(11) DEFAULT '0',
  `bestcall_id` int(11) DEFAULT '0',
  `time_id` int(11) DEFAULT '0',
  `area_id` int(11) DEFAULT '0',
  `pro_area` text COLLATE utf8_unicode_ci,
  `follow_state` int(11) DEFAULT '0',
  `follow_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_id` int(11) DEFAULT '0',
  `c_type` int(11) DEFAULT '0',
  `c_type_2` int(11) DEFAULT '0',
  `visit_s` int(11) DEFAULT '0',
  `visit_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `visit_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rev_s` int(11) DEFAULT '0',
  `rev_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rev_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `rev_date_2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancel_s` int(11) DEFAULT '0',
  `cancel_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cancel_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contract_s` int(11) DEFAULT '0',
  `contract_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contract_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `jop_id` int(11) DEFAULT '0',
  `kind_id` int(11) DEFAULT '0',
  `social_id` int(11) DEFAULT '0',
  `live_id` int(11) DEFAULT '0',
  `country_id` int(11) DEFAULT '0',
  `countrylive_id` int(11) DEFAULT '0',
  `city_id` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  `close_follow` int(11) DEFAULT '0',
  `close_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `close_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `close_date_2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `close_month_2` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `close_type` int(11) DEFAULT '0',
  `close_review` int(11) DEFAULT '0',
  `contact_review` int(11) DEFAULT '0',
  `support_review` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_ticket`
--

INSERT INTO `sales_ticket` (`id`, `date_add`, `date_month`, `date_time`, `lead_sours`, `lead_type`, `lead_cat`, `ticket_cust`, `cust_id`, `user_id`, `notes`, `admin_id`, `cash_id`, `unit_id`, `date_id`, `bestcall_id`, `time_id`, `area_id`, `pro_area`, `follow_state`, `follow_date`, `follow_time`, `priority_id`, `c_type`, `c_type_2`, `visit_s`, `visit_date`, `visit_month`, `rev_s`, `rev_date`, `rev_month`, `rev_date_2`, `cancel_s`, `cancel_date`, `cancel_month`, `contract_s`, `contract_date`, `contract_month`, `jop_id`, `kind_id`, `social_id`, `live_id`, `country_id`, `countrylive_id`, `city_id`, `state`, `close_follow`, `close_date`, `close_month`, `close_date_2`, `close_month_2`, `close_type`, `close_review`, `contact_review`, `support_review`) VALUES
(1, '1570485600', '10-2019', '1570908953', 2, 2, 0, 1, 1, 8, 'تم تحرير طلب', 8, 0, 0, 0, 0, 0, 0, NULL, 1, '1571004000', '1571045400', 3, 2, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1570658400', '10-2019', 0, 0, 0, 0, 0, 0, 22, 5, 0, NULL, NULL, '1570831200', '10-2019', 1, 0, 1, 0),
(2, '1570485600', '10-2019', '1572198560', 2, 2, 0, 1, 2, 5, 'طلب اكواب ورقية كود العميل 102721', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 2, 1, 0, '', '', 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1571522400', '10-2019', 0, 0, 0, 0, 0, 0, 9, 5, 0, NULL, NULL, '1572127200', '10-2019', 1, 0, 1, 0),
(3, '1570572000', '10-2019', '1573746085', 1, 1, 0, 1, 3, 5, 'حصل قبل كده واتصلت بيه وبعتله الاسعار ع الواتس ومردش عليا تانى\r\nاتصلت بيه من حوالى يومين بعد ما هو اتصل بيا وقال انه كان عنده ظروف شخصيه لعدم الرد\r\nقولتله انى هعمل ابديت للاسعار وابعتهاله تانى', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(4, '1570572000', '10-2019', '1570976740', 2, 1, 0, 1, 4, 2, 'تم الاتصال يالعميل والتاكيد', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1570572000', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 5, 5, 0, '1570831200', '10-2019', '1570917600', '10-2019', 3, 0, 1, 0),
(5, '1570572000', '10-2019', '1573583942', 1, 1, 0, 1, 5, 5, 'تم الرد من قبل العميل \r\nولا يرغب فى المتابعه', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573682400', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 5, 0, '1573509600', '11-2019', '1573509600', '11-2019', 3, 0, 1, 0),
(6, '1570572000', '10-2019', '1571563439', 1, 1, 0, 1, 6, 8, 'تم التواصل مع العميل ولم يتم الرد وجارى المتابعة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 26, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(7, '1570572000', '10-2019', '1572363044', 1, 1, 0, 1, 7, 8, 'تم الاتصال بالعميل عن طريق Face\r\nوتم ارسال كافه الصور \r\nاستاذ محمد انور كان ارسل لها كافة الاسعار \r\nوتقيمى انها فعلا باحثة عن سعر فقط تم ارسال الصور حسب رغبتها', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 27, 5, 0, '1572300000', '10-2019', '1572300000', '10-2019', 3, 0, 1, 0),
(8, '1570572000', '10-2019', '1571837872', 1, 1, 0, 1, 8, 10, 'هل تم متابعة العميل من قبل المندوب', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(9, '1570572000', '10-2019', '1570632296', 2, 2, 0, 1, 9, 10, 'تم تغير حالة الاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1570572000', '', 0, 3, 7, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1570572000', '10-2019', '1570572000', '10-2019', 2, 0, 1, 0),
(10, '1570572000', '10-2019', '1570630803', 1, 1, 0, 1, 10, 10, 'تم الاتصال بالعميل وميعاد مقابله ١ نوڤمبر لظروف سفر العميل والمجال توزيع لمحلات حدايد وبويات اسكوتش كريستال و دوكو', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572559200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(11, '1570658400', '10-2019', '1573296386', 1, 1, 0, 1, 11, 2, 'تم الاتصال بالعميل \r\nواضح انه خلال اسبوعين ممكن يطلب طلب لانه كان بالفعل كان اشترى بضاعة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(12, '1570658400', '10-2019', '1572297785', 1, 1, 0, 1, 12, 2, 'منافس', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 4, 4, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 14, 5, 0, '1572213600', '10-2019', '1572213600', '10-2019', 3, 0, 1, 0),
(13, '1570658400', '10-2019', '1572350844', 1, 1, 0, 1, 13, 8, 'العميل طالب باكو شريط عينة فى الزقازيق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 4, 5, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 18, 5, 0, '1572300000', '10-2019', '1572300000', '10-2019', 3, 0, 1, 0),
(14, '1570831200', '10-2019', '1570908846', 1, 1, 0, 1, 14, 6, 'فعلا تم التواصل مع العميل ومن الواضح ان الشخص اللى بيتكلم مش هو اللى رقم تليفونه معانا لذالك تم الاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1570831200', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1570831200', '10-2019', '1570831200', '10-2019', 3, 0, 1, 0),
(15, '1570831200', '10-2019', '1573744334', 1, 1, 0, 1, 15, 5, 'تم متابعة العميل مرة أخرى والتواصل معه كان بيسال ع الاسكوتش الكريستال والاستيك وتم تبليغه بالاسعار وفى انتظار الرد', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574287200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 6, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(16, '1570831200', '10-2019', '1573551632', 1, 1, 0, 1, 16, 9, 'تم تحرير طلب وكود العميل 102737', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572559200', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1573423200', '11-2019', 0, 0, 0, 0, 0, 0, 2, 5, 0, '', '', '1573509600', '11-2019', 1, 0, 1, 0),
(17, '1570831200', '10-2019', '1573302373', 2, 2, 0, 1, 17, 2, 'عند الاتصال بالعميل قال الرقم غلط', 8, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 3, 0, 1, 0),
(18, '1570831200', '10-2019', '1571233689', 1, 1, 0, 1, 18, 2, 'قمت بمحاولة الاتصال بالعميل اكثر من مره ولكن التليفون مغلق', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1570831200', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 5, 0, '1570917600', '10-2019', '1571176800', '10-2019', 3, 0, 1, 0),
(19, '1570831200', '10-2019', '1570965966', 2, 2, 0, 1, 19, 2, 'تم تسجيل العميل', 8, 0, 0, 0, 0, 0, 0, NULL, 1, '1571436000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1570917600', '10-2019', 0, 0, 0, 0, 0, 0, 2, 5, 0, NULL, NULL, '1570917600', '10-2019', 1, 0, 1, 0),
(20, '1570831200', '10-2019', '1572200002', 1, 1, 0, 1, 20, 9, 'تم التواصل على الفيس ولم يتم الرد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572300000', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 5, 0, '1571695200', '10-2019', '1572127200', '10-2019', 2, 0, 1, 0),
(21, '1570831200', '10-2019', '1571473357', 1, 1, 0, 1, 21, 5, 'تم التواصل مع العميل وتحديد ميعاد زيارة يوم الثلاثاء\r\nالقادم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(22, '1570917600', '10-2019', '1573572703', 1, 1, 0, 1, 22, 5, 'تم الاتصال بالعميل الهاتف مغلق تم ارسال رسالة على الفيس وفى انتظار الرد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573682400', '', 0, 2, 1, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(23, '1570917600', '10-2019', '1573296877', 2, 2, 0, 1, 23, 2, 'تم الاتصال بالعميل وتم المراجعة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(24, '1570917600', '10-2019', '1572199238', 2, 2, 0, 1, 24, 9, 'تم الاتصال بالعميل \r\nوتم التاكيد وبتشكر فى استاذ مينا بس هيا للاسف كان عندها ظروف \r\nوستقوم بالاتصال لاحقا بنا', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571436000', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1571608800', '10-2019', '1572127200', '10-2019', 3, 0, 1, 0),
(25, '1570917600', '10-2019', '1572353510', 2, 2, 0, 1, 25, 2, 'تم تحرير الطلب كود العميل 102728', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572040800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1572300000', '10-2019', 0, 0, 0, 0, 0, 0, 14, 5, 0, NULL, NULL, '1572300000', '10-2019', 1, 0, 1, 0),
(26, '1571004000', '10-2019', '1571139101', 2, 2, 0, 1, 26, 5, 'رقم العميل  : 102714', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571004000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1571004000', '10-2019', 0, 0, 0, 0, 0, 0, 11, 5, 0, NULL, NULL, '1571090400', '10-2019', 1, 0, 1, 0),
(27, '1571004000', '10-2019', '1571582100', 2, 2, 0, 1, 27, 2, 'تم الاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 4, 8, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1571436000', '10-2019', '1571522400', '10-2019', 3, 0, 1, 0),
(28, '1571004000', '10-2019', '1571234388', 1, 1, 0, 1, 28, 8, 'اعاده فتح التذكرة للمتابعة بعد توفير مندوب مبيعات لغرب الاسكندرية', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1571004000', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1571090400', '10-2019', '1571176800', '10-2019', 2, 0, 1, 0),
(29, '1571004000', '10-2019', '1571582091', 1, 1, 0, 1, 29, 10, 'تم الاغلاق', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1571004000', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1571436000', '10-2019', '1571522400', '10-2019', 3, 0, 1, 0),
(30, '1571004000', '10-2019', '1571474089', 1, 1, 0, 1, 30, 10, 'تم التواصل معاه وتحديد اتصال اخر بعد أسبوع عشان مش فاضي بيوضب مقر شركه له جديد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572040800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(31, '1571004000', '10-2019', '1572868272', 1, 1, 0, 1, 31, 9, 'تم الاتصال والتاكيد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 6, 5, 0, '1572818400', '11-2019', '1572818400', '11-2019', 3, 0, 1, 0),
(32, '1571004000', '10-2019', '1573297485', 1, 1, 0, 1, 32, 2, 'تم الاتصال بالعميل وهو عميل غير جاد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 3, 0, 1, 0),
(33, '1571004000', '10-2019', '1571473976', 1, 1, 0, 1, 33, 5, 'تم التواصل مع العميل واستفسر عن اسعار الكلينج الغذائى واسعار الاكواب الكرتون وسيتم ارسال الاسعار ع الواتس اب', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(34, '1571090400', '10-2019', '1572867420', 1, 1, 0, 1, 34, 9, 'تم الاتصال وارسال رسالة على الفيس للاغلاق \r\nفعلا العميل غير جاد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 23, 5, 0, '1572818400', '11-2019', '1572818400', '11-2019', 3, 0, 1, 0),
(35, '1571090400', '10-2019', '1572198815', 1, 1, 0, 1, 35, 9, 'تم الاتصال بالعميل وفعلا لم يكن هناك رد', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1571868000', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 5, 0, '1572040800', '10-2019', '1572127200', '10-2019', 3, 0, 1, 0),
(36, '1571090400', '10-2019', '1573390592', 1, 1, 0, 1, 36, 9, 'الاغلاق لعدم الايداع \r\n------------------------------------------\r\nتم الاتصال بالعميل وابلغنا انه لم يتم التواصل معاه بخصوص الايداع\r\nوانه لم يتم تحديد الاتفاق النهائى لكى يتم الايداع\r\nوانه يرغب جديا فى التعامل قد تكون الكمية صغيرة ولكنه يرغب التعاون\r\nبرجاء المراجعة والتواصل مع العميل', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573336800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(37, '1571090400', '10-2019', '1573318186', 1, 1, 0, 1, 37, 9, 'تم الاتصال لا يرد \r\nوتم ارسال رسالة الفيس', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 27, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 3, 0, 1, 0),
(38, '1571090400', '10-2019', '1573392837', 1, 1, 0, 1, 38, 9, 'كان عنده مشكلة فى شركة الشحن وتم حلها\r\nوبعد اتمام الطلب لم يقم بالايداع\r\nبيقول انه بيعمل عمره', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573077600', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 26, 5, 0, '1573336800', '11-2019', '1573336800', '11-2019', 2, 0, 1, 0),
(39, '1571176800', '10-2019', '1573298086', 2, 2, 0, 1, 39, 2, 'تم الاتصال ولم يرد\r\nوتم ارسال رسالة على الفيس تفيد اغلاق المتابعة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 3, 0, 1, 0),
(40, '1571176800', '10-2019', '1572708907', 3, 3, NULL, 3, 28, 12, 'لم يتم تعيين موظف مبيعات للمنطقة حتى الان', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(41, '1571176800', '10-2019', '1573298435', 2, 2, 0, 1, 40, 2, 'تم الاتصال بالعميل \r\nابدى امكانية التعاون فى القريب العاجل', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(42, '1571176800', '10-2019', '1572867823', 2, 2, 0, 1, 41, 9, 'تم الاتصال والتاكيد على العميل', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1572818400', '11-2019', '1572818400', '11-2019', 3, 0, 1, 0),
(43, '1571522400', '10-2019', '1571651234', 2, 2, 0, 1, 42, 8, 'تم التواصل مع العميل وتحديد الطلبية وف انتظار الايداع البنكى \r\nلتحرير الطلب', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572040800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(44, '1571522400', '10-2019', '1571651305', 2, 2, 0, 1, 43, 8, 'تم التواصل مع العميل والرد على استفساراته \r\nومهتم بالمسدس \r\nوف انتظار وصول طلبية المسدس', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(45, '1571522400', '10-2019', '1573298984', 2, 2, 0, 1, 44, 2, 'تم الاتصال بالعميل\r\nواعتذر عن عدم امكانيه المتابعه لضايع الرقم الخاص باستاذ محمد خميس\r\nتم ارسال الرقم الخاص باستاذ محمد وسيقوم العميل بالاتصال\r\nبرجاء تحديث التذكره فى حالة الاتصال من العميل', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(46, '1571608800', '10-2019', '1572708690', 2, 2, 0, 1, 45, 13, 'تم ارسال رسالة على الفيس وتم اغلاق التذكره', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1572645600', '11-2019', '1572645600', '11-2019', 3, 0, 1, 0),
(47, '1571608800', '10-2019', '1572297762', 2, 2, 0, 1, 46, 6, 'طلب وكاله ولا توجد امكانيات', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572559200', '', 0, 4, 5, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1572213600', '10-2019', '1572213600', '10-2019', 3, 0, 1, 0),
(48, '1571781600', '10-2019', '1572789004', 2, 2, 0, 1, 47, 6, 'تمت المتابعة اليوم أ.ميران قالت انها كلمت المهندس و لم يرد عليها حتى الان و لو فى نصيب ان شاء الله حتتصل بيا و تم عرض اصناف اخرى للتعامل معنا فى اى صنف', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 3, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1572732000', '11-2019', '1572732000', '11-2019', 2, 0, 1, 0),
(49, '1572127200', '10-2019', '1573573199', 2, 2, 0, 1, 48, 5, 'تم الاتصال بالعميل\r\nواوضح انه لم يتم ارسال الاسعار على الوتس\r\nما هو سبب الارشفة والاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573682400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(50, '1572213600', '10-2019', '1572342630', 2, 2, 0, 1, 49, 6, 'كود العميل 102726', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572213600', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1572213600', '10-2019', 0, 0, 0, 0, 0, 0, 3, 5, 0, NULL, NULL, '1572300000', '10-2019', 1, 0, 1, 0),
(51, '1572300000', '10-2019', '1572339076', 1, 1, 0, 1, 50, 9, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572300000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(52, '1572300000', '10-2019', '1573299882', 2, 2, 0, 1, 51, 2, 'تم الاتصال بالعميل ولم يرد \r\nوتم ارسال رسالة على الفيس تفيد الاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573250400', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(53, '1572300000', '10-2019', '1573573485', 1, 1, 0, 1, 52, 5, 'تم التواصل مع العميل\r\nوالامكانية ضعيفة للعميل\r\nسيتم الاغلاق', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572300000', '', 0, 4, 5, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 5, 0, '1573509600', '11-2019', '1573509600', '11-2019', 3, 0, 1, 0),
(54, '1572300000', '10-2019', '1572773022', 1, 1, 0, 1, 53, 6, 'هو فى المقابلة الناس جادين لكن الطلبية حتكون فى خلال شهر تقريبا لأنهم بيشترو كل فترة ٣٠ كرتونة و لسه عندهم شغل قديم فى المخزن يخلص و يطلبة شغل تانى من عندنا', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1575151200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(55, '1572300000', '10-2019', '1572357271', 1, 1, 0, 1, 54, 5, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572300000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(56, '1572386400', '10-2019', '1572430151', 1, 1, 0, 1, 55, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572386400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(57, '1572386400', '10-2019', '1573300155', 2, 2, 0, 1, 56, 2, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب \r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572386400', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 14, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(58, '1572386400', '10-2019', '1573570015', 2, 2, 0, 1, 57, 9, 'تم الاتصال بالعميل\r\nولا يوجد تعليق من العميل\r\nوتم التاكيد على اغلاق طلب المتابعة', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572386400', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 18, 5, 0, '1573509600', '11-2019', '1573509600', '11-2019', 3, 0, 1, 0),
(59, '1572472800', '10-2019', '1573571483', 1, 1, 0, 1, 58, 9, 'تم الاتصال بالعميل مرة اخرى وعرض المسدس والشمع بعد تفعيل العرض', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 10, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(60, '1572472800', '10-2019', '1572517755', 1, 1, 0, 1, 59, 5, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 24, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(61, '1572472800', '10-2019', '1573389852', 1, 1, 0, 1, 60, 2, 'تم الرد من العميل\r\nوتم ارسال رقم حضرتك وهيتواصل مع حضرتك\r\nهو بيقول انه كان بيتعامل قبل كده وموقف نشاط وبيرجعه\r\nحضرتك لو اتصل بيك بلغنا', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(62, '1572472800', '10-2019', '1573301845', 1, 1, 0, 1, 61, 2, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب\r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(63, '1572472800', '10-2019', '1573300871', 1, 1, 0, 1, 62, 2, 'تم الاتصال بالعميل وسأل علي الأصناف الشمع والاستيك وورق الهدايا والسوليتب المكتبي وعايز قايمه بالأسعار علي الواتس وجاري تنفيذها للعميل وارسالها', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(64, '1572472800', '10-2019', '1573295741', 1, 1, 0, 1, 63, 2, 'تم الاتصال من قبل استاذ محمد انور وابلغنا انه منافس \r\nوطلب عدم المتابعة على ان يقوم هو بالمتابعة', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 4, 4, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 3, 0, 1, 0),
(65, '1572472800', '10-2019', '1573571430', 1, 1, 0, 1, 64, 9, 'تم الاتصال بالعميل وعرض اصناف الاسكوتش والمسدس والاستيك والشمع والمكتبي عن طريق الواتس', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 18, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(66, '1572472800', '10-2019', '1572518353', 1, 1, 0, 1, 65, 9, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572472800', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 27, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(67, '1572472800', '10-2019', '1572873428', 1, 1, 0, 1, 66, 9, 'تم الاتصال بالعميل وعرض اصناف الاسكوتش الجرين 60و80و100و150 وتم عرض الفويل والشريط وشغال مع الصمدى ومحمد خالد والخواجه وشركة الشحن اللي بيتعامل معها الزهور وفي نية للتعامل في الاسكوتش ويوجد زيارة من اخيه اسمه محمد العجمي لفرع الشركة في بحرى عن قريب', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573077600', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 8, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(68, '1572732000', '11-2019', '1573550562', 1, 1, 0, 1, 67, 6, 'تم التواصل عى الفيس وشاف الرسالة ولم يرد', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573077600', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1573509600', '11-2019', '1573509600', '11-2019', 3, 0, 1, 0),
(69, '1572732000', '11-2019', '1573571207', 1, 1, 0, 1, 68, 9, 'تم التواصل مع العميل بالاتصال ثم الواتس وارسال اسعار السلوتيب الكريستال والايفر', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(70, '1572732000', '11-2019', '1573300519', 2, 2, 0, 1, 69, 2, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب \r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 20, 5, 0, '1573250400', '11-2019', '1573250400', '11-2019', 2, 0, 1, 0),
(71, '1572732000', '11-2019', '1572769378', 2, 2, 0, 1, 70, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(72, '1572732000', '11-2019', '1573127086', 1, 1, 0, 1, 71, 8, 'تم ارسال رسالة على الفيس وتم اغلاق التذكره', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 25, 5, 0, '1572904800', '11-2019', '1573077600', '11-2019', 3, 0, 1, 0),
(73, '1572732000', '11-2019', '1572775174', 1, 1, 0, 1, 72, 10, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1572732000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(74, '1572818400', '11-2019', '1572857997', 2, 2, 0, 1, 73, 9, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572818400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 6, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(75, '1572818400', '11-2019', '1573301365', 2, 2, 0, 1, 74, 2, 'ننتظر تحديث الحاله', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573855200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 26, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(76, '1572818400', '11-2019', '1572867461', 1, 1, 0, 1, 75, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1572818400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(77, '1572818400', '11-2019', '1573744154', 1, 1, 0, 1, 76, 9, 'تم تحرير طلب رقم العميل 102737', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573077600', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1573682400', '11-2019', 0, 0, 0, 0, 0, 0, 6, 5, 0, NULL, NULL, '1573682400', '11-2019', 1, 0, 1, 0),
(78, '1573250400', '11-2019', '1573570471', 1, 1, 0, 1, 77, 9, 'تم التواصل مع العميل المطلوب اسكوتش مطبوع', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 18, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(79, '1573336800', '11-2019', '1573570218', 1, 1, 0, 1, 78, 13, 'تم التواصل على الفيس\r\nوتم اغلاق التذكرة', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573336800', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1573509600', '11-2019', '1573509600', '11-2019', 3, 0, 1, 0),
(80, '1573336800', '11-2019', '1574520595', 1, 1, 0, 1, 79, 2, 'تم التواصل من قبل العميل من حساب اخر \r\nرقم الحساب \r\n100006851108112\r\nتم اضافة المتابعة على ترلو \r\nنرجو التواصل مع العميل\r\nوتحديد جدية العميل فى التعامل\r\nوشكرا', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 14, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(82, '1573941600', '11-2019', '1574790459', 2, 2, 0, 1, 81, 9, 'تم اغلاق التذكرة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1573941600', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 13, 5, 0, '1574719200', '11-2019', '1574719200', '11-2019', 3, 0, 1, 0),
(83, '1573941600', '11-2019', '1574790451', 1, 1, 0, 1, 82, 9, 'تم اغلاق التذكرة', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1573941600', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1574719200', '11-2019', '1574719200', '11-2019', 3, 0, 1, 0),
(84, '1574028000', '11-2019', '1574790443', 2, 2, 0, 1, 83, 9, 'تم اغلاق التذكرة', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574028000', '', 0, 4, 9, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 0, '1574719200', '11-2019', '1574719200', '11-2019', 3, 0, 1, 0),
(85, '1574114400', '11-2019', '1574239676', 2, 2, 0, 1, 84, 6, 'كود العميل 102745', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 1, '1574114400', '11-2019', 0, 0, 0, 0, 0, 0, 3, 5, 0, NULL, NULL, '1574200800', '11-2019', 1, 0, 1, 0),
(86, '1574114400', '11-2019', '1574240052', 2, 2, 0, 1, 85, 6, 'باحث عن سعر فقط', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574114400', '', 0, 4, 3, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1574200800', '11-2019', '1574200800', '11-2019', 3, 0, 1, 0),
(87, '1574460000', '11-2019', '1574517490', 1, 1, 0, 1, 86, 8, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 4, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(88, '1574460000', '11-2019', '1574517894', 1, 1, 0, 1, 87, 9, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(89, '1574460000', '11-2019', '1574519563', 2, 2, 0, 1, 88, 10, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 22, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(90, '1574460000', '11-2019', '1574519395', 2, 2, 0, 1, 89, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(91, '1574460000', '11-2019', '1574523009', 1, 1, 0, 1, 90, 5, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 15, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(92, '1574460000', '11-2019', '1574625685', 1, 1, 0, 1, 91, 6, 'تم التواصل مع العميل واغلاق التذكرة', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 3, 6, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1574546400', '11-2019', '1574546400', '11-2019', 2, 0, 1, 0),
(93, '1574460000', '11-2019', '1574536138', 1, 1, 0, 1, 92, 9, 'اضافة متابعة اليوم', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1574460000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 10, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(94, '1574892000', '11-2019', '1575383297', 2, 2, 0, 1, 93, 6, 'تسجيل بيانات بالخطاء', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574892000', '', 0, 4, 8, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 3, 5, 0, '1575324000', '12-2019', '1575324000', '12-2019', 3, 0, 1, 0),
(95, '1574892000', '11-2019', '1574929728', 2, 2, 0, 1, 94, 9, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1574892000', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(96, '1575151200', '12-2019', '1575214575', 1, 1, 0, 1, 95, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1575151200', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 9, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(97, '1575237600', '12-2019', '1575271381', 1, 1, 0, 1, 96, 5, 'اضافة متابعة اليوم', 7, 0, 0, 0, 0, 0, 0, NULL, 1, '1575237600', '', 0, 2, 0, 0, NULL, NULL, 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 11, 2, 0, NULL, NULL, NULL, NULL, 0, 0, 1, 0),
(98, '1695592800', '9-2023', '1695633885', 1, 1, 0, 1, 97, 7, 'تعليق خدمة العملاء', 1, 0, 0, 0, 0, 0, 0, NULL, 1, '1695592800', '', 1, 3, 7, 1, '1695592800', '9-2023', 0, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 0, 0, 0, 0, 0, 2, 5, 1, '1695592800', '9-2023', '1695592800', '9-2023', 2, 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sales_ticket_des`
--

CREATE TABLE `sales_ticket_des` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `cust_id` int(11) DEFAULT '0',
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ticket_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_date` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `follow_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `priority_id` int(11) DEFAULT '0',
  `follow_type` int(11) DEFAULT '0',
  `follow_state` int(11) DEFAULT '0',
  `des` text COLLATE utf8_unicode_ci,
  `user_id` int(11) DEFAULT '0',
  `user_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `add_type` int(11) DEFAULT '0',
  `count_type` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `sales_ticket_des`
--

INSERT INTO `sales_ticket_des` (`id`, `cat_id`, `cust_id`, `date_add`, `ticket_date`, `date_time`, `date_month`, `follow_date`, `follow_time`, `priority_id`, `follow_type`, `follow_state`, `des`, `user_id`, `user_name`, `add_type`, `count_type`) VALUES
(1, 1, 1, '1570528840', '1570485600', '1570528840', '10-2019', '', NULL, 0, 0, 2, 'مهتم بالدبل فيس 9 مللى \r\nاسكوتش 7 سم \r\nاستريتش صناعى \r\nصمغ سائل', 8, 'هادى ابراهيم', 0, 1),
(2, 1, 1, '1570485600', '1570485600', '1570529101', '10-2019', '1570485600', '1570534200', 3, 128, 1, 'الاستفسار عن دبل فيس 9 مللى \r\nواسكوتش 7 سم', 8, 'هادى ابراهيم', 0, 2),
(3, 2, 2, '1570531792', '1570485600', '1570531792', '10-2019', '', NULL, 0, 0, 2, 'الاستفسار عن \r\nالفويل – اكواب ساخن \r\nالاسكوتش \r\nالاسترتش المنزلى والمستورد والمصرى \r\nاطباق الفويل \r\nالملاعق والشوك', 7, 'اسماء محمد', 0, 1),
(4, 2, 2, '1570485600', '1570485600', '1570531840', '10-2019', '1570572000', '', 3, 131, 1, 'الاستفسار عن \r\nالفويل – اكواب ساخن \r\nالاسكوتش \r\nالاسترتش المنزلى والمستورد والمصرى \r\nاطباق الفويل \r\nالملاعق والشوك', 7, 'اسماء محمد', 0, 2),
(5, 7, 7, '1570611417', '1570572000', '1570611417', '10-2019', '', NULL, 0, 0, 2, 'ايمان\r\n01154006829\r\nمكتبة الخديوى\r\nالمنيا - مركز العدوه\r\nبلاستر واسترتش وممكن فويل', 7, 'اسماء محمد', 0, 1),
(6, 7, 7, '1570572000', '1570572000', '1570611539', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(7, 6, 6, '1570611410', '1570572000', '1570611410', '10-2019', '', NULL, 0, 0, 2, 'احمد كمال\r\n01016560092\r\nتجاره ادوات مكتبيه جمله الجمله -المنوفيه', 7, 'اسماء محمد', 0, 1),
(8, 6, 6, '1570572000', '1570572000', '1570611554', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(9, 5, 5, '1570611393', '1570572000', '1570611393', '10-2019', '', NULL, 0, 0, 2, 'محتاج اعرف اسعار السولتيب الكريستال بمقاساته والشيكرتون واللصق المطبوع\r\nمحمودمحي\r\n01011536020\r\nتوزيع\r\nدمياط', 7, 'اسماء محمد', 0, 1),
(10, 5, 5, '1570572000', '1570572000', '1570611561', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(11, 4, 4, '1570611385', '1570572000', '1570611385', '10-2019', '', NULL, 0, 0, 2, 'تاجر جملة بعربية مقغله\r\nبس قبل كده اشتريت المسدس جملة من القاهرة  من درب البرابره', 7, 'اسماء محمد', 0, 1),
(12, 4, 4, '1570572000', '1570572000', '1570611568', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(13, 3, 3, '1570611376', '1570572000', '1570611376', '10-2019', '', NULL, 0, 0, 2, 'انا شغل في معضم الشغل عتمان\r\nالسلتب مسدس الشمع  الشمع الا زواك\r\nمع ناس موزيعين بس انا عايز اوزع\r\nحماده ماجور\r\nمحافظة كفرالشيخ مركز فوه', 7, 'اسماء محمد', 0, 1),
(14, 3, 3, '1570572000', '1570572000', '1570611574', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(15, 1, 1, '1570572000', '1570485600', '1570612186', '10-2019', '1571004000', '1571045400', 3, 128, 1, 'سيتم عمل الايداع وبعد الايداع سيتم ارسال البضاعة إلى العميل', 8, 'هادى ابراهيم', 0, 2),
(16, 8, 8, '1570614989', '1570572000', '1570614989', '10-2019', '', NULL, 0, 0, 2, 'Drmahmoud ELghazaly\r\nشركة ماركتوفا فارما\r\nستيكر مطبوع', 7, 'اسماء محمد', 0, 1),
(17, 8, 8, '1570572000', '1570572000', '1570615034', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(18, 9, 9, '1570625303', '1570572000', '1570625303', '10-2019', '', NULL, 0, 0, 2, 'الاستفسار عن الاسكوتش المطبوع \r\nالقاهرة - المعادى الجديدة', 7, 'اسماء محمد', 0, 1),
(19, 9, 9, '1570572000', '1570572000', '1570625342', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(20, 10, 10, '1570628446', '1570572000', '1570628446', '10-2019', '', NULL, 0, 0, 2, 'ابداع للأستيراد والتجاره\r\nIbrahim Abo Arab\r\nكفر الشيخ- بلطيم - القاهره- مدينة نصر - سوهاج- اخميم \r\nلزق كريستال\r\nكفر الشيخ\r\nبلطيم المنطقه الصناعيه', 7, 'اسماء محمد', 0, 1),
(21, 10, 10, '1570572000', '1570572000', '1570628513', '10-2019', '1570572000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(22, 2, 2, '1570572000', '1570485600', '1570628776', '10-2019', '1570658400', '', 0, 128, 1, 'الرد على استفسارات العميل', 7, 'اسماء محمد', 0, 2),
(23, 10, 10, '1570572000', '1570572000', '1570629933', '10-2019', '1570658400', '', 0, 128, 1, 'الرد على استفسارات العميل', 7, 'اسماء محمد', 0, 2),
(24, 3, 3, '1570572000', '1570572000', '1570629992', '10-2019', '1570658400', '', 0, 128, 1, 'الرد على استفسارات العميل', 7, 'اسماء محمد', 0, 2),
(25, 5, 5, '1570572000', '1570572000', '1570630113', '10-2019', '1570658400', '', 0, 128, 1, 'التواصل مع العميل', 7, 'اسماء محمد', 0, 2),
(26, 8, 8, '1570572000', '1570572000', '1570630315', '10-2019', '1570658400', '', 0, 129, 1, 'تم التواصل مع العميل وارسال السعر المطلوب له', 7, 'اسماء محمد', 0, 2),
(27, 10, 10, '1570572000', '1570572000', '1570630803', '10-2019', '1572559200', '', 0, 132, 1, 'تم الاتصال بالعميل وميعاد مقابله ١ نوڤمبر لظروف سفر العميل والمجال توزيع لمحلات حدايد وبويات اسكوتش كريستال و دوكو', 7, 'اسماء محمد', 0, 2),
(28, 9, 9, '1570572000', '1570572000', '1570631376', '10-2019', '1570572000', '', 0, 128, 1, 'تم التواصل مع العميل ويريد التعامل فى اصناف ليست متوفرة فى الشركة وهى الطباعة على الاسكوتش ميلك', 7, 'اسماء محمد', 0, 2),
(29, 9, 9, '1570572000', '1570572000', '1570631453', '10-2019', NULL, NULL, 0, 0, 0, 'لعدم توافر المنتج المطلوب من العميل', 7, 'اسماء محمد', 0, 2),
(30, 9, 9, '1570572000', '1570572000', '1570632296', '10-2019', NULL, NULL, 0, 0, 0, 'تم تغير حالة الاغلاق', 1, 'مدير الموقع', 0, 3),
(31, 2, 2, '1570572000', '1570485600', '1570634800', '10-2019', '1570658400', '', 0, 128, 1, 'تم التواصل مع المندوب وسوف يتواصل مع العميل غدا', 7, 'اسماء محمد', 0, 2),
(32, 3, 3, '1570572000', '1570572000', '1570634835', '10-2019', '1570658400', '', 0, 128, 1, 'تم التواصل مع المندوب وسوف يتواصل مع العميل غدا', 7, 'اسماء محمد', 0, 2),
(33, 5, 5, '1570572000', '1570572000', '1570634970', '10-2019', '1570658400', '', 0, 128, 1, 'تم التواصل مع المندوب وسوف يتواصل مع العميل غدا', 7, 'اسماء محمد', 0, 2),
(34, 12, 12, '1570697396', '1570658400', '1570697396', '10-2019', '', NULL, 0, 0, 2, 'الحسيني الفداوي‎\r\n01005533224\r\nاسترتش مصرى  وكورى - سلفر بانواعه\r\nفوم- اطباق حرارى\r\nالدقهليه', 7, 'اسماء محمد', 0, 1),
(35, 12, 12, '1570658400', '1570658400', '1570697460', '10-2019', '1570658400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(36, 11, 11, '1570697392', '1570658400', '1570697392', '10-2019', '', NULL, 0, 0, 2, 'الاستفسار عن \r\nسلوتيب - استيريتش غذائي\r\nالغربيه - ٠١٢٠٠٦٦٦١٠٦', 7, 'اسماء محمد', 0, 1),
(37, 11, 11, '1570658400', '1570658400', '1570697580', '10-2019', '1570658400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(38, 1, 1, '1570658400', '1570485600', '1570707777', '10-2019', '', NULL, 0, 0, 0, 'طلب العميل ( دبل فيس )', 7, 'اسماء محمد', 4, 2),
(39, 13, 13, '1570718249', '1570658400', '1570718249', '10-2019', '', NULL, 0, 0, 2, 'كان حد كلمني وقالي هيبعتلي مندوب بالعينات\r\nانا مصنع لاطباق الحلويات\r\nكنت عايزة الشريط الحلواني\r\nمنة ابو سنة 01274225512\r\nمن ١ ل ٩', 7, 'اسماء محمد', 0, 1),
(40, 13, 13, '1570658400', '1570658400', '1570718551', '10-2019', '1570658400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(41, 14, 14, '1570875848', '1570831200', '1570875848', '10-2019', '', NULL, 0, 0, 2, 'ده رقم الحج خالد الميلادي\r\nالاسم التجاري\r\nخالد الميلادي لتجاره الحدايد والبويات بالجمله\r\nالعنوان خلف 317ش مصطفي كامل غبريال اسكندريه\r\nشارع الجمرك القديم سابقا', 7, 'اسماء محمد', 0, 1),
(42, 14, 14, '1570831200', '1570831200', '1570875873', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(43, 15, 15, '1570875853', '1570831200', '1570875853', '10-2019', '', NULL, 0, 0, 2, 'احمد عثمان\r\n01097050616\r\nاسيوط\r\nالمنتجات استك نقديه سولتيب كبير ومكتبات خردوات  وياريت لسته بكل منتجاتكم وانا اختار اللى يناسبنى', 7, 'اسماء محمد', 0, 1),
(44, 15, 15, '1570831200', '1570831200', '1570875921', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(46, 3, 3, '1570831200', '1570572000', '1570877797', '10-2019', '1571004000', '', 0, 128, 1, 'تم الاتصال بالعميل من قبل المندوب وجار المتابعة مع العميل', 7, 'اسماء محمد', 0, 2),
(47, 12, 12, '1570831200', '1570658400', '1570880845', '10-2019', '1571004000', '', 0, 128, 1, 'تم التواصل مع العميل وعنوانه المنزلة محافظة الدقهلية وعميل لدى عافية بلاست', 7, 'اسماء محمد', 0, 2),
(48, 14, 14, '1570831200', '1570831200', '1570880965', '10-2019', NULL, NULL, 0, 0, 0, 'تم بالفعل التواصل مع العميل ولا يريد التعامل مع الشركة', 7, 'اسماء محمد', 0, 2),
(49, 2, 2, '1570831200', '1570485600', '1570881037', '10-2019', '1571090400', '', 0, 128, 1, 'تم بالفعل التواصل مع العميل وتحديد موعد للزيارة يوم الثلاثاء', 7, 'اسماء محمد', 0, 2),
(50, 4, 4, '1570831200', '1570572000', '1570881665', '10-2019', NULL, NULL, 0, 0, 0, 'تم التواص مع العميل وعنوانه اسوان و استفسر عن مسدس الشمع فقط \r\nوغير متخصص ( فكرة عن الاسعار فقط )', 7, 'اسماء محمد', 0, 2),
(51, 5, 5, '1570831200', '1570572000', '1570881737', '10-2019', '1571004000', '', 0, 129, 1, 'تم التواصل مع العميل وجارى المتابعة على الواتس اب', 7, 'اسماء محمد', 0, 2),
(52, 11, 11, '1570831200', '1570658400', '1570881816', '10-2019', '1571004000', '', 0, 128, 1, 'تم التواصل مع العميل وجارى المتابعة على رسائل الواتس اب', 7, 'اسماء محمد', 0, 2),
(53, 8, 8, '1570831200', '1570572000', '1570881897', '10-2019', '1570917600', '', 0, 128, 1, 'تم التواصل مع العميل وارسال السعر المطلوب له', 7, 'اسماء محمد', 0, 2),
(54, 15, 15, '1570831200', '1570831200', '1570881951', '10-2019', '1571004000', '', 0, 128, 1, 'تم التواصل مع المندوب وسوف يتم التواصل مع العميل', 7, 'اسماء محمد', 0, 2),
(55, 16, 16, '1570884557', '1570831200', '1570884557', '10-2019', '', NULL, 0, 0, 2, 'ممكن أعرف اسعار\r\nفويل الألومنيوم', 1, 'مدير الموقع', 0, 1),
(56, 16, 16, '1570831200', '1570831200', '1570884620', '10-2019', '1570831200', '', 0, 128, 1, 'تم الاتصال بالعميل من قبل مينا وتم تحديد ميعاد للزيارة ولم تتم الزيارة برجاء المراجعة', 1, 'مدير الموقع', 0, 2),
(57, 17, 17, '1570884886', '1570831200', '1570884886', '10-2019', '', NULL, 0, 0, 2, 'العياط شارع الجيش \r\nالايداع قبل تحرير الطلب (حسب اتفاق خدمة العملاء مع العميل)\r\nمهتم بالأستك الزراعى مطلوب 1 طن', 8, 'هادى ابراهيم', 0, 1),
(58, 17, 17, '1570831200', '1570831200', '1570884927', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 8, 'هادى ابراهيم', 0, 2),
(59, 18, 18, '1570885519', '1570831200', '1570885519', '10-2019', '', NULL, 0, 0, 2, 'اشرف محمد‎\r\nادكو بحيرة\r\n01150020158\r\nسعر استك الزراع كام', 1, 'مدير الموقع', 0, 1),
(60, 18, 18, '1570831200', '1570831200', '1570885531', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(61, 19, 19, '1570892115', '1570831200', '1570892115', '10-2019', '', NULL, 0, 0, 2, 'مكان العميل فى المعادى \r\nمهتم بالاستك \r\nمطلوب 300 كيلو وقابل للزيادة', 8, 'هادى ابراهيم', 0, 1),
(62, 19, 19, '1570831200', '1570831200', '1570892134', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 8, 'هادى ابراهيم', 0, 2),
(63, 14, 14, '1570831200', '1570831200', '1570908846', '10-2019', NULL, NULL, 0, 0, 0, 'فعلا تم التواصل مع العميل ومن الواضح ان الشخص اللى بيتكلم مش هو اللى رقم تليفونه معانا لذالك تم الاغلاق', 1, 'مدير الموقع', 0, 3),
(64, 1, 1, '1570831200', '1570485600', '1570908953', '10-2019', NULL, NULL, 0, 0, 0, 'تم تحرير طلب', 1, 'مدير الموقع', 0, 3),
(65, 21, 21, '1570909120', '1570831200', '1570909120', '10-2019', '', NULL, 0, 0, 2, 'البحيرة\r\nممكن مندوب المحافظة\r\n01000292012\r\nمكتبه توزيع', 1, 'مدير الموقع', 0, 1),
(66, 21, 21, '1570831200', '1570831200', '1570909142', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(67, 20, 20, '1570909113', '1570831200', '1570909113', '10-2019', '', NULL, 0, 0, 2, 'الجيزة\r\nاحمد ناصر\r\n01006599166\r\nالأدوات الزراعة\r\nالاستفسار عن الاستيك', 1, 'مدير الموقع', 0, 1),
(68, 20, 20, '1570831200', '1570831200', '1570909604', '10-2019', '1570831200', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(69, 19, 19, '1570831200', '1570831200', '1570910173', '10-2019', '1571436000', '', 0, 129, 1, 'طلب الشغل وبعتله رقم حساب البنك علي الواتس ننتظر اتمام الايداع', 1, 'مدير الموقع', 0, 2),
(70, 11, 11, '1570831200', '1570658400', '1570910267', '10-2019', '1571954400', '', 0, 128, 1, 'جاري المتابعة مع العميل', 1, 'مدير الموقع', 0, 2),
(71, 17, 17, '1570831200', '1570831200', '1570910339', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل وعرض السعر عليه وفي انتظار الرد', 1, 'مدير الموقع', 0, 2),
(72, 12, 12, '1570831200', '1570658400', '1570910397', '10-2019', '1572472800', '', 0, 128, 1, 'تاريخ المتابعة القادمة', 1, 'مدير الموقع', 0, 2),
(73, 18, 18, '1570917600', '1570831200', '1570952589', '10-2019', NULL, NULL, 0, 0, 0, 'حنشيله في الأرشيف', 1, 'مدير الموقع', 0, 2),
(74, 22, 22, '1570954271', '1570917600', '1570954271', '10-2019', '', NULL, 0, 0, 2, 'Amr Ahmed\r\nعمرو أحمد فرج\r\nموبايل ٠١٢٧١٢٣٢٤١٢\r\nأتمنى وأود التكرم بأن يتواصل معى مندوب حضراتكم بصفة مؤقتة\r\nطيب مين بيأخذ منتجاتكم فى القاهرة علشان اتعامل معاه من فضلك', 1, 'مدير الموقع', 0, 1),
(76, 22, 22, '1570917600', '1570917600', '1570954380', '10-2019', '1570917600', '', 2, 129, 1, 'مساء النور يا فندم\r\nبالفعل كلمنى واتفقت معاه يبعث لى صور منتجات شركتكم الموقره عالواتس لكن جيت اكلمه على الرقم اللى كان بيكلمنى منه لم أجد عليه واتس\r\nهو قاللى انه هييجى دمياط بإذن الله السبت الجاى لأ\r\nلكن هييجى اللى بعده\r\nوبييجى مرتين فى الشهر\r\nالف شكر', 1, 'مدير الموقع', 0, 2),
(77, 20, 20, '1570917600', '1570831200', '1570956906', '10-2019', '1571176800', '', 0, 129, 1, 'تم الاتصال بالعميل وسال علي الاستيك العادى والاسكوتش البني والجرين وصور للعينات للعلم مكانه في المنوفيه', 1, 'مدير الموقع', 0, 2),
(78, 23, 23, '1570958098', '1570917600', '1570958098', '10-2019', '', NULL, 0, 0, 2, 'المكان جسر السويس \r\nمطلوب اسعار الاستيك والسولتيب \r\nعلى الواتس اب او مكالمة', 7, 'اسماء محمد', 0, 1),
(79, 23, 23, '1570917600', '1570917600', '1570958131', '10-2019', '1570917600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(80, 19, 19, '1570917600', '1570831200', '1570962252', '10-2019', '', NULL, 0, 0, 0, 'كود العميل 102712', 7, 'اسماء محمد', 4, 2),
(81, 24, 24, '1570963828', '1570917600', '1570963828', '10-2019', '', NULL, 0, 0, 2, 'العنوان / جسر السويس شارع جمال عبد الناصر \r\nمحل الياسمين \r\n01095561879\r\nالاستقسار عن ( الاستيك - الاسكوتش 150 متر - 100 متر - 70 متر  )', 7, 'اسماء محمد', 0, 1),
(82, 24, 24, '1570917600', '1570917600', '1570963849', '10-2019', '1570917600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(83, 25, 25, '1570964883', '1570917600', '1570964883', '10-2019', '', NULL, 0, 0, 2, 'شربين \r\nالاستفسار عن الاسكوتش 100 ياردة كريستال', 7, 'اسماء محمد', 0, 1),
(84, 25, 25, '1570917600', '1570917600', '1570964892', '10-2019', '1570917600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(85, 19, 19, '1570917600', '1570831200', '1570965966', '10-2019', NULL, NULL, 0, 0, 0, 'تم تسجيل العميل', 1, 'مدير الموقع', 0, 3),
(86, 4, 4, '1570917600', '1570572000', '1570976740', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال يالعميل والتاكيد', 1, 'مدير الموقع', 0, 3),
(87, 26, 26, '1571048404', '1571004000', '1571048404', '10-2019', '', NULL, 0, 0, 2, 'الاستقسار عن -	سكوتش 100متر * 9.6سم E00\r\nاسكوتش مطبوع \r\nالعنوان برو سعيد تعاونيات الزهور - عمارة الوفاء', 7, 'اسماء محمد', 0, 1),
(88, 26, 26, '1571004000', '1571004000', '1571048419', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(89, 26, 26, '1571004000', '1571004000', '1571048526', '10-2019', '', NULL, 0, 0, 0, 'تم تحرير طلب اسكوتش مطبوع والوان', 7, 'اسماء محمد', 4, 2),
(90, 27, 27, '1571065998', '1571004000', '1571065998', '10-2019', '', NULL, 0, 0, 2, 'الاستفسار عن السولتيب', 7, 'اسماء محمد', 0, 1),
(91, 27, 27, '1571004000', '1571004000', '1571066033', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(92, 28, 28, '1571082701', '1571004000', '1571082701', '10-2019', '', NULL, 0, 0, 2, 'لؤي عثمان\r\nالفرسان للتجارة\r\n01002725405\r\nمحافظة الاسكندرية الكيلو 46 صحراوي\r\nالمنتجات مستلزمات مطاعم', 1, 'مدير الموقع', 0, 1),
(93, 28, 28, '1571004000', '1571004000', '1571082929', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(94, 29, 29, '1571082807', '1571004000', '1571082807', '10-2019', '', NULL, 0, 0, 2, 'ايمن السويدي\r\n01006959458\r\n01146190688\r\nحمزه باك\r\nالقاهره\r\nجميع  المنتجات', 1, 'مدير الموقع', 0, 1),
(95, 29, 29, '1571004000', '1571004000', '1571083023', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(96, 30, 30, '1571082830', '1571004000', '1571082830', '10-2019', '', NULL, 0, 0, 2, 'عبدالله سيد\r\n01002679581\r\nشركة هاردكير- القاهرة\r\nتوريدات- سترتش غذائي - لزق مطبوع\r\nمعرفش إنتوا بنشتغلوا بإيه تاني', 1, 'مدير الموقع', 0, 1),
(97, 30, 30, '1571004000', '1571004000', '1571083108', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(98, 31, 31, '1571082860', '1571004000', '1571082860', '10-2019', '', NULL, 0, 0, 2, 'علاء الدين\r\n01009698365\r\nشركة اليسر لتجارة الورق وخامات الطباعه\r\nاسيوط\r\nحضرتك انا بوزع جمله\r\nممكن اعرف الاصناف والاسعار\r\nان شاء الله نازل القاهره', 1, 'مدير الموقع', 0, 1),
(99, 31, 31, '1571004000', '1571004000', '1571083182', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(100, 32, 32, '1571084019', '1571004000', '1571084019', '10-2019', '', NULL, 0, 0, 2, 'ابو عمرو مكتبه الشيماء\r\n01003855474\r\nطنطا - بسيون - غربيه\r\nبكره لصق ٦٠ يرده\r\nوسعره كام وهل فيه خصم', 1, 'مدير الموقع', 0, 1),
(101, 32, 32, '1571004000', '1571004000', '1571084053', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(102, 33, 33, '1571084028', '1571004000', '1571084028', '10-2019', '', NULL, 0, 0, 2, 'السيد حمزة\r\n01093961963\r\nحمزة بلاست\r\nالاسترتش الغذاءي\r\nاكواب الكرتون', 1, 'مدير الموقع', 0, 1),
(103, 33, 33, '1571004000', '1571004000', '1571084128', '10-2019', '1571004000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(104, 38, 38, '1571137442', '1571090400', '1571137442', '10-2019', '', NULL, 0, 0, 2, '‎محمد العدوى‎\r\n01062946415\r\nمكتبه العدوي\r\nشبين الكوم /المنوفيه\r\nممكن سعر بكر زينه عريض\r\nبكر زينه حلواني الرفيع\r\nمسدس شمع كبير', 1, 'مدير الموقع', 0, 1),
(105, 38, 38, '1571090400', '1571090400', '1571137873', '10-2019', '1571090400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(106, 34, 34, '1571137397', '1571090400', '1571137397', '10-2019', '', NULL, 0, 0, 2, '01001390111\r\nعبدالموجود عبدالمعطي\r\nالمصرية للبلاستيك\r\nمحافظة قنا\r\nالسولتيب -  وخيط الحلواني - والاسترتش', 1, 'مدير الموقع', 0, 1),
(107, 34, 34, '1571090400', '1571090400', '1571137886', '10-2019', '1571090400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(108, 35, 35, '1571137405', '1571090400', '1571137405', '10-2019', '', NULL, 0, 0, 2, 'زاهر الدبيكي\r\n01006657040\r\nمكتبة الصفاء المحمدي\r\nنزلة المرج القلج شارع الجمهورية قبل موقف الاتوبيس\r\nمحافظة القليوبية', 1, 'مدير الموقع', 0, 1),
(109, 35, 35, '1571090400', '1571090400', '1571137960', '10-2019', '1571090400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(110, 36, 36, '1571137415', '1571090400', '1571137415', '10-2019', '', NULL, 0, 0, 2, '01014158555\r\nالقليوبيه - بنها \r\nاستفساراتى كلها غالبا فى شغل اللازق الدبل فيس\r\nواللزق الدوكو', 1, 'مدير الموقع', 0, 1),
(111, 36, 36, '1571090400', '1571090400', '1571138016', '10-2019', '1571090400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(112, 37, 37, '1571137432', '1571090400', '1571137432', '10-2019', '', NULL, 0, 0, 2, '‎وليد حشمت‎\r\n01092333911\r\nمحافظة المنيا\r\nمكتبات الوليد ووليد الجديدة و التلاوى\r\nأدوات مكتبية', 1, 'مدير الموقع', 0, 1),
(113, 37, 37, '1571090400', '1571090400', '1571138064', '10-2019', '1571090400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(114, 26, 26, '1571090400', '1571004000', '1571139101', '10-2019', NULL, NULL, 0, 0, 0, 'رقم العميل  : 102714', 1, 'مدير الموقع', 0, 3),
(115, 28, 28, '1571090400', '1571004000', '1571147452', '10-2019', NULL, NULL, 0, 0, 0, 'سيقوم العميل بالحضور للفرع الرئيسى ببحرى ليرى الاصناف المحتاج إليها وتحديد الاسعار والمنتجات المطلوبة', 8, 'هادى ابراهيم', 0, 2),
(116, 25, 25, '1571176800', '1570917600', '1571210936', '10-2019', '1571263200', '', 0, 128, 1, 'تم الاتصال والسعر 540 الوزن الي عايزه 14.5 الكيلو', 7, 'اسماء محمد', 0, 2),
(117, 24, 24, '1571176800', '1570917600', '1571211224', '10-2019', '1571436000', '', 0, 128, 1, 'تم الاتصال بالعميل اليوم ولم يتم تحديد طلب الان السبب اخويا مسافر ولما يرجع بعد يومين\r\nوالسؤال علي السلوتيب والاستيك', 7, 'اسماء محمد', 0, 2),
(118, 16, 16, '1571176800', '1570831200', '1571211375', '10-2019', '1571436000', '', 0, 132, 1, 'تم الذهاب للعميل وفي انتظار طلب', 7, 'اسماء محمد', 0, 2),
(119, 39, 39, '1571219898', '1571176800', '1571219898', '10-2019', '', NULL, 0, 0, 2, 'الاستفسار عن شريط اللحام', 7, 'اسماء محمد', 0, 1),
(120, 39, 39, '1571176800', '1571176800', '1571219920', '10-2019', '1571176800', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(121, 2, 2, '1571176800', '1570485600', '1571221876', '10-2019', '1571176800', '1571232600', 3, 128, 1, 'الرجاء الاتصال بالمندوب ومتابعه هل تم زياره العميل امس و نتائج الزيارة ... وشكرا', 11, 'أ.ايمن بكر', 0, 2),
(122, 3, 3, '1571176800', '1570572000', '1571221977', '10-2019', '1571176800', '1571232720', 3, 128, 1, 'الرجاء الاتصال بالمندوب و متابعة ماتم  مع العميل', 11, 'أ.ايمن بكر', 0, 2),
(123, 5, 5, '1571176800', '1570572000', '1571222063', '10-2019', '1571176800', '1571232600', 3, 128, 1, 'الرجاء الاتصال بالمندوب ومعرفة متابعة ماتم مع العميل', 11, 'أ.ايمن بكر', 0, 2),
(124, 6, 6, '1571176800', '1570572000', '1571222132', '10-2019', '1571176800', '1571226300', 3, 128, 1, 'الرجاء معرفة ما تم مع العميل من المندوب', 11, 'أ.ايمن بكر', 0, 2),
(125, 7, 7, '1571176800', '1570572000', '1571222186', '10-2019', '1571176800', '1571225760', 3, 128, 1, 'هل تم الاتصال بالعميلة و عمل طلبية ؟؟', 11, 'أ.ايمن بكر', 0, 2),
(126, 8, 8, '1571176800', '1570572000', '1571222258', '10-2019', '1571176800', '1571229420', 2, 128, 1, 'الاتصال بالمندوب و تحديد موعد للمتابعه', 11, 'أ.ايمن بكر', 0, 2),
(127, 13, 13, '1571176800', '1570658400', '1571222354', '10-2019', '1571176800', '1571229480', 3, 128, 1, 'هل تم الاتصال بالعميلة ام لا ... ارجو المتابعة', 11, 'أ.ايمن بكر', 0, 2),
(128, 15, 15, '1571176800', '1570831200', '1571222804', '10-2019', '1571176800', '1571229000', 3, 128, 1, 'ما هي نتيجة اتصال المندوب بالعميل', 11, 'أ.ايمن بكر', 0, 2),
(129, 21, 21, '1571176800', '1570831200', '1571222890', '10-2019', '1571176800', '1571226300', 2, 128, 1, 'متابعة مع المندوب', 11, 'أ.ايمن بكر', 0, 2),
(130, 22, 22, '1571176800', '1570917600', '1571223006', '10-2019', '1571176800', '1571232600', 3, 128, 1, 'هل تم ارسال تذكرة للمندوب على ترلو ؟؟', 11, 'أ.ايمن بكر', 0, 2),
(131, 18, 18, '1571176800', '1570831200', '1571233689', '10-2019', NULL, NULL, 0, 0, 0, 'قمت بمحاولة الاتصال بالعميل اكثر من مره ولكن التليفون مغلق', 1, 'مدير الموقع', 0, 3),
(132, 28, 28, '1571176800', '1571004000', '1571234388', '10-2019', NULL, NULL, 0, 0, 0, 'اعاده فتح التذكرة للمتابعة بعد توفير مندوب مبيعات لغرب الاسكندرية', 1, 'مدير الموقع', 0, 3),
(133, 40, 28, '1571234388', '1571176800', '1571234388', '10-2019', '', NULL, 0, 0, 2, 'اعاده فتح التذكرة للمتابعة بعد توفير مندوب مبيعات لغرب الاسكندرية', 1, 'مدير الموقع', 0, 1),
(134, 40, 28, '1571176800', '1571176800', '1571234494', '10-2019', '1571176800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(135, 40, 28, '1571176800', '1571176800', '1571234561', '10-2019', '1572645600', '', 0, 128, 1, 'يتم مراجعة العميل بتارخ 2-11-2019\r\nلؤي عثمان\r\nالفرسان للتجارة\r\n01002725405\r\nمحافظة الاسكندرية الكيلو 46 صحراوي\r\nالمنتجات مستلزمات مطاعم', 1, 'مدير الموقع', 0, 2),
(136, 42, 41, '1571235766', '1571176800', '1571235766', '10-2019', '', NULL, 0, 0, 2, 'الهرم \r\nالاستفسار عن الاسكوتش الالوان \r\nالاسكوتش الكريستال', 7, 'اسماء محمد', 0, 1),
(137, 42, 41, '1571176800', '1571176800', '1571235780', '10-2019', '1571176800', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(138, 41, 40, '1571235550', '1571176800', '1571235550', '10-2019', '', NULL, 0, 0, 2, 'الجيزة - الوراق \r\nالاستفسار عن الاسترتشى المنزلى \r\nوأخذ فكرة عن منتجات الشركة', 7, 'اسماء محمد', 0, 1),
(139, 41, 40, '1571176800', '1571176800', '1571235789', '10-2019', '1571176800', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(140, 2, 2, '1571263200', '1570485600', '1571297361', '10-2019', '1571436000', '', 0, 132, 1, 'تم عمل زيارة للعميل امس وتم عرض الاصناف بالاسعار وفى انتظار الرد منه', 7, 'اسماء محمد', 0, 2),
(141, 3, 3, '1571263200', '1570572000', '1571297428', '10-2019', '1571436000', '', 0, 129, 1, 'تم ارسال قائمة اسعار للعميل ع الواتس اب وفى انتظار الرد', 7, 'اسماء محمد', 0, 2),
(142, 22, 22, '1571263200', '1570917600', '1571297671', '10-2019', '1571263200', '', 0, 128, 1, 'تم ارسال التذكرة على تريلو', 7, 'اسماء محمد', 0, 2),
(143, 21, 21, '1571436000', '1570831200', '1571473357', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وتحديد ميعاد زيارة يوم الثلاثاء\r\nالقادم', 7, 'اسماء محمد', 0, 2),
(144, 15, 15, '1571436000', '1570831200', '1571473667', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل ولم يتم الرد الهاتف مغلق\r\nوسيتم المتابعه فى وقت لاحق', 7, 'اسماء محمد', 0, 2),
(145, 5, 5, '1571436000', '1570572000', '1571473733', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل تليفونيا وطلب بعض اسعار للاسكوتش العادى والكريستال وتم ارسال الاسعار ع الواتس وفى اتتظار رد', 7, 'اسماء محمد', 0, 2),
(146, 2, 2, '1571436000', '1570485600', '1571473855', '10-2019', '1571868000', '', 0, 132, 1, 'انتظار الرد من العميل على الاسعار', 7, 'اسماء محمد', 0, 2),
(147, 3, 3, '1571436000', '1570572000', '1571473902', '10-2019', '1571868000', '', 0, 129, 1, 'تم ارسال قائمة اسعار للعميل ع الواتس اب وفى انتظار الرد', 7, 'اسماء محمد', 0, 2),
(148, 22, 22, '1571436000', '1570917600', '1571473947', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وتحديد موعد زيارة السبت', 7, 'اسماء محمد', 0, 2),
(149, 33, 33, '1571436000', '1571004000', '1571473976', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل واستفسر عن اسعار الكلينج الغذائى واسعار الاكواب الكرتون وسيتم ارسال الاسعار ع الواتس اب', 7, 'اسماء محمد', 0, 2),
(150, 30, 30, '1571436000', '1571004000', '1571474089', '10-2019', '1572040800', '', 0, 128, 1, 'تم التواصل معاه وتحديد اتصال اخر بعد أسبوع عشان مش فاضي بيوضب مقر شركه له جديد', 7, 'اسماء محمد', 0, 2),
(151, 29, 29, '1571436000', '1571004000', '1571474222', '10-2019', NULL, NULL, 0, 0, 0, 'العميل ده اسمه مش غريب وأظن انه تبع محمد انور بس محتاج متابعه جامده عشان لو هو اللي في بالي أظن انه عميل كبير جدا\r\nالعميل موجود بالفعل ومتعامل فى فرع عتمان القاهرة', 7, 'اسماء محمد', 0, 2),
(152, 41, 40, '1571436000', '1571176800', '1571474305', '10-2019', '1571522400', '', 0, 128, 1, 'تم الاتصال بالعميل اكثر من مره والتليفون غير متاح وسيتم المتابعة في وقت اخر', 7, 'اسماء محمد', 0, 2),
(153, 39, 39, '1571436000', '1571176800', '1571474358', '10-2019', '1571436000', '', 0, 128, 1, 'تم الاتصال بالعميل ولم يتم الرد وسيتم المتابعه لاحقا', 7, 'اسماء محمد', 0, 2),
(154, 39, 39, '1571436000', '1571176800', '1571474385', '10-2019', '1571608800', '', 0, 128, 1, 'معذره هذا العميل تم الاتصال به وقالي ابقي كلمني وقت تاني علشان انا مش فاضي', 7, 'اسماء محمد', 0, 2),
(155, 32, 32, '1571436000', '1571004000', '1571474428', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل وقالي حبقي اشوف حنحتاج ايه ونبقي نكلمك', 7, 'اسماء محمد', 0, 2),
(156, 27, 27, '1571436000', '1571004000', '1571474461', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال ورقم التليفون غير صحيح برجاء مراجعه البيانات والتأكد من صحتها قبل إرسال الطلب', 7, 'اسماء محمد', 0, 2),
(157, 23, 23, '1571436000', '1570917600', '1571474555', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل اكثر من مره ولم يرد وتم إرسال علي الواتس اب كما هو موضح بالتذكرة أيضا وجاري المتابعه لاحقا', 7, 'اسماء محمد', 0, 2),
(158, 17, 17, '1571436000', '1570831200', '1571474607', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل وعرض السعر الخاص بالاستيك عليه وفي انتظار الرد', 7, 'اسماء محمد', 0, 2),
(159, 27, 27, '1571436000', '1571004000', '1571480918', '10-2019', NULL, NULL, 0, 0, 0, 'رقم هاتف غير صحيح', 7, 'اسماء محمد', 0, 2),
(160, 45, 44, '1571563168', '1571522400', '1571563168', '10-2019', '', NULL, 0, 0, 2, 'الغربية / طنطا / مركز قطور \r\nمكتبة شفيق \r\nالاستفسار عن سولتيب عريض واستيك نقدية', 7, 'اسماء محمد', 0, 1),
(161, 45, 44, '1571522400', '1571522400', '1571563212', '10-2019', '1571522400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(162, 44, 43, '1571563162', '1571522400', '1571563162', '10-2019', '', NULL, 0, 0, 2, 'القاهرة العاشر من رمضان \r\nتوريد لوزم الخياطة \r\nالاستفسار عن ( شمع - مسدس - استيك )', 7, 'اسماء محمد', 0, 1),
(163, 44, 43, '1571522400', '1571522400', '1571563220', '10-2019', '1571522400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(164, 43, 42, '1571563155', '1571522400', '1571563155', '10-2019', '', NULL, 0, 0, 2, 'المكان - مدينة نصر عباس العقاد \r\nالاستفسار عن الاسكوتش مطبوع 1 لون', 7, 'اسماء محمد', 0, 1),
(165, 43, 42, '1571522400', '1571522400', '1571563229', '10-2019', '1571522400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(166, 6, 6, '1571522400', '1570572000', '1571563439', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل ولم يتم الرد وجارى المتابعة', 7, 'اسماء محمد', 0, 2),
(167, 7, 7, '1571522400', '1570572000', '1571563497', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وعرض السعر وفى انتظار الرد', 7, 'اسماء محمد', 0, 2),
(168, 13, 13, '1571522400', '1570658400', '1571563563', '10-2019', '1572472800', '', 0, 128, 1, 'تم التواصل مع العميل والمطلوب ارسال عينة من الشريط ( 4 او 5 بكرات من الشريط )', 7, 'اسماء محمد', 0, 2),
(169, 41, 40, '1571522400', '1571176800', '1571563712', '10-2019', '1571868000', '', 0, 128, 1, 'تم الاتصال بالعميل اكثر من مره والتليفون غير متاح وسيتم المتابعة في وقت اخر', 7, 'اسماء محمد', 0, 2),
(170, 45, 44, '1571522400', '1571522400', '1571563764', '10-2019', '1571868000', '', 0, 128, 1, 'تم ارسال بيانات العميل للمندوب وف انتظار الرد', 7, 'اسماء محمد', 0, 2),
(171, 29, 29, '1571522400', '1571004000', '1571582091', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاغلاق', 1, 'مدير الموقع', 0, 3),
(172, 27, 27, '1571522400', '1571004000', '1571582100', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاغلاق', 1, 'مدير الموقع', 0, 3),
(173, 2, 2, '1571608800', '1570485600', '1571649624', '10-2019', '', NULL, 0, 0, 0, 'طلب اكواب ورقية\r\nكود العميل 102721', 7, 'اسماء محمد', 4, 2),
(174, 20, 20, '1571608800', '1570831200', '1571649799', '10-2019', '1572300000', '', 0, 128, 1, 'تم التواصل مع العميل وفي انتظار طلبية', 7, 'اسماء محمد', 0, 2),
(175, 16, 16, '1571608800', '1570831200', '1571649839', '10-2019', '1572559200', '', 0, 128, 1, 'تم الاتصال بالعميل وفي انتظار الطلبية اول الشهر وذلك بناء علي رغبه العميل', 7, 'اسماء محمد', 0, 2),
(176, 31, 31, '1571608800', '1571004000', '1571649883', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل ( طلب صور واسعر مرة تانية بحجة ان التليفون ضاع منه ) وتم ارسال طلبه مرة اخرى وفي انتظار رده', 7, 'اسماء محمد', 0, 2),
(177, 34, 34, '1571608800', '1571090400', '1571649921', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وعاوز صور للاسكوتش العادى واسعاره واستيك والشريط', 7, 'اسماء محمد', 0, 2),
(178, 36, 36, '1571608800', '1571090400', '1571649976', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وفي انتظار صنف مطلوبب معرفته (دكو 1/2 بوصة) موجود عندنا في التشغيله او لا اما بالنسبة للدبل فيس مطلوب', 7, 'اسماء محمد', 0, 2),
(179, 42, 41, '1571608800', '1571176800', '1571650011', '10-2019', '1571868000', '', 0, 128, 1, 'تم التواصل مع العميل وفي انتظار العرض علي مالك الشركه الخاصه بيه لطلب عينات اولا ثم عمل الطلبية', 7, 'اسماء محمد', 0, 2),
(180, 24, 24, '1571608800', '1570917600', '1571650064', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل اكتر من مرة ولم يتم الرد', 7, 'اسماء محمد', 0, 2),
(181, 38, 38, '1571608800', '1571090400', '1571650110', '10-2019', '1572040800', '', 0, 128, 1, 'تم التواصل مع العميل وفي انتظار معرفه شركه الشحن والايداع لعمل الطلبية', 7, 'اسماء محمد', 0, 2),
(182, 39, 39, '1571608800', '1571176800', '1571650889', '10-2019', '1572040800', '', 0, 128, 1, 'معذره هذا العميل تم الاتصال ببع وقالي ابقي كلمني وقت تاني علشان انا مش فاضي\r\nف انتظار الرد من العميل', 7, 'اسماء محمد', 0, 2),
(183, 43, 42, '1571608800', '1571522400', '1571651234', '10-2019', '1572040800', '', 0, 128, 1, 'تم التواصل مع العميل وتحديد الطلبية وف انتظار الايداع البنكى \r\nلتحرير الطلب', 7, 'اسماء محمد', 0, 2),
(184, 44, 43, '1571608800', '1571522400', '1571651305', '10-2019', '1572472800', '', 0, 128, 1, 'تم التواصل مع العميل والرد على استفساراته \r\nومهتم بالمسدس \r\nوف انتظار وصول طلبية المسدس', 7, 'اسماء محمد', 0, 2),
(185, 46, 45, '1571652042', '1571608800', '1571652042', '10-2019', '', NULL, 0, 0, 2, 'ادوات \r\nمشتريات مدارسس فيوتشر \r\nكل المنتجات', 7, 'اسماء محمد', 0, 1),
(186, 46, 45, '1571608800', '1571608800', '1571652076', '10-2019', '1571608800', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(187, 47, 46, '1571652382', '1571608800', '1571652382', '10-2019', '', NULL, 0, 0, 2, 'سموحة مدينة اسيد \r\nموزع تجارى \r\nالاستفسار عن الاسترتش المنزلى', 7, 'اسماء محمد', 0, 1),
(188, 47, 46, '1571608800', '1571608800', '1571652395', '10-2019', '1571608800', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(189, 46, 45, '1571608800', '1571608800', '1571655055', '10-2019', '1572472800', '', 0, 128, 1, 'تم التواصل مع العميل \r\nوالرد على جميع استفساراته وتم الاتفاق على زيارة المعرض ببحرى خلال اسبوع', 7, 'اسماء محمد', 0, 2),
(190, 47, 46, '1571608800', '1571608800', '1571658977', '10-2019', '1572559200', '', 0, 128, 1, 'تم التواصل مع العميل \r\nويريد ان يكون موزع لدى الشركة ويرغب فى معرفة الشروط اللازمة \r\nوسوف يقوم بزيارة فرع الشركة لمعرفة التفاصيل', 7, 'اسماء محمد', 0, 2),
(191, 39, 39, '1571695200', '1571176800', '1571731095', '10-2019', '1571868000', '', 0, 128, 1, 'تمت المتابعه اليوم ولم يتم الرد من العميل وجاري متابعه العميل من طرفنا', 7, 'اسماء محمد', 0, 2),
(192, 41, 40, '1571695200', '1571176800', '1571731131', '10-2019', '1571868000', '', 0, 128, 1, 'تم المتابعه اليوم والاتصال بالعميل اكثر من مره ولم يتم الرد وجاري المتابعه لاحقا', 7, 'اسماء محمد', 0, 2),
(193, 23, 23, '1571695200', '1570917600', '1571731197', '10-2019', '1572645600', '', 0, 128, 1, 'تم المتابعه اليوم للعميل وطلب سعر الاستيك وكان ٥٨٥ وسعر بكره سوليتب ١٥٠ وكان ٥٠٥ وقالي لما نحتاج حبقا اكلمك ان شاء الله', 7, 'اسماء محمد', 0, 2),
(194, 25, 25, '1571695200', '1570917600', '1571731266', '10-2019', '1572040800', '', 0, 128, 1, 'تم الاتصال والسعر 540 الوزن الي عايزه 14.5 الكيلو', 7, 'اسماء محمد', 0, 2),
(195, 31, 31, '1571695200', '1571004000', '1571731333', '10-2019', '1572040800', '', 0, 128, 1, 'تم الاتصال بالعميل عدة مرات ولم يتم الرد منه', 7, 'اسماء محمد', 0, 2),
(196, 34, 34, '1571695200', '1571090400', '1571731362', '10-2019', '1572040800', '', 0, 128, 1, 'تم الاتصال بالعميل وفي انتظار الطلبية', 7, 'اسماء محمد', 0, 2),
(197, 20, 20, '1571695200', '1570831200', '1571731437', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل عدة مرات ولم يتم الرد منه واخر اتصال فتح وقفل', 7, 'اسماء محمد', 0, 2),
(198, 48, 47, '1571824669', '1571781600', '1571824669', '10-2019', '', NULL, 0, 0, 2, 'أ / ميران \r\nمحطة الرمل - الغرفة التجارية \r\nحلوانى دريس\r\nالاستفسار عن الاسكوتش \r\nوالتعرف على منتجات الشركة', 7, 'اسماء محمد', 0, 1),
(199, 48, 47, '1571781600', '1571781600', '1571824681', '10-2019', '1571781600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(200, 48, 47, '1571781600', '1571781600', '1571831429', '10-2019', '1572040800', '', 0, 128, 1, 'تم التواصل و اعطاء اسعار و حتشوف المهندس و تعرض عليه الامر و ترد علينا .', 7, 'اسماء محمد', 0, 2),
(201, 8, 8, '1571781600', '1570572000', '1571837872', '10-2019', '1571868000', '', 0, 129, 1, 'هل تم متابعة العميل من قبل المندوب', 11, 'أ.ايمن بكر', 0, 2),
(202, 35, 35, '1571781600', '1571090400', '1571837934', '10-2019', '1571868000', '', 0, 129, 1, 'هل تم متابعة العميل من قبل المندوب ؟؟', 11, 'أ.ايمن بكر', 0, 2),
(203, 37, 37, '1571781600', '1571090400', '1571837968', '10-2019', '1571868000', '', 0, 129, 1, 'هل تم متابعة العميل من قبل المندوب ؟؟', 11, 'أ.ايمن بكر', 0, 2),
(204, 48, 47, '1572040800', '1571781600', '1572100901', '10-2019', '1572472800', '', 0, 128, 1, 'تم التواصل مرة اخرى و اعطاء اسعار للاسكوتش 600 م شعر البكرة 58 عرض 4.8 D05\r\n900 م عرض 4.8 سعر البكرة 88 D05', 7, 'اسماء محمد', 0, 2),
(205, 35, 35, '1572040800', '1571090400', '1572101058', '10-2019', NULL, NULL, 0, 0, 0, 'لم يتم الرد من العميل عدة مرات', 7, 'اسماء محمد', 0, 2),
(206, 49, 48, '1572188649', '1572127200', '1572188649', '10-2019', '', NULL, 0, 0, 2, 'عمر اسامة  صاحب محل \r\nكنزى لمسلتزمات رياض الاطفال\r\nكفر الشيخ\r\nاتمنى ارسال قائمة بالمنتجات المتوفرة واسعارها وحاليا ارسال اسعار مسدس الشمع التايوانى والسلوتب الشفاف والدوكو.', 7, 'اسماء محمد', 0, 1),
(207, 49, 48, '1572127200', '1572127200', '1572188662', '10-2019', '1572127200', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(208, 2, 2, '1572127200', '1570485600', '1572198560', '10-2019', NULL, NULL, 0, 0, 0, 'طلب اكواب ورقية كود العميل 102721', 1, 'مدير الموقع', 0, 3),
(209, 35, 35, '1572127200', '1571090400', '1572198815', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وفعلا لم يكن هناك رد', 1, 'مدير الموقع', 0, 3),
(210, 24, 24, '1572127200', '1570917600', '1572199238', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل \r\nوتم التاكيد وبتشكر فى استاذ مينا بس هيا للاسف كان عندها ظروف \r\nوستقوم بالاتصال لاحقا بنا', 1, 'مدير الموقع', 0, 3),
(211, 20, 20, '1572127200', '1570831200', '1572200002', '10-2019', NULL, NULL, 0, 0, 0, 'تم التواصل على الفيس ولم يتم الرد', 1, 'مدير الموقع', 0, 3),
(212, 48, 47, '1572213600', '1571781600', '1572273403', '10-2019', '1572472800', '', 3, 128, 1, 'تمت المتابعة اليوم و فى انتظار تحديد موعد لمقابلة المهندس مع وجود عينات', 7, 'اسماء محمد', 0, 2),
(213, 50, 49, '1572273419', '1572213600', '1572273419', '10-2019', '', NULL, 0, 0, 2, 'الاسم التجارى : بدوى للصناعات الغذائية \r\nالاستفسار عن الاسكوتش \r\nسلاح الكتر والسولتيب المكتبى \r\nالاسكندرية', 7, 'اسماء محمد', 0, 1),
(214, 50, 49, '1572213600', '1572213600', '1572273433', '10-2019', '1572213600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(215, 49, 48, '1572213600', '1572127200', '1572275414', '10-2019', '1572386400', '', 0, 128, 1, 'تم التواصل مع العميل وسيتم ارسال اسعار ع واتس', 7, 'اسماء محمد', 0, 2),
(216, 47, 46, '1572213600', '1571608800', '1572279187', '10-2019', NULL, NULL, 0, 0, 0, 'طلب وكاله ولا توجد امكانيات', 1, 'مدير الموقع', 0, 2),
(217, 12, 12, '1572213600', '1570658400', '1572279493', '10-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل وعنوانه المنزلة محافظة الدقهلية وعميل لدى عافية بلاست', 1, 'مدير الموقع', 0, 2),
(218, 47, 46, '1572213600', '1571608800', '1572297762', '10-2019', NULL, NULL, 0, 0, 0, 'طلب وكاله ولا توجد امكانيات', 1, 'مدير الموقع', 0, 3),
(219, 12, 12, '1572213600', '1570658400', '1572297785', '10-2019', NULL, NULL, 0, 0, 0, 'منافس', 1, 'مدير الموقع', 0, 3),
(220, 50, 49, '1572300000', '1572213600', '1572334255', '10-2019', '', NULL, 0, 0, 0, 'كود العميل 102726\r\nمصنع بدوى', 7, 'اسماء محمد', 4, 2),
(221, 52, 51, '1572339003', '1572300000', '1572339003', '10-2019', '', NULL, 0, 0, 2, 'الزفتاوى للتجارة والتوزيع \r\nاسكوتش عريض \r\nشيكرتون \r\nسوبر جلو \r\nدبل فيس', 7, 'اسماء محمد', 0, 1),
(222, 52, 51, '1572300000', '1572300000', '1572339019', '10-2019', '1572300000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(223, 51, 50, '1572339000', '1572300000', '1572339000', '10-2019', '', NULL, 0, 0, 2, 'حسين العطار \r\nمكتبات الاوائل\r\nمدينة الرحاب السوق التجاري محل رقم ٧٧/٧٨\r\nالفروع الرحاب _مدينتي _التجمع\r\n01111000684/01115599290\r\nالسلوتيب - بكر الحلويات - شمع المسدس', 7, 'اسماء محمد', 0, 1),
(224, 51, 50, '1572300000', '1572300000', '1572339076', '10-2019', '1572300000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(225, 50, 49, '1572300000', '1572213600', '1572342630', '10-2019', NULL, NULL, 0, 0, 0, 'كود العميل 102726', 1, 'مدير الموقع', 0, 3),
(226, 11, 11, '1572300000', '1570658400', '1572343309', '10-2019', '1573250400', '', 0, 128, 1, 'تم متابعه العميل علي الواتس اب بأرسال بعض الاسعار السوليتب الكريستال وفي انتظار الرد', 1, 'مدير الموقع', 0, 2),
(227, 17, 17, '1572300000', '1570831200', '1572343361', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل ولم يرد عليه وجاري المتابعه', 1, 'مدير الموقع', 0, 2),
(228, 23, 23, '1572300000', '1570917600', '1572343406', '10-2019', '1573250400', '', 0, 128, 1, 'تم المتابعه علي الواتس وفي انتظار الرد من العميل', 1, 'مدير الموقع', 0, 2),
(229, 32, 32, '1572300000', '1571004000', '1572343555', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل ولم يرد', 1, 'مدير الموقع', 0, 2),
(230, 39, 39, '1572300000', '1571176800', '1572343607', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل ولم يرد', 1, 'مدير الموقع', 0, 2),
(231, 41, 40, '1572300000', '1571176800', '1572344949', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل وطلب سعر الاسترتش الغذائي المصري والكوري وتم عرض السعر من طرفنا ١٦٥ و١٩٥ و٢٢٥ وقالي حشوف ايه المطلوب من المطعم واكلمك تاني', 1, 'مدير الموقع', 0, 2),
(232, 45, 44, '1572300000', '1571522400', '1572345017', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل وقالي حبقي اكلمك وقت تاني', 1, 'مدير الموقع', 0, 2),
(233, 53, 52, '1572345987', '1572300000', '1572345987', '10-2019', '', NULL, 0, 0, 2, '‎محمد عيسى\r\nالهدى جروب\r\nدمياط\r\n01001193686\r\nشيكرتون - سوليتب', 7, 'اسماء محمد', 0, 1),
(234, 53, 52, '1572300000', '1572300000', '1572345999', '10-2019', '1572300000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(235, 7, 7, '1572300000', '1570572000', '1572349615', '10-2019', NULL, NULL, 0, 0, 0, 'العميل تم الاتصال به من وقت المتابعة ولم يرد على الاتصالات', 8, 'هادى ابراهيم', 0, 2),
(236, 13, 13, '1572300000', '1570658400', '1572349697', '10-2019', NULL, NULL, 0, 0, 0, 'العميل طالب باكو شريط عينة فى الزقازيق', 8, 'هادى ابراهيم', 0, 2),
(237, 13, 13, '1572300000', '1570658400', '1572350844', '10-2019', NULL, NULL, 0, 0, 0, 'العميل طالب باكو شريط عينة فى الزقازيق', 1, 'مدير الموقع', 0, 3),
(238, 31, 31, '1572300000', '1571004000', '1572351006', '10-2019', '1572732000', '', 0, 128, 1, 'نعم تم التصال بالعميل عن طريق الواتس ولم يتم الرد منه', 1, 'مدير الموقع', 0, 2),
(239, 34, 34, '1572300000', '1571090400', '1572351080', '10-2019', '1572732000', '', 0, 129, 1, 'نعم تم متابعة العميل عن طريق الواتس ولم يتم الرد منه', 1, 'مدير الموقع', 0, 2),
(240, 36, 36, '1572300000', '1571090400', '1572351250', '10-2019', '1572732000', '', 0, 128, 1, 'ليس من صلاحياتي الاتصال بالمصنع', 1, 'مدير الموقع', 0, 2),
(241, 37, 37, '1572300000', '1571090400', '1572351309', '10-2019', '1572732000', '', 0, 128, 1, 'نعم تم الاتصال مرة جرس ومفيش استجابه ومرة غير متاح', 1, 'مدير الموقع', 0, 2),
(242, 38, 38, '1572300000', '1571090400', '1572351420', '10-2019', '1572732000', '', 0, 128, 1, 'لا لم يتم متابعه العميل وذلك لعدم الرد من قبل خدمه العملاء علي هل في شحن للمنوفيه ام لا', 1, 'مدير الموقع', 0, 2),
(243, 42, 41, '1572300000', '1571176800', '1572351541', '10-2019', '1572732000', '', 0, 128, 1, 'الشركة خاصتهم لم يتم تحديد انهي مورد هشتغلوا معاه\r\nاسف يا استاذ مينا انا مفهمتش حضرتك تقصد ايه', 1, 'مدير الموقع', 0, 2),
(244, 25, 25, '1572300000', '1570917600', '1572353481', '10-2019', '', NULL, 0, 0, 0, 'تم المتابعه مع العميل وطلب ٣٠ كرتونه ١٠٠ يارده ايفر جرين بس اهم حاجه عنده ان الشغل يكون كريستال مفيهوش هواء ووزن الكرتونه ١٣.٥ كيلو السعر ٥١١ والبونص.١ كرتونه', 1, 'مدير الموقع', 4, 2),
(245, 25, 25, '1572300000', '1570917600', '1572353510', '10-2019', NULL, NULL, 0, 0, 0, 'تم تحرير الطلب كود العميل 102728', 1, 'مدير الموقع', 0, 3),
(246, 54, 53, '1572355455', '1572300000', '1572355455', '10-2019', '', NULL, 0, 0, 2, '01223182310\r\nم صفيه حليم\r\nشركه الكرمه للتجارة والاستيراد\r\nالعصافره بحري\r\nالاسكندريه\r\nالرقم يعمل واتس اب\r\nالاستيك - الاسكوتش -  الادوات المكتبيه - سلك الدباسه الحصان لوومتوفر', 1, 'مدير الموقع', 0, 1),
(247, 54, 53, '1572300000', '1572300000', '1572355486', '10-2019', '1572300000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(248, 55, 54, '1572357259', '1572300000', '1572357259', '10-2019', '', NULL, 0, 0, 2, 'مهندس . محمد ربيع \r\nمصنع مفروشات \r\n01000171408\r\nدمياط\r\nالاسكوتش - بابلز - اسكوتش مطبوع', 1, 'مدير الموقع', 0, 1),
(249, 55, 54, '1572300000', '1572300000', '1572357271', '10-2019', '1572300000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(250, 52, 51, '1572300000', '1572300000', '1572361380', '10-2019', '1573250400', '', 0, 128, 1, 'تم الاتصال بالعميل وسأل علي شيكرتون والسوليتب العريض وسوبر جلو وتم إرسال الاسعار علي الواتس وجاري المتابعه', 7, 'اسماء محمد', 0, 2),
(251, 54, 53, '1572300000', '1572300000', '1572362590', '10-2019', '1572645600', '', 0, 128, 1, 'أ.اسماء بتجهز قايمة با لاصناف و الاسعار لأرسالها\r\nاصناف الاسكوتش بمقاساتة\r\nلسوليتب\r\nدبل فيس\r\nاستيك نقدية\r\nشيكرتون\r\nو باقى الاصناف علشان ممكن تدخل حاجات هى مش شغالة فيها ده على كلامها فا عايزة تعرف كل الاصناف بتاعت الشركة علشان تشتغل معانا', 1, 'مدير الموقع', 0, 2),
(252, 7, 7, '1572300000', '1570572000', '1572363044', '10-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل عن طريق Face\r\nوتم ارسال كافه الصور \r\nاستاذ محمد انور كان ارسل لها كافة الاسعار \r\nوتقيمى انها فعلا باحثة عن سعر فقط تم ارسال الصور حسب رغبتها', 1, 'مدير الموقع', 0, 3),
(253, 56, 55, '1572430136', '1572386400', '1572430136', '10-2019', '', NULL, 0, 0, 2, '01094356155\r\nعمر والي\r\nمكتبة إسراء كوم حماده البحيرة\r\nاقدر اعرف المنتجات اللي شغالين فيها\r\nانا اللي اعرفه اللصق ومسدس الشمع\r\nالاتصال ***  تمام بص استاذنك لو من بعد 12', 7, 'اسماء محمد', 0, 1),
(254, 56, 55, '1572386400', '1572386400', '1572430151', '10-2019', '1572386400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(255, 57, 56, '1572440840', '1572386400', '1572440840', '10-2019', '', NULL, 0, 0, 2, 'مركز دكرنس / محافظة الدقهلية\r\nالنشاط / توزيع\r\nالاستفسار عن جميع منتجات الشركة', 1, 'مدير الموقع', 0, 1),
(256, 57, 56, '1572386400', '1572386400', '1572440946', '10-2019', '1572386400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(257, 58, 57, '1572440967', '1572386400', '1572440967', '10-2019', '', NULL, 0, 0, 2, 'احمد لاشين \r\nمحافظة الشرقية \r\nالاستفسار عن الكلينج الكينج راب\r\nوباقى منتجات الشركة', 1, 'مدير الموقع', 0, 1),
(258, 58, 57, '1572386400', '1572386400', '1572441156', '10-2019', '1572386400', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(259, 59, 58, '1572474306', '1572472800', '1572474306', '10-2019', '', NULL, 0, 0, 2, 'محمود عبدالكريم\r\nالصحابه\r\nبنى سويف \r\nالاستفسار عن \r\nشمع مسدس\r\nمسدس شمع\r\nدبل فيس مقاسات\r\nشريط حلوانى رفيع\r\nشريط حلوانى ٥سم\r\nسلوتيبات ٥سم ٨٠و١٠٠و٦٠ يارده', 1, 'مدير الموقع', 0, 1),
(260, 59, 58, '1572472800', '1572472800', '1572517629', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(261, 61, 60, '1572474437', '1572472800', '1572474437', '10-2019', '', NULL, 0, 0, 2, '01128168200\r\nمحمد علي محمود\r\nالرائد للتوريدات\r\nالقليوبية\r\nالاستفسار عن \r\nجوانتي طبي\r\nاستيك كورن\r\nجوانتي شفاف\r\nرول استرتش \r\nرول فويل', 1, 'مدير الموقع', 0, 1),
(262, 61, 60, '1572472800', '1572472800', '1572517719', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(263, 60, 59, '1572474339', '1572472800', '1572474339', '10-2019', '', NULL, 0, 0, 2, '01010251200\r\n01222607490\r\nالسيد حجازي\r\nدسوق\r\nالاستفسار عن الاسكوتش الالوان والتعرف على منتجات الشركة \r\nالوتس علي الرقم\r\n01010251200', 1, 'مدير الموقع', 0, 1),
(264, 60, 59, '1572472800', '1572472800', '1572517755', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(265, 62, 61, '1572474454', '1572472800', '1572474454', '10-2019', '', NULL, 0, 0, 2, 'محمدعبدالدايم\r\nالعبور للتوريدات العمومية\r\nالقليوبية\r\nالاستيك التايلاندي النسر', 1, 'مدير الموقع', 0, 1),
(266, 62, 61, '1572472800', '1572472800', '1572518014', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(267, 63, 62, '1572474481', '1572472800', '1572474481', '10-2019', '', NULL, 0, 0, 2, 'احمد يوسف\r\nمؤسسة الشروق\r\nطوخ قليوبيه - مستورد أدوات مكتبيه\r\nالاستفسار عن \r\nالشمع بالطن\r\nوالزينه والكريشه\r\nوكل منتجات عتمان\r\nوالفويل\r\nسبق لي التعامل', 1, 'مدير الموقع', 0, 1),
(268, 63, 62, '1572472800', '1572472800', '1572518085', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(269, 64, 63, '1572518258', '1572472800', '1572518258', '10-2019', '', NULL, 0, 0, 2, 'باسم خفاجي\r\nمن طنطا \r\nموزع مواد تعبئه وتغليف\r\nعندي مصنع لاعاده لف ورق الفويل الغذائي والاسترتش المنزل\r\nالاستفسار عن \r\nالاسترتش المصري \r\nخله الشيش', 1, 'مدير الموقع', 0, 1),
(270, 64, 63, '1572472800', '1572472800', '1572518289', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(271, 66, 65, '1572518276', '1572472800', '1572518276', '10-2019', '', NULL, 0, 0, 2, 'الاسم إبرام فرج\r\n01286093129\r\nالمحافظة  المنيا\r\nالاستفسار عن \r\nالسلوتب  و الاسترتش', 1, 'مدير الموقع', 0, 1),
(272, 66, 65, '1572472800', '1572472800', '1572518353', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(273, 54, 53, '1572472800', '1572300000', '1572518376', '10-2019', '1572472800', '', 0, 128, 1, 'تم تحديد معاد اليوم الساعة ١ فى فرع ٤٥', 7, 'اسماء محمد', 0, 2),
(274, 65, 64, '1572518271', '1572472800', '1572518271', '10-2019', '', NULL, 0, 0, 2, 'رقم التلفون /01005619390 او 01060694623\r\nأبو كبير - الشرقيه - أول شارع المحلج\r\nالمحافظ الشرقيه', 1, 'مدير الموقع', 0, 1),
(275, 65, 64, '1572472800', '1572472800', '1572518419', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(276, 67, 66, '1572518577', '1572472800', '1572518577', '10-2019', '', NULL, 0, 0, 2, 'الاسم التجاري العجمي بلاست\r\nالبحر الاحمر\r\nسفاجا\r\nالمدير المسؤول مصطفى العجمي\r\n01288099900', 1, 'مدير الموقع', 0, 1),
(277, 67, 66, '1572472800', '1572472800', '1572518602', '10-2019', '1572472800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2);
INSERT INTO `sales_ticket_des` (`id`, `cat_id`, `cust_id`, `date_add`, `ticket_date`, `date_time`, `date_month`, `follow_date`, `follow_time`, `priority_id`, `follow_type`, `follow_state`, `des`, `user_id`, `user_name`, `add_type`, `count_type`) VALUES
(278, 54, 53, '1572472800', '1572300000', '1572534396', '10-2019', '1572645600', '', 0, 132, 1, 'تمت الزيارة المكان مخصص لبيع احبار الطباعة و ادوات المطابع تم اعطاء اسعار الاسكوتش و الاستيك و دبل فيس و تم عرض باقى الاصناف\r\nان شاء الله حتكون اول طلبية اسكوتش بعد مراجعة مخازنهم', 7, 'اسماء محمد', 0, 2),
(279, 46, 45, '1572645600', '1571608800', '1572707497', '11-2019', NULL, NULL, 0, 0, 0, 'عميل غير فعال هو ليس موزع ادوات او مكتبة هو مسئول مدرسة وحدثت مكلمة بين وبينه من اسبوعين وكان الاتفاق على تحديد زيارة وتم الاتصال بيه امس واليوم ولم يرد وبالتالى هو غير مجدى بالتعامل', 1, 'مدير الموقع', 0, 2),
(280, 46, 45, '1572645600', '1571608800', '1572708690', '11-2019', NULL, NULL, 0, 0, 0, 'تم ارسال رسالة على الفيس وتم اغلاق التذكره', 1, 'مدير الموقع', 0, 3),
(281, 40, 28, '1572645600', '1571176800', '1572708907', '11-2019', '1573855200', '', 0, 128, 1, 'لم يتم تعيين موظف مبيعات للمنطقة حتى الان', 1, 'مدير الموقع', 0, 2),
(282, 54, 53, '1572645600', '1572300000', '1572709010', '11-2019', '1573250400', '', 0, 128, 1, 'لم يتم تحديث حالة العميل وسيتم المرجعة بعد اسبوع من تاريخ لتحديد موقف التذكرة', 1, 'مدير الموقع', 0, 2),
(283, 70, 69, '1572767343', '1572732000', '1572767343', '11-2019', '', NULL, 0, 0, 2, 'المكان / المحلة الكبرى \r\nالاستفسار عن الاسكوتش \r\n100 ياردة\r\n80 ياردة كريستال', 7, 'اسماء محمد', 0, 1),
(284, 70, 69, '1572732000', '1572732000', '1572767421', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(285, 69, 68, '1572767331', '1572732000', '1572767331', '11-2019', '', NULL, 0, 0, 2, '‎العمده الاصلي ابو كريم‎\r\n01113044777\r\nالجيزه  السلوتب', 7, 'اسماء محمد', 0, 1),
(286, 69, 68, '1572732000', '1572732000', '1572767431', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(287, 68, 67, '1572767322', '1572732000', '1572767322', '11-2019', '', NULL, 0, 0, 2, 'ابراهيم شرف  اسكندريه السيوف شارع السلام العمومي الفلكي 01275257598\r\nالسلام عليكم انا اتعملت معاكم من مده بصراحه مستوي عالي جدا. ربنا يبارلكم وبالتوفيق بسأل عن الاستكوتش العادي ومقاسات والجرين مقاسات وأسعار وشكرا', 7, 'اسماء محمد', 0, 1),
(288, 68, 67, '1572732000', '1572732000', '1572767437', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(289, 71, 70, '1572769370', '1572732000', '1572769370', '11-2019', '', NULL, 0, 0, 2, 'كفر الدوار \r\nالاستفسار عن الاسكوتش 60 متر , 100 متر', 7, 'اسماء محمد', 0, 1),
(290, 71, 70, '1572732000', '1572732000', '1572769378', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(291, 72, 71, '1572771628', '1572732000', '1572771628', '11-2019', '', NULL, 0, 0, 2, 'ادهم خطاب\r\nمحلات الريان مطروح\r\nسلوتيب\r\nاستريتش غذائى وصناعى\r\nامير\r\nاستيك نقديه', 7, 'اسماء محمد', 0, 1),
(292, 72, 71, '1572732000', '1572732000', '1572771639', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(293, 54, 53, '1572732000', '1572300000', '1572773022', '11-2019', '1575151200', '', 0, 128, 1, 'هو فى المقابلة الناس جادين لكن الطلبية حتكون فى خلال شهر تقريبا لأنهم بيشترو كل فترة ٣٠ كرتونة و لسه عندهم شغل قديم فى المخزن يخلص و يطلبة شغل تانى من عندنا', 1, 'مدير الموقع', 0, 2),
(294, 73, 72, '1572775159', '1572732000', '1572775159', '11-2019', '', NULL, 0, 0, 2, 'شركة بيور لايف دمياط\r\n------------------------------\r\nتم التعاون معكم من عام 2016 وفي بداية عام 2018 وعند طلب شحنة ولم نستطع ادخالها في نفس اليوم انزعجت ادارة المبيعات لديكم وانهت التعامل معنا وتم التعامل مع اكثر من مورد من القاهرة بعد ذلك\r\n---\r\nمقر الشركة موجود في الكمطقة الحرة العامة بدمياط ويتم عمل اجراءات كثيرة قبل دخول اي شحنة\r\n------------------------------\r\nيرغب فى الاستفسار عن \r\n------------------------------\r\nنريد اسعار بكر لزق شفاف 60 ياردة و 80 ياردة\r\nواسعار بكر لزق 60 ياردة  و 80 ياردة افرجرين', 1, 'مدير الموقع', 0, 1),
(295, 73, 72, '1572732000', '1572732000', '1572775174', '11-2019', '1572732000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(296, 68, 67, '1572732000', '1572732000', '1572781729', '11-2019', '1573077600', '', 0, 128, 1, 'تمت المتابعة و اعطاء اسعار الاسكوتش الجرين و الجولدن و فى انتظار زيارة العميل اليوم  ( 03 - 11  ) ليلاً فى معرض الشركة', 7, 'اسماء محمد', 0, 2),
(297, 48, 47, '1572732000', '1571781600', '1572788786', '11-2019', NULL, NULL, 0, 0, 0, 'تمت المتابعة اليوم أ.ميران قالت انها كلمت المهندس و لم يرد عليها حتى الان و لو فى نصيب ان شاء الله حتتصل بيا و تم عرض اصناف اخرى للتعامل معنا فى اى صنف', 1, 'مدير الموقع', 0, 2),
(298, 48, 47, '1572732000', '1571781600', '1572789004', '11-2019', NULL, NULL, 0, 0, 0, 'تمت المتابعة اليوم أ.ميران قالت انها كلمت المهندس و لم يرد عليها حتى الان و لو فى نصيب ان شاء الله حتتصل بيا و تم عرض اصناف اخرى للتعامل معنا فى اى صنف', 1, 'مدير الموقع', 0, 3),
(299, 75, 74, '1572857948', '1572818400', '1572857948', '11-2019', '', NULL, 0, 0, 2, 'مكتبة صلاح عيادة \r\nمحافظة المنوفية \r\nالسولتيب والاسكوتش', 7, 'اسماء محمد', 0, 1),
(300, 75, 74, '1572818400', '1572818400', '1572857957', '11-2019', '1572818400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(301, 74, 73, '1572857944', '1572818400', '1572857944', '11-2019', '', NULL, 0, 0, 2, 'اسيوط \r\nبرج الصفا بجوار مستشفى الشاملة \r\nمكتبة اليداك \r\nالاستفسار عن بكر سولتيب عريض \r\nادوات المدارس \r\nشمع لحام \r\nبكر زينة عريض ورفيع', 7, 'اسماء محمد', 0, 1),
(302, 74, 73, '1572818400', '1572818400', '1572857997', '11-2019', '1572818400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(303, 16, 16, '1572818400', '1570831200', '1572867070', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وسؤاله علي الطلبية تم الرد منه ان الاسعار في عدم استقرار والانتظار لحين ثبوت الاسعار', 1, 'مدير الموقع', 0, 2),
(304, 16, 16, '1572818400', '1570831200', '1572867103', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال والمراجعة', 1, 'مدير الموقع', 0, 3),
(305, 34, 34, '1572818400', '1571090400', '1572867376', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل ولم يتم الرد', 1, 'مدير الموقع', 0, 2),
(306, 77, 76, '1572867398', '1572818400', '1572867398', '11-2019', '', NULL, 0, 0, 2, 'مكتبه ابو مازن ساحل سليم\r\n01288629077 واتس\r\nمحافظه اسيوط\r\nمركز ساحل سليم\r\nالشحن من القاهره من خلال شحن\r\nشحن الحكيم\r\nشحن سلطان الصعيد\r\nعايز اسعار السلوتب\r\nشريط لف الهدايا والزينه\r\nشنط الهدايا\r\nمكتبه جمله وعايزين اسعار منافسه مع شرط الشحن من القاهره\r\nيا ريت نتواصل واتس لو سمحتو\r\nابعتولنا العروض واتس واللي يناسبنا نحولك مقدما مفيش مشكله', 7, 'اسماء محمد', 0, 1),
(307, 77, 76, '1572818400', '1572818400', '1572867419', '11-2019', '1572818400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(308, 34, 34, '1572818400', '1571090400', '1572867420', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال وارسال رسالة على الفيس للاغلاق \r\nفعلا العميل غير جاد', 1, 'مدير الموقع', 0, 3),
(309, 76, 75, '1572867372', '1572818400', '1572867372', '11-2019', '', NULL, 0, 0, 2, 'محمد السيد رزق\r\nسنتر الاسطوره\r\nالبحيرة. لقانه\r\n01069409517', 7, 'اسماء محمد', 0, 1),
(310, 76, 75, '1572818400', '1572818400', '1572867461', '11-2019', '1572818400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(311, 42, 41, '1572818400', '1571176800', '1572867768', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل ولايوجد جدية في التعامل', 1, 'مدير الموقع', 0, 2),
(312, 42, 41, '1572818400', '1571176800', '1572867823', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال والتاكيد على العميل', 1, 'مدير الموقع', 0, 3),
(313, 31, 31, '1572818400', '1571004000', '1572868239', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال علي العميل ولم يتم الرد عده مرات', 1, 'مدير الموقع', 0, 2),
(314, 31, 31, '1572818400', '1571004000', '1572868272', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال والتاكيد', 1, 'مدير الموقع', 0, 3),
(315, 59, 58, '1572818400', '1572472800', '1572868898', '11-2019', '1573077600', '', 0, 128, 1, 'تم الاتصال علي العميل وفي انتظار طلبية يوم الاربعاء الاصناف المراد الطلب منها شريط عريض وشريط 1/2 سم وسأل علي الشمع لحام', 1, 'مدير الموقع', 0, 2),
(316, 67, 66, '1572818400', '1572472800', '1572873428', '11-2019', '1573077600', '', 0, 128, 1, 'تم الاتصال بالعميل وعرض اصناف الاسكوتش الجرين 60و80و100و150 وتم عرض الفويل والشريط وشغال مع الصمدى ومحمد خالد والخواجه وشركة الشحن اللي بيتعامل معها الزهور وفي نية للتعامل في الاسكوتش ويوجد زيارة من اخيه اسمه محمد العجمي لفرع الشركة في بحرى عن قريب', 1, 'مدير الموقع', 0, 2),
(317, 38, 38, '1572818400', '1571090400', '1572873525', '11-2019', '1573077600', '', 0, 128, 1, 'تم الاتصال بالعميل وتحديد شركة الشحن الغتمي بباب الشعرية وفي انتظار الايداع لعمل الطلب', 1, 'مدير الموقع', 0, 2),
(318, 77, 76, '1572818400', '1572818400', '1572873594', '11-2019', '1573077600', '', 0, 128, 1, 'تم التصال علي العميل وسيتم التواصل علي الواتس', 1, 'مدير الموقع', 0, 2),
(319, 65, 64, '1572818400', '1572472800', '1572873678', '11-2019', '1572818400', '', 0, 128, 1, 'تم التصال علي العميل ولم يتم الرد', 1, 'مدير الموقع', 0, 2),
(320, 65, 64, '1572818400', '1572472800', '1572873699', '11-2019', '1572818400', '', 0, 128, 1, 'تم التواصل مع العميل\r\nبرجاء التواصل على الرقم\r\n01060694623\r\nده رقمي متاح في اي وقت\r\nبرجاء الاتصال والافادة', 1, 'مدير الموقع', 0, 2),
(321, 72, 71, '1572904800', '1572732000', '1572989848', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل اكثر من مرة من رقمى الخاص ورقم الشركة ولا نتلقى استجابة او رد\r\nتم التواصل مع العميل على الفيس وفى انتظار الرد', 1, 'مدير الموقع', 0, 2),
(322, 72, 71, '1573077600', '1572732000', '1573127086', '11-2019', NULL, NULL, 0, 0, 0, 'تم ارسال رسالة على الفيس وتم اغلاق التذكره', 1, 'مدير الموقع', 0, 3),
(323, 64, 63, '1573250400', '1572472800', '1573285600', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل واتضح انه منافس وكان بيتصل ب أ / محمد خميس  اكتر من مره قبل كده ويياخد سعر وبس في الاسترتش الغذائي وما ومضحلوش كل المعلومات الي كان عايز يعرفها', 7, 'اسماء محمد', 0, 2),
(324, 64, 63, '1573250400', '1572472800', '1573295741', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال من قبل استاذ محمد انور وابلغنا انه منافس \r\nوطلب عدم المتابعة على ان يقوم هو بالمتابعة', 1, 'مدير الموقع', 0, 3),
(325, 11, 11, '1573250400', '1570658400', '1573296366', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(326, 11, 11, '1573250400', '1570658400', '1573296386', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل \r\nواضح انه خلال اسبوعين ممكن يطلب طلب لانه كان بالفعل كان اشترى بضاعة', 1, 'مدير الموقع', 0, 3),
(327, 23, 23, '1573250400', '1570917600', '1573296835', '11-2019', NULL, NULL, 0, 0, 0, 'تم المتابعة', 1, 'مدير الموقع', 0, 2),
(328, 23, 23, '1573250400', '1570917600', '1573296877', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وتم المراجعة', 1, 'مدير الموقع', 0, 3),
(329, 32, 32, '1573250400', '1571004000', '1573297460', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل ولم يرد', 1, 'مدير الموقع', 0, 2),
(330, 32, 32, '1573250400', '1571004000', '1573297485', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وهو عميل غير جاد', 1, 'مدير الموقع', 0, 3),
(331, 39, 39, '1573250400', '1571176800', '1573297845', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل ولم يرد', 1, 'مدير الموقع', 0, 2),
(332, 39, 39, '1573250400', '1571176800', '1573298086', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال ولم يرد\r\nوتم ارسال رسالة على الفيس تفيد اغلاق المتابعة', 1, 'مدير الموقع', 0, 3),
(333, 41, 40, '1573250400', '1571176800', '1573298351', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(334, 41, 40, '1573250400', '1571176800', '1573298435', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل \r\nابدى امكانية التعاون فى القريب العاجل', 1, 'مدير الموقع', 0, 3),
(335, 45, 44, '1573250400', '1571522400', '1573298984', '11-2019', '1573855200', '', 0, 128, 1, 'تم الاتصال بالعميل\r\nواعتذر عن عدم امكانيه المتابعه لضايع الرقم الخاص باستاذ محمد خميس\r\nتم ارسال الرقم الخاص باستاذ محمد وسيقوم العميل بالاتصال\r\nبرجاء تحديث التذكره فى حالة الاتصال من العميل', 1, 'مدير الموقع', 0, 2),
(336, 78, 77, '1573299436', '1573250400', '1573299436', '11-2019', '', NULL, 0, 0, 2, 'اسلام الترزاوي مع حضرتك\r\nكنت محتاج بلاستر\r\n01012000017 - 01111037074\r\nمحافظه الشرقيه مركز ومدينه ديرب نجم\r\nشركه اسلام الترزاوي لصناعه الالوميتال', 7, 'اسماء محمد', 0, 1),
(337, 78, 77, '1573250400', '1573250400', '1573299447', '11-2019', '1573250400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(338, 52, 51, '1573250400', '1572300000', '1573299828', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(339, 52, 51, '1573250400', '1572300000', '1573299882', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل ولم يرد \r\nوتم ارسال رسالة على الفيس تفيد الاغلاق', 1, 'مدير الموقع', 0, 3),
(340, 57, 56, '1573250400', '1572386400', '1573300113', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(341, 57, 56, '1573250400', '1572386400', '1573300155', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب \r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 1, 'مدير الموقع', 0, 3),
(342, 70, 69, '1573250400', '1572732000', '1573300499', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(343, 70, 69, '1573250400', '1572732000', '1573300519', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب \r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 1, 'مدير الموقع', 0, 3),
(344, 63, 62, '1573250400', '1572472800', '1573300871', '11-2019', '1573855200', '', 0, 128, 1, 'تم الاتصال بالعميل وسأل علي الأصناف الشمع والاستيك وورق الهدايا والسوليتب المكتبي وعايز قايمه بالأسعار علي الواتس وجاري تنفيذها للعميل وارسالها', 1, 'مدير الموقع', 0, 2),
(345, 75, 74, '1573250400', '1572818400', '1573301365', '11-2019', '1573855200', '', 0, 129, 1, 'ننتظر تحديث الحاله', 1, 'مدير الموقع', 0, 2),
(346, 62, 61, '1573250400', '1572472800', '1573301821', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(347, 62, 61, '1573250400', '1572472800', '1573301845', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وابدى رغبته فى التعاون فى القريب\r\nوسيقوم هو بالمتابعة مع استاذ محمد خميس', 1, 'مدير الموقع', 0, 3),
(348, 17, 17, '1573250400', '1570831200', '1573302333', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق محمد خميس', 1, 'مدير الموقع', 0, 2),
(349, 17, 17, '1573250400', '1570831200', '1573302373', '11-2019', NULL, NULL, 0, 0, 0, 'عند الاتصال بالعميل قال الرقم غلط', 1, 'مدير الموقع', 0, 3),
(350, 61, 60, '1573250400', '1572472800', '1573302831', '11-2019', '1573855200', '', 0, 128, 1, 'تم الاتصال وكنسل\r\nتمت المتابعة على الفيس وفى انتظار الرد\r\nتم الاتصال بالعميل وسأل علي منتجات الشركه وجاري المتابعه علي الواتس', 1, 'مدير الموقع', 0, 2),
(351, 37, 37, '1573250400', '1571090400', '1573318109', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق', 1, 'مدير الموقع', 0, 2),
(352, 37, 37, '1573250400', '1571090400', '1573318186', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال لا يرد \r\nوتم ارسال رسالة الفيس', 1, 'مدير الموقع', 0, 3),
(353, 79, 78, '1573389656', '1573336800', '1573389656', '11-2019', '', NULL, 0, 0, 2, 'احمد بدوي\r\n01221186411\r\nمحتاج فوم جليتر', 1, 'مدير الموقع', 0, 1),
(354, 79, 78, '1573336800', '1573336800', '1573389689', '11-2019', '1573336800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(355, 61, 60, '1573336800', '1572472800', '1573389852', '11-2019', '1573855200', '', 0, 128, 1, 'تم الرد من العميل\r\nوتم ارسال رقم حضرتك وهيتواصل مع حضرتك\r\nهو بيقول انه كان بيتعامل قبل كده وموقف نشاط وبيرجعه\r\nحضرتك لو اتصل بيك بلغنا', 1, 'مدير الموقع', 0, 2),
(356, 36, 36, '1573336800', '1571090400', '1573390592', '11-2019', '1573336800', '', 0, 129, 1, 'الاغلاق لعدم الايداع \r\n------------------------------------------\r\nتم الاتصال بالعميل وابلغنا انه لم يتم التواصل معاه بخصوص الايداع\r\nوانه لم يتم تحديد الاتفاق النهائى لكى يتم الايداع\r\nوانه يرغب جديا فى التعامل قد تكون الكمية صغيرة ولكنه يرغب التعاون\r\nبرجاء المراجعة والتواصل مع العميل', 1, 'مدير الموقع', 0, 2),
(357, 38, 38, '1573336800', '1571090400', '1573392772', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق لعدم عمل الايداع', 1, 'مدير الموقع', 0, 2),
(358, 38, 38, '1573336800', '1571090400', '1573392837', '11-2019', NULL, NULL, 0, 0, 0, 'كان عنده مشكلة فى شركة الشحن وتم حلها\r\nوبعد اتمام الطلب لم يقم بالايداع\r\nبيقول انه بيعمل عمره', 1, 'مدير الموقع', 0, 3),
(359, 80, 79, '1573399834', '1573336800', '1573399834', '11-2019', '', NULL, 0, 0, 2, 'معرض السراج للبلاستيك\r\nسراج على \r\nالمنصورة\r\nدوران العبور\r\n01002011115', 1, 'مدير الموقع', 0, 1),
(360, 80, 79, '1573336800', '1573336800', '1573399846', '11-2019', '1573336800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(363, 68, 67, '1573509600', '1572732000', '1573550532', '11-2019', NULL, NULL, 0, 0, 0, 'اغلاق', 1, 'مدير الموقع', 0, 2),
(364, 68, 67, '1573509600', '1572732000', '1573550562', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل عى الفيس وشاف الرسالة ولم يرد', 1, 'مدير الموقع', 0, 3),
(365, 16, 16, '1573509600', '1570831200', '1573551592', '11-2019', '', NULL, 0, 0, 0, 'تم تحرير طلب وكود العميل 102737', 1, 'مدير الموقع', 4, 2),
(366, 16, 16, '1573509600', '1570831200', '1573551632', '11-2019', NULL, NULL, 0, 0, 0, 'تم تحرير طلب وكود العميل 102737', 1, 'مدير الموقع', 0, 3),
(367, 58, 57, '1573509600', '1572386400', '1573569994', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وغير جاد في التعامل', 1, 'مدير الموقع', 0, 2),
(368, 58, 57, '1573509600', '1572386400', '1573570015', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل\r\nولا يوجد تعليق من العميل\r\nوتم التاكيد على اغلاق طلب المتابعة', 1, 'مدير الموقع', 0, 3),
(369, 79, 78, '1573509600', '1573336800', '1573570201', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل خلال يومين متتاليين والتليفون غ متاح لدى العميل', 1, 'مدير الموقع', 0, 2),
(370, 79, 78, '1573509600', '1573336800', '1573570218', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل على الفيس\r\nوتم اغلاق التذكرة', 1, 'مدير الموقع', 0, 3),
(371, 78, 77, '1573509600', '1573250400', '1573570471', '11-2019', '1574114400', '', 0, 128, 1, 'تم التواصل مع العميل المطلوب اسكوتش مطبوع', 1, 'مدير الموقع', 0, 2),
(372, 69, 68, '1573509600', '1572732000', '1573571207', '11-2019', '1574114400', '', 0, 128, 1, 'تم التواصل مع العميل بالاتصال ثم الواتس وارسال اسعار السلوتيب الكريستال والايفر', 1, 'مدير الموقع', 0, 2),
(373, 65, 64, '1573509600', '1572472800', '1573571430', '11-2019', '1574114400', '', 0, 128, 1, 'تم الاتصال بالعميل وعرض اصناف الاسكوتش والمسدس والاستيك والشمع والمكتبي عن طريق الواتس', 1, 'مدير الموقع', 0, 2),
(374, 59, 58, '1573509600', '1572472800', '1573571483', '11-2019', '1574114400', '', 0, 128, 1, 'تم الاتصال بالعميل مرة اخرى وعرض المسدس والشمع بعد تفعيل العرض', 1, 'مدير الموقع', 0, 2),
(375, 3, 3, '1573509600', '1570572000', '1573572033', '11-2019', '1573941600', '', 0, 128, 1, 'تم الاتصال بالعميل \r\nوتم ارسال رقم تليفون استاذ محمود \r\nوسيقوم العميل بالتواصل معه على الوتس', 1, 'مدير الموقع', 0, 2),
(376, 5, 5, '1573509600', '1570572000', '1573572363', '11-2019', '1573682400', '', 0, 128, 1, 'تم الاتصال لم يرد\r\nتم التواصل على الفيس وفى انتظار الرد', 1, 'مدير الموقع', 0, 2),
(377, 22, 22, '1573509600', '1570917600', '1573572703', '11-2019', '1573682400', '', 0, 128, 1, 'تم الاتصال بالعميل الهاتف مغلق تم ارسال رسالة على الفيس وفى انتظار الرد', 1, 'مدير الموقع', 0, 2),
(378, 49, 48, '1573509600', '1572127200', '1573573199', '11-2019', '1573682400', '', 0, 128, 1, 'تم الاتصال بالعميل\r\nواوضح انه لم يتم ارسال الاسعار على الوتس\r\nما هو سبب الارشفة والاغلاق', 1, 'مدير الموقع', 0, 2),
(379, 53, 52, '1573509600', '1572300000', '1573573456', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل\r\nوالامكانية ضعيفة للعميل\r\nسيتم الاغلاق', 1, 'مدير الموقع', 0, 2),
(380, 53, 52, '1573509600', '1572300000', '1573573485', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل\r\nوالامكانية ضعيفة للعميل\r\nسيتم الاغلاق', 1, 'مدير الموقع', 0, 3),
(381, 5, 5, '1573509600', '1570572000', '1573583904', '11-2019', NULL, NULL, 0, 0, 0, 'عميل غير جاد', 1, 'مدير الموقع', 0, 2),
(382, 5, 5, '1573509600', '1570572000', '1573583942', '11-2019', NULL, NULL, 0, 0, 0, 'تم الرد من قبل العميل \r\nولا يرغب فى المتابعه', 1, 'مدير الموقع', 0, 3),
(383, 77, 76, '1573682400', '1572818400', '1573744125', '11-2019', '', NULL, 0, 0, 0, 'تم تحرير طلب رقم العميل 102737', 1, 'مدير الموقع', 4, 2),
(384, 77, 76, '1573682400', '1572818400', '1573744154', '11-2019', NULL, NULL, 0, 0, 0, 'تم تحرير طلب رقم العميل 102737', 1, 'مدير الموقع', 0, 3),
(385, 15, 15, '1573682400', '1570831200', '1573744334', '11-2019', '1574287200', '', 0, 128, 1, 'تم متابعة العميل مرة أخرى والتواصل معه كان بيسال ع الاسكوتش الكريستال والاستيك وتم تبليغه بالاسعار وفى انتظار الرد', 1, 'مدير الموقع', 0, 2),
(386, 3, 3, '1573682400', '1570572000', '1573746085', '11-2019', '1573855200', '', 0, 128, 1, 'حصل قبل كده واتصلت بيه وبعتله الاسعار ع الواتس ومردش عليا تانى\r\nاتصلت بيه من حوالى يومين بعد ما هو اتصل بيا وقال انه كان عنده ظروف شخصيه لعدم الرد\r\nقولتله انى هعمل ابديت للاسعار وابعتهاله تانى', 1, 'مدير الموقع', 0, 2),
(387, 82, 81, '1573978742', '1573941600', '1573978742', '11-2019', '', NULL, 0, 0, 2, 'الجيزة \r\nالاستفسار عن الاستيك بأنواعه \r\nالعنوان ناهية الجيزة', 7, 'اسماء محمد', 0, 1),
(388, 82, 81, '1573941600', '1573941600', '1573978754', '11-2019', '1573941600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(389, 83, 82, '1573982219', '1573941600', '1573982219', '11-2019', '', NULL, 0, 0, 2, 'محمود ابوغريب \r\nالسلام عليكم مطلوب كرتونة شمع سيلكون مكتب ابو غريب للتجاره والتوريد\r\n٠١٠٠١٥٩٤٦٩٨\r\nالمحافظة القاهره\r\nالمنطقة المطريه', 1, 'مدير الموقع', 0, 1),
(390, 83, 82, '1573941600', '1573941600', '1573982231', '11-2019', '1573941600', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(391, 84, 83, '1574072309', '1574028000', '1574072309', '11-2019', '', NULL, 0, 0, 2, 'شركة الرضا للتجارة والتوريدات \r\nالهرم \r\nالاستفسار عن مسدس شمع G250', 7, 'اسماء محمد', 0, 1),
(392, 84, 83, '1574028000', '1574028000', '1574072705', '11-2019', '1574028000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(393, 85, 84, '1574158246', '1574114400', '1574158246', '11-2019', '', NULL, 0, 0, 2, 'بيت الجملة \r\nميامى الجديدة \r\nالاستفسار عن الاسترتش هاى ماكس', 7, 'اسماء محمد', 0, 1),
(394, 85, 84, '1574114400', '1574114400', '1574158255', '11-2019', '1574114400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(395, 86, 85, '1574169109', '1574114400', '1574169109', '11-2019', '', NULL, 0, 0, 2, 'محمد سيف \r\nميامى \r\nالاستفسار عن الاسترتش الغذائى \r\nوالمنزلى', 7, 'اسماء محمد', 0, 1),
(396, 86, 85, '1574114400', '1574114400', '1574169117', '11-2019', '1574114400', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(397, 85, 84, '1574200800', '1574114400', '1574239456', '11-2019', '', NULL, 0, 0, 0, 'تم التواصل و حيبعت ياخد 20ك 35 سم هاى ماكس و تم تسجيل العميل بأسم عالم الجملة فى ميامى الجديدة شارع مدرسة القدس 45', 1, 'مدير الموقع', 4, 2),
(398, 86, 85, '1574200800', '1574114400', '1574239533', '11-2019', NULL, NULL, 0, 0, 0, 'عنده شركة توريدات عرف اسعار الكلينج المصرى بمقاساتة و تمام شكراً يا باشا', 1, 'مدير الموقع', 0, 2),
(399, 85, 84, '1574200800', '1574114400', '1574239676', '11-2019', NULL, NULL, 0, 0, 0, 'كود العميل 102745', 1, 'مدير الموقع', 0, 3),
(400, 86, 85, '1574200800', '1574114400', '1574240052', '11-2019', NULL, NULL, 0, 0, 0, 'باحث عن سعر فقط', 1, 'مدير الموقع', 0, 3),
(401, 87, 86, '1574517477', '1574460000', '1574517477', '11-2019', '', NULL, 0, 0, 2, 'محمد مدحت\r\nمكتبة زووم الإسماعيلية\r\n01202070066\r\nبكر الزينة الكوريشة السلوتيب العريض الشفاف والليزر وشنط الهدايا', 1, 'مدير الموقع', 0, 1),
(402, 87, 86, '1574460000', '1574460000', '1574517490', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(403, 88, 87, '1574517884', '1574460000', '1574517884', '11-2019', '', NULL, 0, 0, 2, 'مكتبة المكتبة \r\nحدائق الأهرام \r\nأحمد يوسف\r\n01141166677', 1, 'مدير الموقع', 0, 1),
(404, 88, 87, '1574460000', '1574460000', '1574517894', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(405, 90, 89, '1574519382', '1574460000', '1574519382', '11-2019', '', NULL, 0, 0, 2, 'دمياط - عزبة البرج \r\nالاستفسار عن الاسكوتش 60 ياردة', 7, 'اسماء محمد', 0, 1),
(406, 90, 89, '1574460000', '1574460000', '1574519395', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(407, 89, 88, '1574519379', '1574460000', '1574519379', '11-2019', '', NULL, 0, 0, 2, 'شركة مصر الفراعنة \r\nأ / ايمن صبرى \r\nالقليوبية - الخانكة - الجبل الاصفر \r\nالاستفسار عن الاسكوتش المطبوع', 7, 'اسماء محمد', 0, 1),
(408, 89, 88, '1574460000', '1574460000', '1574519563', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(409, 80, 79, '1574460000', '1573336800', '1574520595', '11-2019', '1574460000', '', 0, 128, 1, 'تم التواصل من قبل العميل من حساب اخر \r\nرقم الحساب \r\n100006851108112\r\nتم اضافة المتابعة على ترلو \r\nنرجو التواصل مع العميل\r\nوتحديد جدية العميل فى التعامل\r\nوشكرا', 1, 'مدير الموقع', 0, 2),
(410, 91, 90, '1574522995', '1574460000', '1574522995', '11-2019', '', NULL, 0, 0, 2, 'انا عميل معاكوا كنت اخد فاتوره مرتين من استاذ محمد انور \r\nبعد كده محدش عاد تابع معايا\r\n\r\nمكتبه جمله\r\n- السلوتب\r\n- شريط العصفور\r\n- شمع اللحام\r\n- شكرتون الكهرباء\r\n- مسدسات الشمع\r\n- شنط الهدايا\r\n- اي حاجه تمشي مع المكتبات', 1, 'مدير الموقع', 0, 1),
(411, 91, 90, '1574460000', '1574460000', '1574523009', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(412, 92, 91, '1574525134', '1574460000', '1574525134', '11-2019', '', NULL, 0, 0, 2, 'انا عميل قديم من 8سنين \r\nعامر محمد عبد العزيز الحمصاني\r\nفرعين المنشية وللمؤسسات - وباكوس\r\n\r\nعندك شمع سليكون اصفر سعره كام والوزن وشفاف\r\nتمام طيب فيه شمع اصفر\r\nياريت يكلموني', 1, 'مدير الموقع', 0, 1),
(413, 92, 91, '1574460000', '1574460000', '1574525147', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(414, 93, 92, '1574536124', '1574460000', '1574536124', '11-2019', '', NULL, 0, 0, 2, '01111185140\r\nممكن اشوف المنتجات التانية غير السولتب\r\nجملة مكتبات', 1, 'مدير الموقع', 0, 1),
(415, 93, 92, '1574460000', '1574460000', '1574536138', '11-2019', '1574460000', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(416, 92, 91, '1574546400', '1574460000', '1574625632', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل سأل عن شمع اللحام ملون و بداخلة جليتر موجود فى السوق بنسبة بسيطة اوى\r\nسأل عن شمع اللحام العادى و قال حيشوف و حيبقى يكلمنى ان شاء الله\r\nشكر الشركة و الادارة على الاهتمام و سرعة التواصل', 1, 'مدير الموقع', 0, 2),
(417, 92, 91, '1574546400', '1574460000', '1574625685', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل واغلاق التذكرة', 1, 'مدير الموقع', 0, 3),
(418, 84, 83, '1574719200', '1574028000', '1574789999', '11-2019', NULL, NULL, 0, 0, 0, 'تم الاتصال بالعميل وارسال صورة المسدس ويوجد مماطله منه وبيقول انه لسه لم يقابل المديرين خاصته', 1, 'مدير الموقع', 0, 2),
(419, 83, 82, '1574719200', '1573941600', '1574790211', '11-2019', NULL, NULL, 0, 0, 0, 'العميل اتصل عليا وغير جاد في التعامل', 1, 'مدير الموقع', 0, 2),
(420, 82, 81, '1574719200', '1573941600', '1574790361', '11-2019', NULL, NULL, 0, 0, 0, 'تم التواصل مع العميل وغير جاد في التعامل', 1, 'مدير الموقع', 0, 2),
(421, 84, 83, '1574719200', '1574028000', '1574790443', '11-2019', NULL, NULL, 0, 0, 0, 'تم اغلاق التذكرة', 1, 'مدير الموقع', 0, 3),
(422, 83, 82, '1574719200', '1573941600', '1574790451', '11-2019', NULL, NULL, 0, 0, 0, 'تم اغلاق التذكرة', 1, 'مدير الموقع', 0, 3),
(423, 82, 81, '1574719200', '1573941600', '1574790459', '11-2019', NULL, NULL, 0, 0, 0, 'تم اغلاق التذكرة', 1, 'مدير الموقع', 0, 3),
(424, 94, 93, '1574929125', '1574892000', '1574929125', '11-2019', '', NULL, 0, 0, 2, 'شركة مبادرة \r\nالاسكندرية - ميدان الساعة - فيكتوريا \r\nالاستفسار عن الشيكرتون', 7, 'اسماء محمد', 0, 1),
(425, 94, 93, '1574892000', '1574892000', '1574929133', '11-2019', '1574892000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(426, 95, 94, '1574929652', '1574892000', '1574929652', '11-2019', '', NULL, 0, 0, 2, 'نجوى عصمت \r\nمصر الجديدة \r\nالاستفسار عن \r\nالاسكوتش - الاسترتش - دبل فيس', 7, 'اسماء محمد', 0, 1),
(427, 95, 94, '1574892000', '1574892000', '1574929728', '11-2019', '1574892000', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(428, 96, 95, '1575214425', '1575151200', '1575214425', '12-2019', '', NULL, 0, 0, 2, 'محتاج استفسر ع مكن اللصق والفويل عرض ٣٠سم\r\nوآخر مره سالت على مكن اللصق مش موجود ياريت تشفهولى هو كمان أنا محتاج كرتونة مكن كاملة\r\n\r\nمحافظة البحيرة ٠١٠٩٣٩٩٠٢٨١\r\nمركز أبو حمص محل ندا بلاست لتجارة الموازين الكمبيوتر وأدوات الطباخة والورقيات', 7, 'اسماء محمد', 0, 1),
(429, 96, 95, '1575151200', '1575151200', '1575214575', '12-2019', '1575151200', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(430, 97, 96, '1575271371', '1575237600', '1575271371', '12-2019', '', NULL, 0, 0, 2, 'التعرف على منتجات الشركة \r\nوالاستفسار عن \r\nال30 /35/40\r\nالاستندر', 7, 'اسماء محمد', 0, 1),
(431, 97, 96, '1575237600', '1575237600', '1575271381', '12-2019', '1575237600', '', 0, 130, 1, 'اضافة متابعة اليوم', 7, 'اسماء محمد', 0, 2),
(432, 94, 93, '1575324000', '1574892000', '1575383259', '12-2019', NULL, NULL, 0, 0, 0, 'تسجيل بيانات بالخطاء', 1, 'مدير الموقع', 0, 2),
(433, 94, 93, '1575324000', '1574892000', '1575383297', '12-2019', NULL, NULL, 0, 0, 0, 'تسجيل بيانات بالخطاء', 1, 'مدير الموقع', 0, 3),
(434, 98, 97, '1695633649', '1695592800', '1695633649', '9-2023', '', NULL, 0, 0, 2, 'ملاحظات', 1, 'مدير الموقع', 0, 1),
(435, 98, 97, '1695592800', '1695592800', '1695633664', '9-2023', '1695592800', '', 0, 130, 1, 'اضافة متابعة اليوم', 1, 'مدير الموقع', 0, 2),
(436, 98, 97, '1695592800', '1695592800', '1695633685', '9-2023', '1695592800', '', 1, 128, 1, 'نص المحادثة', 1, 'مدير الموقع', 0, 2),
(437, 98, 97, '1695592800', '1695592800', '1695633700', '9-2023', '', NULL, 0, 0, 0, 'تفاصيل الزيارة', 1, 'مدير الموقع', 1, 2),
(438, 98, 97, '1695592800', '1695592800', '1695633759', '9-2023', NULL, NULL, 0, 0, 0, 'سبب الاغلاق', 1, 'مدير الموقع', 0, 2),
(439, 98, 97, '1695592800', '1695592800', '1695633816', '9-2023', '1695592800', '', 1, 128, 1, 'تعليق خدمة العملاء', 1, 'مدير الموقع', 0, 3),
(440, 98, 97, '1695592800', '1695592800', '1695633885', '9-2023', NULL, NULL, 0, 0, 0, 'تعليق خدمة العملاء', 1, 'مدير الموقع', 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sms_report`
--

CREATE TABLE `sms_report` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_time` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci,
  `count` int(11) DEFAULT '0',
  `total` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `user_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `user_password` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `group_id` int(11) NOT NULL,
  `group_state` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mobile` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_login` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_seen` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `seen_state` int(11) DEFAULT '0',
  `sales` int(11) DEFAULT '0',
  `team_leader` int(11) DEFAULT '0',
  `custserv` int(11) DEFAULT '0',
  `custserv_leader` int(11) DEFAULT '0',
  `pass_date` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pass_expird` int(11) DEFAULT '0',
  `google_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `telegram_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `lang` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_follow` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `user_name`, `user_password`, `group_id`, `group_state`, `name`, `email`, `mobile`, `last_login`, `last_seen`, `seen_state`, `sales`, `team_leader`, `custserv`, `custserv_leader`, `pass_date`, `pass_expird`, `google_code`, `telegram_code`, `photo`, `lang`, `user_follow`, `state`) VALUES
(1, 'admin', '30da7cf9eeb9ad7daa56d44a880b9d9a', 1, 1, 'مدير الموقع', 'hany@hanydarwish.com', '01221563252', '1695632829', '1695633901', 1, 0, 0, 0, 0, NULL, 0, 'PEMXBOSP374OEAQX', '', NULL, '1', '0', 1),
(2, 'm.khamis', '5c2c623b35c0fd5f42bb82df80cf3b2d', 2, 1, 'محمد خميس', 'm.khames@etmantape.net', '01203656545', '1570114035', '1570115215', 0, 1, 0, 0, 0, '1570053600', 0, 'XLVGBCY327KSUWRT', '', NULL, NULL, '0', 1),
(3, 'm.anwar', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 'محمد أنور', 'm.anwar@etmantape.net', '01006602018', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, '6T3ZK2I2DA5G4TRM', '', NULL, NULL, '0', 1),
(4, 'm.abdelsalam', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 'محمد عبد السلام', 'm.abdelsalam@etmangroup.com', '01287418315', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, '27KSA57OWOQMU3HR', '', NULL, NULL, '0', 1),
(5, 'mu.abdelsalam', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 'محمود عبد السلام', 'm.abdelslam@etmantape.net', '01276989612', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, '5ZPWIPXHPWEH7VGJ', '', NULL, NULL, '0', 1),
(6, 'm.hisham', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 'محمد  هشام', 'hesham@etmantape.net', '01270368828', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, 'ZWZNE5URDGODDPSL', '', NULL, NULL, '0', 1),
(7, 'asma.mohamed', '9f4c7ea317e1e46d26604a922cbadc54', 8, 1, 'اسماء محمد', 'a.fahmy@etmantape.net', '0125888888787987', '1575271363', '1575271387', 1, 1, 0, 0, 0, NULL, 0, 'ZAIGKZXBEZBPA6S7', '', NULL, NULL, 'a:7:{i:0;s:1:\"2\";i:1;s:1:\"3\";i:2;s:1:\"4\";i:3;s:1:\"5\";i:4;s:1:\"6\";i:5;s:1:\"7\";i:6;s:1:\"8\";}', 1),
(8, 'h.ibrahim', '66a8d749aa6a43a71299c2ac6b99449a', 2, 1, 'هادى ابراهيم', 'h.ibrahim@etmangroup.com', '012221545454545', '1572349518', '1572350076', 0, 1, 0, 0, 0, NULL, 0, 'BICX7L4OGVG6Q2TT', '', NULL, NULL, '0', 1),
(9, 'mina.cairo', '02b50279514be1906f478828151067b3', 2, 1, 'مينا مناس', 'mina.cairo@etmantape.net', '01275666465', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, 'V3IKZI77IHQIHEAF', '', NULL, NULL, '0', 1),
(10, 'a.fawzi', '0bfa35d095d6d2815ba30af43e692e58', 2, 1, 'احمد فوزى', 'a.fawzi@etmantape.net', '01224141408', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, '3WJNHTVBE6GM6VVH', '', NULL, NULL, '0', 1),
(11, 'a.bakr', '6b32a864a4f13c4e979cd21b979ba3ca', 10, 1, 'أ.ايمن بكر', 'a.bakr@etmantape.net', '01032977744', '1572947989', '1572947999', 0, 0, 1, 0, 0, NULL, 0, 'MPWRYQNYTQRPGMMR', '', NULL, NULL, 'a:12:{i:0;s:1:\"2\";i:1;s:1:\"3\";i:2;s:1:\"4\";i:3;s:1:\"5\";i:4;s:1:\"6\";i:5;s:1:\"8\";i:6;s:1:\"9\";i:7;s:2:\"10\";i:8;s:2:\"12\";i:9;s:2:\"13\";i:10;s:1:\"7\";i:11;s:2:\"11\";}', 1),
(12, 'alexadria', '72243abe689f08264b11ca56881d3965', 2, 1, 'غرب الاسكندرية', 'Alex@etman-group.com', '01222222222222222', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, 'F4HJWXSY3HAEI2YD', '', NULL, NULL, '0', 1),
(13, 'a.wagih', 'e10adc3949ba59abbe56e057f20f883e', 2, 1, 'احمد وجيه', 'a.wagih@hanydarwish.com', '01224610041', NULL, NULL, 0, 1, 0, 0, 0, NULL, 0, 'IXRSP4MFZHGAJBSZ', '', NULL, NULL, '0', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_group`
--

CREATE TABLE `user_group` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_group`
--

INSERT INTO `user_group` (`id`, `name`, `count`, `state`) VALUES
(1, 'مدير الموقع', 1, 1),
(2, 'مبيعات', 10, 1),
(3, 'خدمة عملاء', 0, 1),
(7, 'التسويق', 0, 1),
(8, 'مدير مبيعات', 1, 1),
(9, 'مشرف خدمة عملاء', 0, 1),
(10, 'مدير مبيعات كامل الصلاحية', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_permission`
--

CREATE TABLE `user_permission` (
  `id` int(11) NOT NULL,
  `group_id` int(11) DEFAULT '0',
  `admin` int(11) DEFAULT '0',
  `web_manage` int(11) DEFAULT '0',
  `project` int(11) DEFAULT '0',
  `project_add` int(11) DEFAULT '0',
  `project_edit` int(11) DEFAULT '0',
  `project_dell` int(11) DEFAULT '0',
  `contract` int(11) DEFAULT '0',
  `contract_add` int(11) DEFAULT '0',
  `contract_edit` int(11) DEFAULT '0',
  `contract_dell` int(11) DEFAULT '0',
  `customer` int(11) DEFAULT '0',
  `customer_add` int(11) DEFAULT '0',
  `customer_edit` int(11) DEFAULT '0',
  `customer_dell` int(11) DEFAULT '0',
  `custserv` int(11) DEFAULT '0',
  `custserv_add` int(11) DEFAULT '0',
  `custserv_edit` int(11) DEFAULT '0',
  `custserv_dell` int(11) DEFAULT '0',
  `salesdep` int(11) DEFAULT '0',
  `salesdep_add` int(11) DEFAULT '0',
  `salesdep_edit` int(11) DEFAULT '0',
  `salesdep_dell` int(11) DEFAULT '0',
  `closedticket` int(11) DEFAULT '0',
  `closedticket_add` int(11) DEFAULT '0',
  `closedticket_edit` int(11) DEFAULT '0',
  `closedticket_dell` int(11) DEFAULT '0',
  `salesfollow` int(11) DEFAULT '0',
  `salesfollow_add` int(11) DEFAULT '0',
  `salesfollow_edit` int(11) DEFAULT '0',
  `salesfollow_dell` int(11) DEFAULT '0',
  `managedate` int(11) DEFAULT '0',
  `managedate_add` int(11) DEFAULT '0',
  `managedate_edit` int(11) DEFAULT '0',
  `managedate_dell` int(11) DEFAULT '0',
  `leads` int(11) DEFAULT '0',
  `leads_add` int(11) DEFAULT '0',
  `leads_edit` int(11) DEFAULT '0',
  `leads_dell` int(11) DEFAULT '0',
  `hotline` int(11) DEFAULT '0',
  `hotline_add` int(11) DEFAULT '0',
  `hotline_edit` int(11) DEFAULT '0',
  `hotline_dell` int(11) DEFAULT '0',
  `report` int(11) DEFAULT '0',
  `report_add` int(11) DEFAULT '0',
  `report_edit` int(11) DEFAULT '0',
  `report_dell` int(11) DEFAULT '0',
  `lppage` int(11) DEFAULT '0',
  `lppage_add` int(11) DEFAULT '0',
  `lppage_edit` int(11) DEFAULT '0',
  `lppage_dell` int(11) DEFAULT '0',
  `sendsms` int(11) DEFAULT '0',
  `sendsms_add` int(11) DEFAULT '0',
  `sendsms_edit` int(11) DEFAULT '0',
  `sendsms_dell` int(11) DEFAULT '0',
  `teamleader` int(11) DEFAULT '0',
  `suberteamleader` int(11) DEFAULT '0',
  `custservleader` int(11) DEFAULT '0',
  `subercustserv` int(11) DEFAULT '0',
  `userprofile` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_permission`
--

INSERT INTO `user_permission` (`id`, `group_id`, `admin`, `web_manage`, `project`, `project_add`, `project_edit`, `project_dell`, `contract`, `contract_add`, `contract_edit`, `contract_dell`, `customer`, `customer_add`, `customer_edit`, `customer_dell`, `custserv`, `custserv_add`, `custserv_edit`, `custserv_dell`, `salesdep`, `salesdep_add`, `salesdep_edit`, `salesdep_dell`, `closedticket`, `closedticket_add`, `closedticket_edit`, `closedticket_dell`, `salesfollow`, `salesfollow_add`, `salesfollow_edit`, `salesfollow_dell`, `managedate`, `managedate_add`, `managedate_edit`, `managedate_dell`, `leads`, `leads_add`, `leads_edit`, `leads_dell`, `hotline`, `hotline_add`, `hotline_edit`, `hotline_dell`, `report`, `report_add`, `report_edit`, `report_dell`, `lppage`, `lppage_add`, `lppage_edit`, `lppage_dell`, `sendsms`, `sendsms_add`, `sendsms_edit`, `sendsms_dell`, `teamleader`, `suberteamleader`, `custservleader`, `subercustserv`, `userprofile`) VALUES
(1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1),
(2, 2, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(3, 3, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1),
(7, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 1),
(8, 8, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1),
(9, 9, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1),
(10, 10, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_regulations`
--

CREATE TABLE `user_regulations` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8_unicode_ci NOT NULL,
  `grouplist` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user_regulations`
--

INSERT INTO `user_regulations` (`id`, `cat_id`, `name`, `des`, `grouplist`, `postion`, `state`) VALUES
(1, 1, 'العنوان الاول', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\r\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\r\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\r\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', '-1-', 1, 1),
(2, 1, 'العنوان الثانى', 'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.\r\nإذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد، النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربى مفيد لمصممي المواقع على وجه الخصوص، حيث يحتاج العميل فى كثير من الأحيان أن يطلع على صورة حقيقية لتصميم الموقع.\r\nومن هنا وجب على المصمم أن يضع نصوصا مؤقتة على التصميم ليظهر للعميل الشكل كاملاً،دور مولد النص العربى أن يوفر على المصمم عناء البحث عن نص بديل لا علاقة له بالموضوع الذى يتحدث عنه التصميم فيظهر بشكل لا يليق.\r\nهذا النص يمكن أن يتم تركيبه على أي تصميم دون مشكلة فلن يبدو وكأنه نص منسوخ، غير منظم، غير منسق، أو حتى غير مفهوم. لأنه مازال نصاً بديلاً ومؤقتاً.', '-1-', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `x_admin_lang_cat`
--

CREATE TABLE `x_admin_lang_cat` (
  `id` int(11) NOT NULL,
  `cat_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count_unit` int(11) DEFAULT '0',
  `count_unit_a` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `x_admin_lang_cat`
--

INSERT INTO `x_admin_lang_cat` (`id`, `cat_id`, `name`, `name_en`, `count_unit`, `count_unit_a`, `postion`) VALUES
(1, 'home', 'الرئيسية', 'Home', 19, 19, 1),
(2, 'mainform', 'المتغيرات الاساسية', 'Basic Variables', 147, 147, 4),
(3, 'adminlang', 'اعدادات اللغة لوحة التحكم', 'Admin Lang', 33, 33, 21),
(4, 'sitelang', 'اعدادات اللغة واجهة الموقع', 'Website Lang', 28, 28, 22),
(5, 'user_profile', 'ادارة المستخدمين', 'Manage User Profile', 3, 3, 36),
(6, 'webconfig', 'ادارة اعدادات الموقع', 'Web Config', 58, 58, 43),
(7, 'project', 'المشاريع', 'Project', 80, 80, 45),
(8, 'pro_price', 'جدول الاسعار', 'جدول الاسعار', 33, 33, 46),
(9, 'pdf', 'PDF File', 'PDF File', 30, 30, 47),
(10, 'contract', 'ادارة التعاقدات', 'ادارة التعاقدات', 64, 64, 48),
(11, 'customer', 'ادارة العملاء', 'Customer', 74, 74, 49),
(12, 'users', 'الاعضاء والصلاحيات', 'الاعضاء والصلاحيات', 86, 86, 50),
(13, 'managedate', 'ادارة البيانات', 'ادارة البيانات', 84, 84, 51),
(14, 'hotline', 'Hot Line', 'Hot Line', 6, 6, 52),
(15, 'leads', 'ادارة اليديز', 'Manage Leads', 63, 63, 53),
(16, 'salesdep', 'متابعة العملاء', 'Customer Follow', 52, 52, 54),
(17, 'ticket', 'التذاكر', 'Tickets', 61, 61, 55),
(18, 'close_ticket', 'اغلاق التذاكر', 'اغلاق التذاكر', 13, 13, 56),
(19, 'custserv', 'خدمة العملاء', 'خدمة العملاء', 32, 32, 57),
(20, 'report', 'التقارير', 'Report', 125, 125, 58),
(21, 'reportconfig', 'اعدادات التقارير', 'Report Config', 16, 16, 59),
(22, 'lppage', 'صفحات الهبوط', 'Landing Page', 80, 80, 0),
(23, 'mainconfig', 'اعدادات عامة', 'اعدادات عامة', 90, 90, 0),
(24, 'backup', 'نسخ احطياطى', 'Back Up', 17, 17, 0),
(25, 'dashboard', 'Dashboard', 'Dashboard', 6, 6, 0),
(26, 'blue', 'blue', 'blue', 7, 7, 0),
(27, 'sms', 'sms', 'sms', 22, 22, 0),
(28, 'managweb', 'Manage Web', 'Manage Web', 12, 12, 0),
(29, 'closedticket', 'التذاكر المغلقة', 'التذاكر المغلقة', 3, 3, 0),
(30, 'test', 'Testrr', 'Test', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_admin_lang_var`
--

CREATE TABLE `x_admin_lang_var` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `var` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` text COLLATE utf8_unicode_ci,
  `name_en` text COLLATE utf8_unicode_ci,
  `state` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `x_admin_lang_var`
--

INSERT INTO `x_admin_lang_var` (`id`, `cat_id`, `var`, `name`, `name_en`, `state`, `postion`) VALUES
(1, 1, 'welcome', 'اهلا وسهلا بك', 'Welcome Back', 1, 0),
(2, 1, 'home', 'الصفحة الرئيسية', 'Home Page', 1, 0),
(3, 1, 'siteview', 'واجهة الموقع', 'Web Site View', 1, 0),
(4, 1, 'menuposion', 'ترتيب القوائم', 'Order Menu', 1, 0),
(5, 1, 'logout', 'تسجيل الخروج', 'LogOut', 1, 0),
(6, 1, 'sitesettings', 'اعدادات الموقع', 'Site Settings', 1, 0),
(7, 1, 'generalsettings', 'الاعدادات العامة', 'General Settings', 1, 0),
(8, 1, 'languagesettings', 'اعدادات اللغة', 'Language Settings', 1, 0),
(9, 1, 'userpermission', 'صلاحيات الاعضاء', 'User Permission', 1, 0),
(10, 1, 'currencysettings', 'اعدادات اختيار العملة', 'Currency Settings', 1, 0),
(11, 1, 'pagessettings', 'اعدادات عرض الصفحات', 'Pages Settings', 1, 0),
(12, 1, 'defaultimage', 'اعدادات الصور الافتراضية', 'Default Image', 1, 0),
(13, 1, 'metatage', 'الكلمات الدالة', 'Meta Tags', 1, 0),
(14, 1, 'emailsettings', 'اعدادات البريد الالكترونى', 'Email Settings', 1, 0),
(15, 1, 'contactussettings', 'اعدادات اتصل بنا', 'Contact Us Settings', 1, 0),
(16, 1, 'sitemap', 'خريطة الموقع', 'Site Map', 1, 0),
(17, 1, 'changepassword', 'تغيير كلمة المرور', 'Change Password', 1, 0),
(18, 1, 'backup', 'نسخ احتياطى', 'Back Up', 1, 0),
(19, 1, 'websitestatistics', 'احصائيات الموقع', 'Website Statistics', 1, 0),
(20, 2, 'radio_active', 'فعال', 'Active', 1, 0),
(21, 2, 'radio_inactive', 'غير فعال', 'Inactive', 1, 0),
(22, 2, 'edit', 'تعديل', 'Edit', 1, 0),
(23, 2, 'delete', 'حذف', 'Delete', 1, 0),
(24, 2, 'activation', 'تفعيل', 'Activation', 1, 0),
(25, 2, 'disable', 'تعطيل', 'Disable', 1, 0),
(26, 2, 'state', 'الحالة', 'State', 1, 0),
(27, 2, 'list_by_order', 'العرض وفقا للترتيب', 'List By Order', 1, 0),
(28, 2, 'newest_to_older', 'الترتيب من الاحدث الى الاقدم', 'Order From Newest to Older', 1, 0),
(29, 2, 'older_to_newest', 'الترتيب من الاقدم الى الاحدث', 'Order From Older to Newest', 1, 0),
(30, 2, 'order_by_date', 'الترتيب وفقا للتاريخ', 'Order By Date', 1, 0),
(31, 2, 'u_redirect_new', 'اضافة جديدة', 'Add New Entry', 1, 0),
(32, 2, 'u_redirect_list', 'عرض محتوى القسم', 'List Content', 1, 0),
(33, 2, 'u_redirect_config', 'عرض الاعدادات', 'View Settings', 1, 0),
(34, 2, 'u_redirect_same', 'عرض نفس المحتوى', 'Redirect To Same Content', 1, 0),
(35, 2, 'no_change_image_dimensions', 'لا تقم بضبط ابعاد الصورة', 'Don\'t Change Image Dimensions', 1, 0),
(36, 2, 'image_dimensions_background', 'تصغير الصورة وفقا للابعاد المحددة مع اضافة خلفية', 'Resize Image Dimensions  with the addition of background', 1, 0),
(37, 2, 'image_dimensions_to_width', 'تقليص ابعاد الصورة وفقا للعرض', 'Resize Image Dimensions Related to Width', 1, 0),
(38, 2, 'image_dimensions_to_height', 'تقليص ابعاد الصورة وفقط للطول', 'Resize Image Dimensions Related to Height', 1, 0),
(39, 2, 'image_dimensions_to_width_height', 'تقليص ابعاد الصورة وفقا للطول والعرض', 'Resize Image Dimensions Related to Width and Height', 1, 0),
(40, 2, 'image_crop_to_width_height', 'قص الصورة وفقا للابعاد المحدد', 'Crop Image Dimensions Related to Width and Height', 1, 0),
(41, 2, 'tap_category_settings', 'اعدادات المجموعات', 'Category Settings', 1, 0),
(42, 2, 'tap_section_settings', 'اعدادات القسم', 'Section Settings', 1, 0),
(43, 2, 'tap_fields_settings', 'اعدادات الحقول', 'Fields Settings', 1, 0),
(44, 2, 'tap_seo_settings', 'اعدادات الكلمات الدالة', 'SEO Settings', 1, 0),
(45, 2, 'tap_watermark_settings', 'اعدادات العلامة المائية', 'Watermark Settings', 1, 0),
(46, 2, 'tap_general_settings', 'الاعدادات العامة', 'General Settings', 1, 0),
(47, 2, 'tap_additional_photo_settings', 'اعدادات الصور الاضافية', 'Additional Photo Settings', 1, 0),
(48, 2, 'tap_sours_settings', 'اعدادات المصدر', 'Sours Settings', 1, 0),
(49, 2, 'c_redirect_new', 'اضافة مجموعة جديدة', 'Add New Category', 1, 0),
(50, 2, 'c_redirect_list', 'عرض المجموعات', 'List Category', 1, 0),
(51, 2, 'c_redirect_config', 'عرض الاعدادات', 'View Settings', 1, 0),
(52, 2, 'c_redirect_same', 'عرض نفس المجموعة', 'Redirect To Same Category', 1, 0),
(53, 2, 'auto_delete_mass', 'الحذف التلقائى فعال', 'Automatic Delete Active', 1, 0),
(54, 2, 'sel_cat', 'المجموعة', 'Category', 1, 0),
(55, 2, 'save_lastcat', 'الاحتفاظ باخر مجموعة', 'Save Last Category', 1, 0),
(56, 2, 'current_photo', 'الصورة الحالية', 'Current Photo', 1, 0),
(57, 2, 'menu_search_tools', 'ادوات البحث', 'Search Tools', 1, 0),
(58, 2, 'menu_use_editor', 'الاضافة باستخدام المحرر', 'Add With Editor', 1, 0),
(59, 2, 'menu_remove_editor', 'الاضافة بدون محرر النصوص', 'Add Without Editor', 1, 0),
(60, 2, 'menu_edit_meta', 'ضبط الكلمات الدالة', 'Edit SEO', 1, 0),
(61, 2, 'menu_add_more_photo', 'اضافة المزيد من الصور', 'Add More Photo', 1, 0),
(62, 2, 'menu_add_more_file', 'اضافة ملفات', 'Attache Files', 1, 0),
(63, 2, 'editor_settings_len', 'اعدادات محرر النصوص', 'Editor Settings', 1, 0),
(64, 2, 'unit_add_photo_option', 'اختيارى', 'Option', 1, 0),
(65, 2, 'unit_add_photo_require', 'اجبارى', 'Require', 1, 0),
(66, 2, 'fields_same_photo', 'نفس الصورة', 'Same Photo', 1, 0),
(67, 2, 'fields_two_photo', 'صورتين', 'Two Photos', 1, 0),
(68, 2, 'watermark_top_right', 'اعلى اليمين', 'Top Right', 1, 0),
(69, 2, 'watermark_top_left', 'اعلى اليسار', 'Top Left', 1, 0),
(70, 2, 'watermark_center', 'المنتصف', 'Center', 1, 0),
(71, 2, 'watermark_bottom_right', 'اسفل اليمين', 'Bottom Right', 1, 0),
(72, 2, 'watermark_bottom_left', 'اسفل اليسار', 'Bottom Left', 1, 0),
(73, 2, 'more_photo_edit_h1', 'تعديل الوصف للصورة', 'Edit Photo Description', 1, 0),
(74, 2, 'more_photo_postion_h1', 'ترتيب الصور', 'Order Photo', 1, 0),
(75, 2, 'more_file_postion_h1', 'ترتيب الملفات', 'File Order', 1, 0),
(76, 2, 'tap_cat_settings', 'اعدادات المجموعة', 'Category Settings', 1, 0),
(77, 2, 'lang_redirect_new', 'اضافة محتوى جديد', 'Add New Entry', 1, 0),
(78, 2, 'lang_redirect_list', 'عرض المحتوى', 'List Content', 1, 0),
(79, 2, 'lang_redirect_list_update', 'عرض المحتوى مع تحديث البيانات', 'List Content after Update Content', 1, 0),
(80, 2, 'lang_redirect_list_cat', 'عرض المحتوى التابع للمجموعة', 'List Content Related To Category', 1, 0),
(81, 2, 'err_this_name_already_exists', 'الاسم مستخدم من من قبل', 'This Name Already Exists', 1, 0),
(82, 2, 'category_has_been_set', 'تم ضبط المجموعات', 'Category has been set', 1, 0),
(83, 2, 'confirmed_existence_language_file', 'تم التاكد من وجود ملف اللغة', 'Been confirmed the existence of the language file', 1, 0),
(84, 2, 'language_file_path_is_incorrect', 'مسار ملف اللغة غير صحيح', 'Language file path is incorrect', 1, 0),
(85, 2, 'language_file_has_been_updated', 'تم تحديث ملف اللغة', 'Language file has been updated', 1, 0),
(86, 2, 'can_not_deleted_category', 'لا يمكن حذف المجموعة -->', 'Can Not Deleted Category -->', 1, 0),
(87, 2, 'contactc_account_name', 'الحساب المستخدم فى الارسال', 'Account Name', 1, 0),
(88, 2, 'contactc_received_email', 'يتم استلام الرسائل على الحساب', 'Received Message At', 1, 0),
(89, 2, 'contactc_captcha_state', 'حالة الكود العشوائى', 'Captcha State', 1, 0),
(90, 2, 'contactc_auto_reply_state', 'حالة الرد التلقائى', 'Auto Reply State', 1, 0),
(91, 2, 'contactc_auto_reply_received_title', 'عنوان الرسالة المستلمة', 'Auto Reply Received Title', 1, 0),
(92, 2, 'contactc_auto_reply_send_title', 'عنوان رسالة الرد التلقائى', 'Auto Reply Send Title', 1, 0),
(93, 2, 'contactc_auto_reply_message', 'راسالة الرد التقائى', 'Auto Reply Message', 1, 0),
(94, 2, 'print_form_please_select', 'اختيار', 'Select', 1, 0),
(95, 2, 'product_this_code_already_exists', 'كود المنتج مستخدم من قبل', 'This code Already Exists', 1, 0),
(96, 2, 'removephoto', 'حذف الصورة', 'Remove Photo', 1, 0),
(97, 2, 'add_but', 'اضافة', 'Add', 1, 0),
(98, 2, 'edit_but', 'تعديل', 'Edit', 1, 0),
(99, 2, 'search_but', 'بحث', 'Search', 1, 0),
(100, 2, 'filter_search', 'بحث بـ', 'Filter', 1, 0),
(101, 2, 'alert_no_content', 'لا يوجد محتوى للعرض', 'There is no content to display', 1, 0),
(102, 2, 'update', 'تحديث', 'Update', 1, 0),
(103, 2, 'filter_cat', 'فلترة المجموعات', 'Filter Category', 1, 0),
(104, 2, 'filter_con', 'فلترة المحتوى', 'Filter Content', 1, 0),
(105, 2, 'duplicated_data', 'برجاء التاكد من عدم تكرار البيانات المدرجة', 'Please ensure that the data listed is not duplicated', 1, 0),
(106, 2, 'err_already_exists', 'موجود بالفعل لـ', 'Already Exists For', 1, 0),
(107, 2, 'err_record_id', 'رقم السجل', 'Record ID', 1, 0),
(108, 2, 'but_close', 'اغلق', 'Close', 1, 0),
(109, 2, 'but_addnew', 'اضافة', 'Add New', 1, 0),
(110, 2, 'start_typing', 'ابداء بالكتابة لكى يبدء البحث', 'Start typing for search', 1, 0),
(111, 2, 'no_results', 'لا توجد نتائج', 'No results', 1, 0),
(112, 2, 'searching', 'جارى البحث', 'Searching...', 1, 0),
(113, 2, 'no_user_per', 'عضويتك لا تملك الصلاحية', 'Your membership does not have permission', 1, 0),
(114, 2, 'canceled_but', 'الغاء', 'Cancel', 1, 0),
(115, 2, 'name_add_err', 'الاسم مستخدم من قبل برجاء المراجعة', 'الاسم مستخدم من قبل برجاء المراجعة', 1, 0),
(116, 2, 'confirm_dell_mass', 'هل انت متاكد من حذف', 'هل انت متاكد من حذف', 1, 0),
(117, 2, 'err_dell_mass', 'لا يمكن حذف هذا المحتوى', 'لا يمكن حذف هذا المحتوى', 1, 0),
(118, 2, 'confirm_but', 'تاكيد', 'تاكيد', 1, 0),
(119, 2, 'close_but', 'اغلاق', 'Close', 1, 0),
(120, 3, 'menu_ul', 'ضبط لغة لوحة التحكم', 'Admin Language', 1, 0),
(121, 3, 'menu_cat_add', 'اضافة مجموعة', 'Add Category', 1, 0),
(122, 3, 'menu_cat_list', 'عرض المجموعات', 'List Category', 1, 0),
(123, 3, 'menu_unit_add', 'اضافة محتوى', 'Add Content', 1, 0),
(124, 3, 'menu_unit_list', 'عرض المحتوى', 'List Content', 1, 0),
(125, 3, 'menu_config', 'اعدادات القسم', 'Settings', 1, 0),
(126, 3, 'menu_update_lang', 'تحديث ملفات اللغة', 'Update Language File', 1, 0),
(127, 3, 'menu_search', 'ادوات البحث', 'Search Tools', 1, 0),
(128, 3, 'main_h1', 'ادارة ملفات لغة لوحة التحكم', 'Mange Admin Language File', 1, 0),
(129, 3, 'h1_catedit', 'تعديل مجموعة', 'Edit Category', 1, 0),
(130, 3, 'h1_cat_dell', 'حذف مجموعة', 'Delete Category', 1, 0),
(131, 3, 'cat_dell_mass', 'فى حالة حذف المجموعة سيتم حذف ما بها من محتوى', 'If you delete the category you will be deleted all content related to this category', 1, 0),
(132, 3, 'cat_var', 'Cat ID', 'Cat ID', 1, 0),
(133, 3, 'cat_name', 'اسم المجموعة', 'Category Name', 1, 0),
(134, 3, 'cat_count_var', 'متغير', 'Variable', 1, 0),
(135, 3, 'cat_count_var_text', 'المجموعة تحتوى على', 'Category Content', 1, 0),
(136, 3, 'cat_content_list', 'عرض المحتوى', 'List Content', 1, 0),
(137, 3, 'cat_content_edit', 'تعديل المحتوى', 'Edit Content', 1, 0),
(138, 3, 'cat_list_edit', 'تعديل', 'Edit', 1, 0),
(139, 3, 'cat_list_dell', 'حذف', 'Delete', 1, 0),
(140, 3, 'add_type', 'نوع الاضافة', 'Add Type', 1, 0),
(141, 3, 'add_type_text', 'نص', 'Text', 1, 0),
(142, 3, 'add_type_paragraph', 'فقرة', 'Paragraph', 1, 0),
(143, 3, 'var_name', 'المتغير', 'Variable', 1, 0),
(144, 3, 'var_des', 'الوصف', 'Description', 1, 0),
(145, 3, 'h1_edit', 'تعديل محتوى', 'Edit Content', 1, 0),
(146, 3, 'h1_del', 'حذف محتوى', 'Delete Content', 1, 0),
(147, 3, 'unit_dell_mass', 'هل انت متاكد من حذف هذا المحتوى', 'Are you sure you want to delete this content', 1, 0),
(148, 4, 'menu_ul', 'ضبط لغة الموقع', 'WebSite Language', 1, 0),
(149, 4, 'menu_cat_add', 'اضافة مجموعة', 'Add Category', 1, 0),
(150, 4, 'menu_cat_list', 'عرض المجموعات', 'List Category', 1, 0),
(151, 4, 'menu_unit_add', 'اضافة محتوى', 'Add Content', 1, 0),
(152, 4, 'menu_unit_list', 'عرض المحتوى', 'List Content', 1, 0),
(153, 4, 'menu_config', 'اعدادات القسم', 'Settings', 1, 0),
(154, 4, 'menu_update_lang', 'تحديث ملفات اللغة', 'Update Language File', 1, 0),
(155, 4, 'menu_search', 'ادوات البحث', 'Search Tools', 1, 0),
(156, 4, 'main_h1', 'ادارة ملفات لغة واجهة الموقع', 'Mange WebSite Language File', 1, 0),
(157, 4, 'h1_catedit', 'تعديل مجموعة', 'Edit Category', 1, 0),
(158, 4, 'h1_cat_dell', 'حذف مجموعة', 'Delete Category', 1, 0),
(159, 4, 'cat_dell_mass', 'فى حالة حذف المجموعة سيتم حذف ما بها من محتوى', 'If you delete the category you will be deleted all content related to this category', 1, 0),
(160, 4, 'cat_var', 'Cat ID', 'Cat ID', 1, 0),
(161, 4, 'cat_name', 'اسم المجموعة', 'Category Name', 1, 0),
(162, 4, 'cat_count_var', 'متغير', 'Variable', 1, 0),
(163, 4, 'cat_count_var_text', 'المجموعة تحتوى على', 'Category Content', 1, 0),
(164, 4, 'cat_content_list', 'عرض المحتوى', 'List Content', 1, 0),
(165, 4, 'cat_content_edit', 'تعديل المحتوى', 'Edit Content', 1, 0),
(166, 4, 'cat_list_edit', 'تعديل', 'Edit', 1, 0),
(167, 4, 'cat_list_dell', 'حذف', 'Delete', 1, 0),
(168, 4, 'add_type', 'نوع الاضافة', 'Add Type', 1, 0),
(169, 4, 'add_type_text', 'نص', 'Text', 1, 0),
(170, 4, 'add_type_paragraph', 'فقرة', 'Paragraph', 1, 0),
(171, 4, 'var_name', 'المتغير', 'Variable', 1, 0),
(172, 4, 'var_des', 'الوصف', 'Description', 1, 0),
(173, 4, 'h1_edit', 'تعديل محتوى', 'Edit Content', 1, 0),
(174, 4, 'h1_del', 'حذف محتوى', 'Delete Content', 1, 0),
(175, 4, 'unit_dell_mass', 'هل انت متاكد من حذف هذا المحتوى', 'Are you sure you want to delete this content', 1, 0),
(176, 5, 'lang_h1', 'اختيار اللغة', 'Choose Language', 1, 0),
(177, 5, 'ar_lang', 'اللغة العربية', 'Arabic Language', 1, 0),
(178, 5, 'en_lang', 'اللغة الانجليزية', 'English Language', 1, 0),
(179, 6, 'main_h1', 'ادارة الاعدادات', 'Manage Config', 1, 0),
(180, 6, 'web', 'اعدادات الموقع', 'Web Config', 1, 0),
(181, 6, 'currencysetting', 'اعدادات العملة', 'Web Site Currency Setting', 1, 0),
(182, 6, 'change_currency_state', 'السماح بتغير العملة', 'Change Currency State', 1, 0),
(183, 6, 'default_currency', 'العملة الافتراضية', 'Default Currency', 1, 0),
(184, 6, 'usd_value', 'قيمة الدولار', 'USD Value', 1, 0),
(185, 7, 'main_h1', 'ادارة المشاريع', 'Manage Project', 1, 0),
(186, 7, 'add_pro', 'اضافة مشروع', 'Add Project', 1, 0),
(187, 7, 'list_pro', 'عرض المشروعات', 'List Project', 1, 0),
(188, 7, 'edit_pro', 'تعديل المشروعات', 'Edit Project', 1, 0),
(189, 7, 'pro_name', 'اسم المشروع', 'Project Name', 1, 0),
(190, 7, 'pro_area_n', 'اسم الحى', 'Area', 1, 0),
(191, 7, 'floor_count', 'عدد الادوار', 'عدد الادوار', 1, 0),
(192, 7, 'unit_count', 'عدد الوحدات', 'Unit Count', 1, 0),
(193, 7, 'add_floor', 'اضافة دور', 'Add Floor', 1, 0),
(194, 7, 'floor_add_mass', 'انت الان تقوم باضافة دور جديد للمشروع', 'انت الان تقوم باضافة دور جديد للمشروع', 1, 0),
(195, 7, 'floor_last_mass', 'عدد الادوار المضافة للمشروع', 'عدد الادوار المضافة للمشروع', 1, 0),
(196, 7, 'floor_name', 'اسم الدور', 'Floor Name', 1, 0),
(197, 7, 'floor_code', 'كود الدور', 'Floor Code', 1, 0),
(198, 7, 'floor_u_count', 'عدد الوحدات بالدور', 'عدد الوحدات بالدور', 1, 0),
(199, 7, 'floor_code_err', 'عذرا كود الدور مستخدم من قبل برجاء المراجعة', 'عذرا كود الدور مستخدم من قبل برجاء المراجعة', 1, 0),
(200, 7, 'last_floor', 'اخر دور تم اضافته هو', 'اخر دور تم اضافته هو', 1, 0),
(201, 7, 'code', 'كود رقم', 'كود رقم', 1, 0),
(202, 7, 'floor_name_err_mass', 'اسم الدور مستخدم من قبل برجاء المراجعة', 'اسم الدور مستخدم من قبل برجاء المراجعة', 1, 0),
(203, 7, 'floor_list', 'عرض الادوار', 'List Floor', 1, 0),
(204, 7, 'list_unit', 'عرض الوحدات', 'عرض الوحدات', 1, 0),
(205, 7, 'active_unit', 'تنشيط الوحدات', 'تنشيط الوحدات', 1, 0),
(206, 7, 'unit_code', 'رقم الوحدة', 'رقم الوحدة', 1, 0),
(207, 7, 'tabel_list', 'جدول الوحدات', 'عرض جدول الوحدات', 1, 0),
(208, 7, 'active_mass_1', 'انت الان تقوم بتنشيط مجموعة من الوحدات للمشروع', 'انت الان تقوم بتنشيط مجموعة من الوحدات للمشروع', 1, 0),
(209, 7, 'active_mass_2', 'الدور الذى تقوم بتنشيطه هو', 'الدور الذى تقوم بتنشيطه هو', 1, 0),
(210, 7, 'active_mass_3', 'عدد الوحدادت التى تقوم بتنشيطها عدد', 'عدد الوحدادت التى تقوم بتنشيطها عدد', 1, 0),
(211, 7, 'errforactive', 'هذه الوحدات تم تنشيطها من قبل برجاء المراجعة', 'هذه الوحدات تم تنشيطها من قبل برجاء المراجعة', 1, 0),
(212, 7, 'unit_state_unavtive', 'الوحدة غير نشطة', 'Unit UnActive', 1, 0),
(213, 7, 'list_all_unit', 'عرض كل الوحدات', 'List All Unit', 1, 0),
(214, 7, 'unit_state_t', 'حالة الوحدة', 'Unit State', 1, 0),
(215, 7, 'edit_unit', 'تعديل وحدة', 'Edit Unit', 1, 0),
(216, 7, 'unit_area_sq', 'مساحة الوحدة', 'مساحة الوحدة', 1, 0),
(217, 7, 'unit_price', 'سعر الوحدة', 'Unit Price', 1, 0),
(218, 7, 'down_pay', 'دفعة الحجز', 'دفعة الحجز', 1, 0),
(219, 7, 'payment_method', 'طريقة الدفع', 'Payment Method', 1, 0),
(220, 7, 'additions', 'اضافات', 'Additions', 1, 0),
(221, 7, 'garden', 'الحديقة', 'garden', 1, 0),
(222, 7, 'unit_state_0', 'الوحدة معلقة حاليا', 'الوحدة معلقة حاليا', 1, 0),
(223, 7, 'unit_state_1', 'الوحدة متاحة للحجز', 'الوحدة متاحة للحجز', 1, 0),
(224, 7, 'unit_state_2', 'الوحدة محجوزة', 'الوحدة محجوزة', 1, 0),
(225, 7, 'unit_state_3', 'الوحدة مباعة', 'الوحدة مباعة', 1, 0),
(226, 7, 'price_add', 'اضافة جدول اسعار', 'اضافة جدول اسعار', 1, 0),
(227, 7, 'unit_notes', 'ملاحظات', 'ملاحظات', 1, 0),
(228, 7, 'listarea', 'عرض الاحياء', 'عرض الاحياء', 1, 0),
(229, 7, 'area_add', 'اضافة حى', 'اضافة حى', 1, 0),
(230, 7, 'area_edit', 'تعديل حى', 'تعديل حى', 1, 0),
(231, 7, 'area_dell', 'حذف حى', 'حذف حى', 1, 0),
(232, 7, 'area_name', 'اسم الحى', 'اسم الحى', 1, 0),
(233, 7, 'area_err', 'اسم الحى مستخدم من قبل برجاء المراجعة', 'اسم الحى مستخدم من قبل برجاء المراجعة', 1, 0),
(234, 7, 'area_dell_no', 'برجاء حذف المشاريع التابعة للحى قبل حذف الحي', 'برجاء حذف المشاريع التابعة للحى قبل حذف الحي', 1, 0),
(235, 7, 'area_dell_confirm', 'هل انت متاكد من حذف الحى', 'هل انت متاكد من حذف الحى', 1, 0),
(236, 7, 'project_count', 'عدد المشروعات', 'عدد المشروعات', 1, 0),
(237, 7, 'crunt_s', 'حالة المشروع', 'حالة المشروع', 1, 0),
(238, 7, 'crunt_0', 'مشروع سابق', 'مشروع سابق', 1, 0),
(239, 7, 'crunt_1', 'مشروع حالى', 'مشروع حالى', 1, 0),
(240, 7, 'project_err', 'اسم المشروع مستخدم من قبل برجاء المراجعة', 'اسم المشروع مستخدم من قبل برجاء المراجعة', 1, 0),
(241, 7, 'project_dell', 'حذف مشروع', 'حذف مشروع', 1, 0),
(242, 7, 'pro_dell_mas_confirm', 'هل انت متاكد من حذف المشروع', 'هل انت متاكد من حذف المشروع', 1, 0),
(243, 7, 'pro_dell_mas_err', 'لا يمكن حذف المشروع برجاء حذف الوحدات والادوار التابعة للمشروع لكى تتمكن من حذف المشروع', 'لا يمكن حذف المشروع برجاء حذف الوحدات والادوار التابعة للمشروع لكى تتمكن من حذف المشروع', 1, 0),
(244, 7, 'flo_del', 'حذف دور', 'حذف دور', 1, 0),
(245, 7, 'flo_del_mas_conf', 'هل انت متاكد من حذف', 'هل انت متاكد من حذف', 1, 0),
(246, 7, 'flo_del_mas_err', 'لا يمكن حذف الدور', 'لا يمكن حذف الدور', 1, 0),
(247, 7, 'pro_code', 'كود المشروع', 'كود المشروع', 1, 0),
(248, 7, 'pro_code_err', 'كود المشروع مستخدم من قبل برجاء المراجعة', 'كود المشروع مستخدم من قبل برجاء المراجعة', 1, 0),
(249, 7, 'filtr_but', 'فلترة', 'فلترة', 1, 0),
(250, 7, 'creunt_but', 'مشروعات الحالية', 'مشروعات الحالية', 1, 0),
(251, 7, 'last_but', 'مشروعات السابقة', 'مشروعات السابقة', 1, 0),
(252, 7, 'filtr_text', 'بحث باسم المشروع', 'بحث باسم المشروع', 1, 0),
(253, 7, 'pro_dell_w_1', 'وجب التنويه \r\nان المشروع مرتبط بمجموعة من المدخلات فى حالة حذف المشروع سيتم حذفها وهى', 'وجب التنويه \r\nان المشروع مرتبط بمجموعة من المدخلات فى حالة حذف المشروع سيتم حذفها وهى', 1, 0),
(254, 7, 'pro_dell_w_count', 'عدد', 'عدد', 1, 0),
(255, 7, 'pro_dell_w_floor', 'درو', 'درو', 1, 0),
(256, 7, 'pro_dell_w_unit', 'وحدة', 'وحدة', 1, 0),
(257, 7, 'pro_dell_w_price', 'جدول اسعار', 'جدول اسعار', 1, 0),
(258, 7, 'pro_dell_w_rev', 'استمارة حجز وتعاقد', 'استمارة حجز وتعاقد', 1, 0),
(259, 7, 'view_all_floor', 'عرض كل الادور', 'عرض كل الادور', 1, 0),
(260, 7, 'unit_list_proname_1', 'اسم المشروع :', 'اسم المشروع :', 1, 0),
(261, 7, 'unit_list_proname_2', 'اسم الحى :', 'اسم الحى :', 1, 0),
(262, 7, 'new_unit_code', 'كود الوحدة', 'كود الوحدة', 1, 0),
(263, 7, 'new_unit_num', 'رقم الوحدة', 'رقم الوحدة', 1, 0),
(264, 8, 'tabel_name', 'اسم جدول الاسعار', 'اسم جدول الاسعار', 1, 0),
(265, 8, 'main_t', 'الجدول الاساسى', 'الجدول الاساسى', 1, 0),
(266, 8, 'date', 'تاريخ السداد', 'تاريخ السداد', 1, 0),
(267, 8, 'list', 'عرض قوائم الاسعار', 'List Price Tabel', 1, 0),
(268, 8, 'price_edit', 'تعديل قوائم الاسعار', 'تعديل قوائم الاسعار', 1, 0),
(269, 8, 'total_price', 'اجمالى ثمن الوحدة', 'اجمالى ثمن الوحدة', 1, 0),
(270, 8, 'reser_price', 'دفعة الحجز', 'دفعة الحجز', 1, 0),
(271, 8, 'contract_price', 'دفعة التعاقد', 'دفعة التعاقد', 1, 0),
(272, 8, 'monthly_des', 'عدد الاقساط', 'عدد الاقساط', 1, 0),
(273, 8, 'monthly_price', 'قيمة القسط الشهرى', 'قيمة القسط الشهرى', 1, 0),
(274, 8, 'primary_receipt', 'تاريخ الإستلام الإبتدائي', 'Primary Receipt', 1, 0),
(275, 8, 'final_receipt', 'تاريخ الإستلام النهائي', 'Final Receipt', 1, 0),
(276, 8, 'last_update_d', 'اخر تحديث بتاريخ', 'اخر تحديث بتاريخ', 1, 0),
(277, 8, 'errsendpost', 'برجاء مراجعة ادخال البيانات الخاصة بـ', 'برجاء مراجعة ادخال البيانات الخاصة بـ', 1, 0),
(278, 8, 'g1', 'قيمة الجراج 1', 'قيمة الجراج 1', 1, 0),
(279, 8, 'additional_services', 'خدمات اضافية', 'خدمات اضافية', 1, 0),
(280, 8, 'g2', 'قيمة الجراج 2', 'قيمة الجراج 2', 1, 0),
(281, 8, 'g3', 'قيمة المخزن', 'قيمة المخزن', 1, 0),
(282, 8, 'g4', 'قيمة عداد الكهرباء', 'قيمة عداد الكهرباء', 1, 0),
(283, 8, 'g5', 'قيمة عداد المياه', 'قيمة عداد المياه', 1, 0),
(284, 8, 'g6', 'قيمة الوديعة', 'قيمة الوديعة', 1, 0),
(285, 8, 'payments_table', 'جدول الدفعات', 'Payments Table', 1, 0),
(286, 8, 'value', 'القيمة', 'القيمة', 1, 0),
(287, 8, 'des', 'الوصف', 'Des', 1, 0),
(288, 8, 'price_for_m', 'سعر المتر', 'سعر المتر', 1, 0),
(289, 8, 'print_but', 'طباعة', 'طباعة', 1, 0),
(290, 8, 'edit', 'تعديل', 'تعديل', 1, 0),
(291, 8, 'but_s1', 'اضافة استمارة حجز', 'اضافة استمارة حجز', 1, 0),
(292, 8, 'but_s2', 'عرض استمارة الحجز', 'عرض استمارة الحجز', 1, 0),
(293, 8, 'but_s3', 'عرض تفاصيل التعاقد', 'عرض تفاصيل التعاقد', 1, 0),
(294, 8, 'price_del', 'حذف جدول الاسعار', 'حذف جدول الاسعار', 1, 0),
(295, 8, 'price_del_err', 'لا يمكن حذف جدول الاسعار لانه مرتبط بوحدات برجاء المراجعه', 'لا يمكن حذف جدول الاسعار لانه مرتبط بوحدات برجاء المراجعه', 1, 0),
(296, 8, 'add_err', 'اسم جدول الاسعار مستخدم من قبل للمشروع برجاء المراجعة', 'اسم جدول الاسعار مستخدم من قبل للمشروع برجاء المراجعة', 1, 0),
(297, 9, 'test', 'بسم الله الرحمن الرحيم', 'ters', 1, 0),
(298, 9, 'u_code', 'كود الوحدة', 'كود الوحدة', 1, 0),
(299, 9, 'u_type', 'النموذج', 'النموذج', 1, 0),
(300, 9, 'u_floor', 'الدور', 'الدور', 1, 0),
(301, 9, 'u_area', 'المساحة', 'المساحة', 1, 0),
(302, 9, 'total_price', 'اجمالى ثمن الوحدة', 'اجمالى الوحدة', 1, 0),
(303, 9, 'meter_price', 'سعر المتر', 'سعر المتر', 1, 0),
(304, 9, 'hakz_price', 'دفعة الحجز', 'دفعة الحجز', 1, 0),
(305, 9, 'taakod_price', 'دفعة التعاقد', 'دفعة التعاقد', 1, 0),
(306, 9, 'mm', 'م2', 'م2', 1, 0),
(307, 9, 'eg_p', 'جنية', 'جنية', 1, 0),
(308, 9, 'payments', 'الدفعات', 'الدفعات', 1, 0),
(309, 9, 'value', 'القيمة', 'القيمة', 1, 0),
(310, 9, 'pay_des', 'بيان الدفعة', 'بيان الدفعة', 1, 0),
(311, 9, 'date_pay', 'تاريخ السداد', 'تاريخ السداد', 1, 0),
(312, 9, 'monthly_01', 'الاقساط الشهرية', 'الاقساط الشهرية', 1, 0),
(313, 9, 'monthly_02', 'القسط الشهرى', 'القسط الشهرى', 1, 0),
(314, 9, 'monthly_03', 'عدد الاقساط', 'عدد الاقساط', 1, 0),
(315, 9, 'date_1', 'تاريخ الإستلام الإبتدائي', 'تاريخ الإستلام الإبتدائي', 1, 0),
(316, 9, 'date_2', 'تاريخ الإستلام النهائي', 'تاريخ الإستلام النهائي', 1, 0),
(317, 9, 'last_update_d', 'اخر تحديث بتاريخ', 'اخر تحديث بتاريخ', 1, 0),
(318, 9, 'other', 'الخدمات', 'الخدمات', 1, 0),
(319, 9, 'store', 'قيمة المخزن', 'قيمة المخزن', 1, 0),
(320, 9, 'electricity', 'قيمة عداد الكهرباء', 'قيمة عداد الكهرباء', 1, 0),
(321, 9, 'water', 'قيمة عداد المياه', 'قيمة عداد المياه', 1, 0),
(322, 9, 'deposit', 'قيمة الوديعة', 'قيمة الوديعة', 1, 0),
(323, 9, 'garage_total', 'اجمالى الجراج', 'اجمالى الجراج', 1, 0),
(324, 9, 'g_area', 'مساحة الحديقة', 'مساحة الحديقة', 1, 0),
(325, 9, 'err_print', 'لا يمكن طباعة عرض الاسعار للوحدة برجاء مراجعة حالة الوحدة', 'لا يمكن طباعة عرض الاسعار للوحدة برجاء مراجعة حالة الوحدة', 1, 0),
(326, 9, 'prject_name', 'اسم المشروع', 'اسم المشروع', 1, 0),
(327, 10, 'h1', 'ادارة التعاقدات', 'ادارة التعاقدات', 1, 0),
(328, 10, 'reservation_add', 'اضافة استمارة حجز', 'اضافة استمارة حجز', 1, 0),
(329, 10, 'reservation_list', 'عرض استمارات الحجز المعلقة', 'عرض استمارات الحجز المعلقة', 1, 0),
(330, 10, 'reservation_dell', 'الغاء استمارة حجز', 'الغاء استمارة حجز', 1, 0),
(331, 10, 'reservation_err_mass', 'لا يمكن تحرير استمارة حجز للوحدة برجاء المراجعة', 'لا يمكن تحرير استمارة حجز للوحدة برجاء المراجعة', 1, 0),
(332, 10, 'rev_date', 'تاريخ الحجز', 'تاريخ الحجز', 1, 0),
(333, 10, 'cont_date', 'تاريخ التعاقد', 'تاريخ التعاقد', 1, 0),
(334, 10, 'emp_id', 'اسم الموظف', 'اسم الموظف', 1, 0),
(335, 10, 'cust_id', 'اسم العميل', 'اسم العميل', 1, 0),
(336, 10, 'ref_num', 'رقم الايصال', 'رقم الايصال', 1, 0),
(337, 10, 'notes', 'ملاحظات', 'ملاحظات', 1, 0),
(338, 10, 'rev_s_0', 'استمارة حجز معلقة', 'استمارة حجز معلقة', 1, 0),
(339, 10, 'rev_s_1', 'تم التعاقد', 'تم التعاقد', 1, 0),
(340, 10, 'rev_s_2', 'تم الغاء استمارة الحجز', 'تم الغاء استمارة الحجز', 1, 0),
(341, 10, 'rev_s_name', 'حالة الحجز', 'حالة الحجز', 1, 0),
(342, 10, 'view_form', 'عرض الاستمارة', 'عرض الاستمارة', 1, 0),
(343, 10, 'rev_but_0', 'الاستمارات المعلقة', 'الاستمارات المعلقة', 1, 0),
(344, 10, 'rev_but_1', 'تم التعاقد', 'تم التعاقد', 1, 0),
(345, 10, 'rev_but_2', 'تم الغاء الحجز', 'تم الغاء الحجز', 1, 0),
(346, 10, 'rev_view', 'عرض تفاصيل استمارة الحجز', 'عرض تفاصيل استمارة الحجز', 1, 0),
(347, 10, 'cust_info', 'بيانات العميل', 'بيانات العميل', 1, 0),
(348, 10, 'rev_update_h', 'تغير حالة الاستمارة', 'تغير حالة الاستمارة', 1, 0),
(349, 10, 'rev_update_1', 'الغاء استمارة الحجز', 'الغاء استمارة الحجز', 1, 0),
(350, 10, 'rev_update_2', 'تم التعاقد على الوحدة', 'تم التعاقد على الوحدة', 1, 0),
(351, 10, 'canel_err_mass', 'برجاء توضيح سبب الغاء الحجز فى خانة الملاحظات', 'برجاء توضيح سبب الغاء الحجز فى خانة الملاحظات', 1, 0),
(352, 10, 'canceled_but', 'عرض استمارات الحجز الملغاه', 'عرض استمارات الحجز الملغاه', 1, 0),
(353, 10, 'canceled_date', 'تاريخ الغاء الحجز', 'تاريخ الغاء الحجز', 1, 0),
(354, 10, 'canceled_num', 'رقم استمارة الغاء الحجز', 'رقم استمارة الغاء الحجز', 1, 0),
(355, 10, 'canceled_notes', 'سبب الغاء الحجز', 'سبب الغاء الحجز', 1, 0),
(356, 10, 'canceled_view_mass', 'هذه الاستمارة تم الغاءها', 'هذه الاستمارة تم الغاءها', 1, 0),
(357, 10, 'contract_0', 'عرض التعاقدات', 'عرض التعاقدات', 1, 0),
(358, 10, 'contract_1', 'عرض التعاقدات الملغاه', 'عرض التعاقدات الملغاه', 1, 0),
(359, 10, 'contract_view_mass', 'تم التعاقد على الوحدة', 'تم التعاقد على الوحدة', 1, 0),
(360, 10, 'contract_date', 'تاريخ التعاقد', 'تاريخ التعاقد', 1, 0),
(361, 10, 'contract_num', 'رقم التعاقد', 'رقم التعاقد', 1, 0),
(362, 10, 'contract_notes', 'ملاحظات', 'ملاحظات', 1, 0),
(363, 10, 'tabel_rese', 'تحرير استمارة حجز', 'تحرير استمارة حجز', 1, 0),
(364, 10, 'tabel_cont', 'تحرير استمارة تعاقد', 'تحرير استمارة تعاقد', 1, 0),
(365, 10, 'cont_but', 'تعاقد', 'تعاقد', 1, 0),
(366, 10, 'rev_but', 'حجز', 'حجز', 1, 0),
(367, 10, 'list_but', 'تحرير استمارة', 'تحرير استمارة', 1, 0),
(368, 10, 'rev_mass', 'انت الان تقوم بتحرير استمارة حجز لوحدة للمشروع', 'انت الان تقوم بتحرير استمارة حجز لوحدة للمشروع', 1, 0),
(369, 10, 'con_mass', 'انت الان تقوم بتحرير استمارة تعاقد لوحدة بالمشروع', 'انت الان تقوم بتحرير استمارة تعاقد لوحدة بالمشروع', 1, 0),
(370, 10, 't_rev', 'حجز', 'حجز', 1, 0),
(371, 10, 't_rev_c', 'حجز ملغاه', 'حجز ملغاه', 1, 0),
(372, 10, 't_con', 'تعاقد', 'تعاقد', 1, 0),
(373, 10, 't_con_c', 'تعاقد ملغاه', 'تعاقد ملغاه', 1, 0),
(374, 10, 'form', 'استمارة', 'استمارة', 1, 0),
(375, 10, 'form_no', 'لا يوجد', 'لا يوجد', 1, 0),
(376, 10, 'ref_num_err', 'رقم الايصال مستخدم من قبل برجاء المراجعة', 'رقم الايصال مستخدم من قبل برجاء المراجعة', 1, 0),
(377, 10, 'con_dell_but', 'الغاء التعاقد', 'الغاء التعاقد', 1, 0),
(378, 10, 'cont_mass_conifrm', 'وجب التنويه\r\nانت الان تقوم بالغاء التعاقد على وحدة تم التعاقد عليها', 'وجب التنويه\r\nانت الان تقوم بالغاء التعاقد على وحدة تم التعاقد عليها', 1, 0),
(379, 10, 'dell_date', 'تاريخ الغاء التعاقد', 'تاريخ الغاء التعاقد', 1, 0),
(380, 10, 'dell_notes', 'سبب الغاء التعاقد', 'سبب الغاء التعاقد', 1, 0),
(381, 10, 'menu_rev', 'استمارات الحجز', 'استمارات الحجز', 1, 0),
(382, 10, 'menu_rev_c', 'استمارة حجز ملغاه', 'استمارة حجز ملغاه', 1, 0),
(383, 10, 'menu_con', 'التعاقدات', 'التعاقدات', 1, 0),
(384, 10, 'menu_con_c', 'التعاقدات الملغاه', 'التعاقدات الملغاه', 1, 0),
(385, 10, 'mass_rev_des', 'تفاصيل استمارة الحجز', 'تفاصيل استمارة الحجز', 1, 0),
(386, 10, 'mass_rev_unit_des', 'بيانات الوحدة', 'بيانات الوحدة', 1, 0),
(387, 10, 'mass_con_des', 'تفاصيل التعاقد', 'تفاصيل التعاقد', 1, 0),
(388, 10, 'mass_cancel_des', 'تفاصيل استمار الغاء التعاقد', 'تفاصيل استمار الغاء التعاقد', 1, 0),
(389, 10, 'view_unit_tabel', 'عرض جدول الوحدادات', 'عرض جدول الوحدادات', 1, 0),
(390, 10, 'view_unit_tabel_mass', 'عرض جدول الوحدادات للمشروع', 'عرض جدول الوحدادات للمشروع', 1, 0),
(391, 11, 'h1', 'ادارة العملاء', 'Customer Management', 1, 0),
(392, 11, 'add', 'اضافة عميل', 'Add Customer ', 1, 0),
(393, 11, 'list', 'عرض العملاء', 'List Customer ', 1, 0),
(394, 11, 'edit', 'تعديل عميل', 'Edit Customer ', 1, 0),
(395, 11, 'dell', 'حذف عميل', 'Delete Customer ', 1, 0),
(396, 11, 'name', 'اسم العميل', 'Customer Name', 1, 0),
(397, 11, 'mobile', 'رقم الموبايل', 'Mobile Number ', 1, 0),
(398, 11, 'phone', 'رقم الهاتف', 'Phone Number ', 1, 0),
(399, 11, 'email', 'البريد الالكترونى', 'Email', 1, 0),
(400, 11, 'city', 'المحافظة', 'City', 1, 0),
(401, 11, 'country', 'الدولة', 'Country ', 1, 0),
(402, 11, 'type', 'حالة العميل', 'Customer State', 1, 0),
(403, 11, 'notes', 'ملاحظات', 'Notes', 1, 0),
(404, 11, 'birth_date', 'تاريخ الميلاد', 'Birth Date', 1, 0),
(405, 11, 'national_id', 'رقم الهوية', 'National ID', 1, 0),
(406, 11, 'jop', 'المهنة', 'Jop', 1, 0),
(407, 11, 'cust_2_err', 'اسم العميل 2 تم اضافته برجاء المراجعة', 'Customer name 2 has been added Please review', 1, 0),
(408, 11, 'cust_2_err_2', 'لابد من اضافة العميل رقم 2 قبل اضافة العميل رقم 3', 'Client 2 must be added prior to Client 3', 1, 0),
(409, 11, 'cust_3_err', 'اسم العميل رقم 3 مستخدم من قبل برجاء المراجعة', 'Customer name 3 is already in use', 1, 0),
(410, 11, 'kind', 'النوع', 'Kind', 1, 0),
(411, 11, 'social_type', 'الحالة الاجتماعية', 'Social Status', 1, 0),
(412, 11, 'live_type', 'الاقامة', 'Residence', 1, 0),
(413, 11, 'lead_type', 'طريقة التواصل', 'Leads Type', 1, 0),
(414, 11, 'lead_sours', 'مصدر التواصل', 'Leads Sours', 1, 0),
(415, 11, 'view_cust_err', 'عرض تفاصيل العميل', 'عرض تفاصيل العميل', 1, 0),
(416, 11, 'edit_cust_err', 'تعديل بيانات العميل', 'Edit Customer', 1, 0),
(417, 11, 'state_s', 'حالة العميل', 'Customer State', 1, 0),
(418, 11, 'add_more_contact', 'اضافة وسائل اتصل اخرى', 'Add other means of communication', 1, 0),
(419, 11, 'sub_re', 'الصلة', 'Relation', 1, 0),
(420, 11, 'sub_name', 'الاسم', 'Name', 1, 0),
(421, 11, 'sub_mobile', 'موبايل', 'Mobile', 1, 0),
(422, 11, 'sub_email', 'البريد الالكترونى', 'Email', 1, 0),
(423, 11, 'profile', 'الملف الشخصى', 'Profile', 1, 0),
(424, 11, 'profile_info', 'بيانات العميل', 'Customer Data', 1, 0),
(425, 11, 'more_contact', 'وسائل اتصال اخرى', 'Other means of communication', 1, 0),
(426, 11, 'profileedit', 'الاضافة من التعديل', 'Added amendment', 1, 0),
(427, 11, 'date_add', 'تاريخ الاضافة', 'Date added', 1, 0),
(428, 11, 'add_user', 'اضيف بواسطة', 'Added by', 1, 0),
(429, 11, 'nationality', 'الجنسية', 'Nationality', 1, 0),
(430, 11, 'country_live', 'دولة الاقامة', 'Country of residence', 1, 0),
(431, 11, 'nationality_err', 'برجاء تحديد الجنسية بصورة صحيحة', 'Please specify nationality correctly', 1, 0),
(432, 11, 'country_live_err', 'برجاء تحديد دولة الاقامة بصورة صحيحة', 'Please specify the country of residence correctly', 1, 0),
(433, 11, 'c_type_sub', 'التصنيف', 'Category', 1, 0),
(434, 11, 'c_type', 'نوع العميل', 'Customer Type', 1, 0),
(435, 11, 'contract_tab', 'التعاقدات', 'Contracting', 1, 0),
(436, 11, 'edit_err_5', 'حالة العميل قيد المراجعة برجاء مراجعة البيانات وتفعيله لتتمكن من تعديل البيانات', 'Customer Status Under Review Please review and activate the data to be able to modify the data', 1, 0),
(437, 11, 'duf_mass', 'تمت الاضافة بواسطة', 'Added by', 1, 0),
(438, 11, 'add_contract', 'اضافة عميل تعاقد', 'Add Customer Contract', 1, 0),
(439, 11, 'filter', 'فلترة العملاء', 'Filter Customer', 1, 0),
(440, 11, 'customer_search', 'بحث عن عميل', 'Customer Search', 1, 0),
(441, 11, 'search_by_name', 'البحث بالاسم', 'Search by Name', 1, 0),
(442, 11, 'search_by_mobile', 'بحث برقم الهاتف', 'Search by Mobile', 1, 0),
(443, 11, 'search_by_email', 'بالبحث بالبريد الاكترونى', 'Search by Email', 1, 0),
(444, 11, 'search_by_id', 'البحث برقم الهوية', 'Search by ID', 1, 0),
(445, 11, 'search_by', 'البحث بواسطة', 'Search By', 1, 0),
(446, 11, 'search_name', 'كلمات البحث', 'Search Keyword', 1, 0),
(447, 11, 'search_but', 'بحث', 'Search', 1, 0),
(448, 12, 'cat_add', 'اضافة مجموعة', 'Add Group', 1, 0),
(449, 12, 'cat_list', 'عرض المجموعات', 'List Group', 1, 0),
(450, 12, 'add_user', 'اضافة مستخدم', 'Add User ', 1, 0),
(451, 12, 'list_user', 'عرض المستخدمين', 'List User ', 1, 0),
(452, 12, 'h1', 'ادارة الاعضاء والصلاحيات', 'Management Users and Permissions', 1, 0),
(453, 12, 'cat_name', 'اسم المجموعة', 'Group Name', 1, 0),
(454, 12, 'count', 'عدد الاعضاء', 'Count Of User', 1, 0),
(455, 12, 'cat_edit', 'تعديل المجموعة', 'Edit Group', 1, 0),
(456, 12, 'per', 'تعديل الصلاحيات', 'Edit Permissions', 1, 0),
(457, 12, 'state', 'حالة المجموعة', 'Group State ', 1, 0),
(458, 12, 'dell_cat', 'حذف المجموعة', 'Delete Group', 1, 0),
(459, 12, 'active_cat', 'تنشيط المجموعة', 'Activate the group', 1, 0),
(460, 12, 'cat_add_err', 'اسم المجموعة مستخدم من قبل برجاء المراجعة', 'The group name is used by please review', 1, 0),
(461, 12, 'cat_state', 'حالة المجموعة', 'Group State ', 1, 0),
(462, 12, 'sec_name', 'القسم', 'Section', 1, 0),
(463, 12, 'view', 'حالة العرض', 'View Status', 1, 0),
(464, 12, 'add', 'حالة الاضافة', 'Added Status', 1, 0),
(465, 12, 'edit', 'حالة التعديل', 'Status of modification', 1, 0),
(466, 12, 'dell', 'حالة الحذف', 'Deletion status', 1, 0),
(467, 12, 'warning_mass', 'انت الان تقوم بتعديل الصلاحيات للمجموعة', 'You are now editing the permissions for the group', 1, 0),
(468, 12, 'mod_project', 'ادارة المشاريع', 'Project  Management', 1, 0),
(469, 12, 'mod_contract', 'ادارة التعاقدات', 'Manage Contracts', 1, 0),
(470, 12, 'mod_users', 'ادارة العملاء', 'Customer Management', 1, 0),
(471, 12, 'webmanage', 'المجموعه لها صلاحيات مدير الموقع', 'المجموعه لها صلاحيات مدير الموقع', 1, 0),
(472, 12, 'dell_cat_err', 'لا يمكن حذف المجموعة الا بعد حذف الاعضاء التابعين لها', 'لا يمكن حذف المجموعة الا بعد حذف الاعضاء التابعين لها', 1, 0),
(473, 12, 'dell_cat_confirm', 'هل انت متاكد من حذف مجموعة الاعضاء', 'Are you sure you want to delete this group?', 1, 0),
(474, 12, 'user_name', 'User Name', 'User Name', 1, 0),
(475, 12, 'name', 'اسم المستخدم', 'User Name', 1, 0),
(476, 12, 'email', 'البريد الالكترونى', 'Email', 1, 0),
(477, 12, 'mobile', 'رقم الهاتف', 'Mobile', 1, 0),
(478, 12, 'last_login', 'اخر تسجيل دخول', 'Last Login ', 1, 0),
(479, 12, 'user_edit', 'تعديل مستخدم', 'Edit User ', 1, 0),
(480, 12, 'new_pass', 'كلمة المرور الجديدة', 'Password', 1, 0),
(481, 12, 'user_state', 'حالة المستخدم', 'User State', 1, 0),
(482, 12, 'username_err', 'اسم المستخدم مستخدم من قبل برجاء المراجعة', 'Username is already used by please review', 1, 0),
(483, 12, 'name_err', 'الاسم مستخدم من قبل برجاء المراجعة', 'Name is already used by please review', 1, 0),
(484, 12, 'email_err', 'البريد الالكترونى مستخدم من قبل برجاء المراجعة', 'Email is already used by please review', 1, 0),
(485, 12, 'mobile_err', 'رقم الهاتف مستخدم من قبل برجاء المراجعة', 'Phone number used by please review', 1, 0),
(486, 12, 'user_dell', 'حذف مستخدم', 'Delete User ', 1, 0),
(487, 12, 'mod_salesdep', 'متابعة العملاء', 'Sales', 1, 0),
(488, 12, 'mod_custserv', 'خدمة العملاء', 'Customers Service', 1, 0),
(489, 12, 'mod_managedate', 'ادارة البيانات', 'Manage Date', 1, 0),
(490, 12, 'mod_leads', 'ادارة العملاء الجدد', 'Manage Leads', 1, 0),
(491, 12, 'mod_hotline', 'اضافة العملاء الجدد', 'HotLine', 1, 0),
(492, 12, 'mod_report', 'التقارير', 'Report', 1, 0),
(493, 12, 'user_follow', 'متابعة المستخدمين', 'User Follow', 1, 0),
(494, 13, 'main_h1', 'ادارة البيانات', 'Manage Data', 1, 0),
(495, 13, 'data_name', 'الاسم', 'Name', 1, 0),
(496, 13, 'callt_list', 'عرض وسائل الاتصال', 'View Lead Type', 1, 0),
(497, 13, 'callt_add', 'اضافة وسيلة اتصال', 'Add  Lead Type', 1, 0),
(498, 13, 'custsub_list', 'عرض الحالات الفرعية للعملاء', 'List Sub Customer Status', 1, 0),
(499, 13, 'custsub_but', 'حالات العملاء', 'Customer Status', 1, 0),
(500, 13, 'custsub_add', 'اضافة حالة فرعية', 'Add Sub Status', 1, 0),
(501, 13, 'custsub_edit', 'تعديل حالة فرعية', 'Edit Sub Status', 1, 0),
(502, 13, 'custsub_dell', 'حذف حالة فرعية', 'Delete Sub Status', 1, 0),
(503, 13, 'custsub_name', 'اسم الحالة الفرعية', 'Sub Status Name', 1, 0),
(504, 13, 'custsub_catname', 'حالة العميل الاساسية', 'Basic Customer Status', 1, 0),
(505, 13, 'cash_list', 'عرض طرق السداد', 'List Payment Methods ', 1, 0),
(506, 13, 'cash_add', 'اضافة طريقة سداد', 'Add Payment Methods ', 1, 0),
(507, 13, 'cash_edit', 'تعديل طريقة سداد', 'Edit Payment Methods ', 1, 0),
(508, 13, 'cash_dell', 'حذف طريقة سداد', 'Delete Payment Methods ', 1, 0),
(509, 13, 'cash_but', 'طرق السداد', 'Payment Methods ', 1, 0),
(510, 13, 'unit_but', 'النماذج', 'Unit Type', 1, 0),
(511, 13, 'unit_list', 'عرض النماذج', 'List Unit Type', 1, 0),
(512, 13, 'unit_add', 'اضافة نموذج', 'Add Unit Type', 1, 0),
(513, 13, 'unit_edit', 'تعديل نموذج', 'Edit Unit Type', 1, 0),
(514, 13, 'unit_dell', 'حذف نموذج', 'Delete Unit Type', 1, 0),
(515, 13, 'date_but', 'مواعيد الاستلام', 'Date of Receipt', 1, 0),
(516, 13, 'date_list', 'عرض مواعيد الاستلام', 'List', 1, 0),
(517, 13, 'date_add', 'اضافة ميعاد استلام', 'Add', 1, 0),
(518, 13, 'date_edit', 'تعديل ميعاد الاستلام', 'Edit', 1, 0),
(519, 13, 'date_dell', 'حذف ميعاد استلام', 'Delete ', 1, 0),
(520, 13, 'bestcall_list', 'عرض افضل الطرق للتواصل', 'List Best Communiction', 1, 0),
(521, 13, 'bestcall_add', 'اضافة طريقة تواصل', 'Add Best Communiction', 1, 0),
(522, 13, 'bestcall_edit', 'تعديل طريقة تواصل', 'Edit Best Communiction', 1, 0),
(523, 13, 'bestcall_dell', 'حذف طريقة تواصل', 'Delete Best Communiction', 1, 0),
(524, 13, 'bestcall_but', 'افضل طريقة للتواصل', 'Best Communiction', 1, 0),
(525, 13, 'time_list', 'عرض انسب وقت للاتصال', 'List Best Time To Call', 1, 0),
(526, 13, 'time_add', 'اضافة انسب وقت للاتصال', 'Add Best Time To Call', 1, 0),
(527, 13, 'time_edit', 'تعديل انسب وقت للاتصال', 'Edit Best Time To Call', 1, 0),
(528, 13, 'time_dell', 'حذف انسب وقت للاتصال', 'Delete Best Time To Call', 1, 0),
(529, 13, 'time_but', 'وقت الاتصال', 'Time To Call', 1, 0),
(530, 13, 'area_list', 'عرض المساحات', 'List Spaces', 1, 0),
(531, 13, 'area_add', 'اضافة مساحة', 'Add Spaces', 1, 0),
(532, 13, 'area_edit', 'تعديل المساحات', 'Edit Spaces', 1, 0),
(533, 13, 'area_dell', 'حذف مساحة', 'Delete Spaces', 1, 0),
(534, 13, 'area_but', 'المساحات', 'Spaces', 1, 0),
(535, 13, 'social_list', 'عرض الحالة الاجتماعية', 'List Social Status', 1, 0),
(536, 13, 'social_add', 'اضافة حالة اجتماعية', 'Add Social Status', 1, 0),
(537, 13, 'social_edit', 'تعديل حالة اجتماعية', 'Edit Social Status', 1, 0),
(538, 13, 'social_dell', 'حذف حالة اجتماعية', 'Delete Social Status', 1, 0),
(539, 13, 'social_but', 'الحالة الاجتماعية', 'Social Status', 1, 0),
(540, 13, 'lead_sours_list', 'عرض مصادر التواصل', 'List Lead Sours', 1, 0),
(541, 13, 'lead_sours_add', 'اضافة مصدر تواصل', 'Add Lead Sours', 1, 0),
(542, 13, 'lead_sours_edit', 'تعديل مصدر التواصل', 'Edit Lead Sours', 1, 0),
(543, 13, 'lead_sours_dell', 'حذف مصدر التواصل', 'Delete Lead Sours', 1, 0),
(544, 13, 'lead_sours_but', 'مصدر التواصل', 'Lead Sours', 1, 0),
(545, 13, 'lead_type_list', 'عرض طريقة التواصل', 'List Lead Type', 1, 0),
(546, 13, 'lead_type_add', 'اضافة طريقة تواصل', 'Add Lead Type', 1, 0),
(547, 13, 'lead_type_edit', 'تعديل طريقة تواصل', 'Edit Lead Type', 1, 0),
(548, 13, 'lead_type_dell', 'حذف طريقة تواصل', 'Delete Lead Type', 1, 0),
(549, 13, 'lead_type_but', 'طريقة التواصل', 'Lead Type', 1, 0),
(550, 13, 'jop_list', 'عرض الوظائف', 'View Jop', 1, 0),
(551, 13, 'jop_add', 'اضافة وظيفة', 'Add Jop', 1, 0),
(552, 13, 'jop_edit', 'تعديل وظيفة', 'Edit Jop', 1, 0),
(553, 13, 'jop_dell', 'حذف وظيفة', 'Delete Jop', 1, 0),
(554, 13, 'jop_but', 'الوظائف', 'Jop', 1, 0),
(555, 13, 'leadcat_but', 'الحملات الاعلانية', 'Campaign Name', 1, 0),
(556, 13, 'leadcat_list', 'عرض الحملات الاعلانية', 'View ad campaigns', 1, 0),
(557, 13, 'leadcat_edit', 'تعديل الحملات الاعلانية', 'Edit Campaign', 1, 0),
(558, 13, 'leadcat_add', 'اضافة حملات اعلانية', 'Add Campaign', 1, 0),
(559, 13, 'leadcat_dell', 'حذف الحملات الاعلانية', 'Delete Campaign', 1, 0),
(560, 14, 'main_h1', 'ادارة الاتصالات', 'Add New Leads', 1, 0),
(561, 14, 'add', 'اضافة اتصال', 'Add New Customer', 1, 0),
(562, 14, 'list', 'عرض الاتصالات', 'List Customer', 1, 0),
(563, 14, 'fast_add', 'اضافة سريعة', 'Fast Add Customer', 1, 0),
(564, 14, 'delete_customer', 'حذف عميل', 'Delete Customer', 1, 0),
(565, 14, 'ad_campaign', 'الحملة الاعلانية', 'Campaign Name', 1, 0),
(566, 15, 'main_h1', 'توزيع الاتصالات', 'Manage Leads', 1, 0),
(567, 15, 'list', 'توزيع الاتصالات الجديدة', 'Distribution of new customers', 1, 0),
(568, 15, 'type', 'Leads Type', 'Leads Type', 1, 0),
(569, 15, 'date_add', 'تاريخ الاضافة', 'Date Add', 1, 0),
(570, 15, 'c_name', 'اسم العميل', 'Customer Name', 1, 0),
(571, 15, 'mobile', 'رقم الموبايل', 'Mobile', 1, 0),
(572, 15, 'email', 'البريد الالكترونى', 'Email ', 1, 0),
(573, 15, 'lead_type', 'الوسيلة الاعلانية', 'Lead Typt', 1, 0),
(574, 15, 'c_dell', 'حذف عميل', 'Delete Customer ', 1, 0),
(575, 15, 'c_data', 'بيانات العميل', 'Customer Info', 1, 0),
(576, 15, 'c_state', 'حالة العميل', 'Customer State', 1, 0),
(577, 15, 'new_cust', 'عملاء جدد', 'New Customer ', 1, 0),
(578, 15, 'old_cust', 'عملاء حاليين', 'Current Customer ', 1, 0),
(579, 15, 'sales_cust', 'تحويل من المبيعات', 'تحويل من المبيعات', 1, 0),
(580, 15, 'dell', 'حذف بيانات', 'Delete Date', 1, 0),
(581, 15, 'notes', 'ملاحظات', 'Notes', 1, 0),
(582, 15, 'sales_cat', 'قسم المبيعات', 'Sales Department', 1, 0),
(583, 15, 'add_to_sales', 'اضافة الى موظف', 'Add To Employee', 1, 0),
(584, 15, 'emp', 'موظف', 'Employee', 1, 0),
(585, 15, 'sell_err_mass', 'لم يتم تحديد بيانات للتوزيع برجاء المراجعة', 'No data specified for distribution Please review', 1, 0),
(586, 15, 'report_date', 'تقرير التوزيع', 'Distribution Report', 1, 0),
(587, 15, 'from_date', 'من تاريخ', 'From Date', 1, 0),
(588, 15, 'to_date', 'الى تاريخ', 'To Date', 1, 0),
(589, 15, 'date_err', 'برجاء تحديد الفترة بصورة صحيحة', 'Please specify the period correctly', 1, 0),
(590, 15, 'report_emp_name', 'اسم الموظف', 'Employee Name', 1, 0),
(591, 15, 'report_st_0', 'بيانات غير مراجعه', 'بيانات غير مراجعه', 1, 0),
(592, 15, 'report_st_1', 'تذكرة مفتوحة', 'تذكرة مفتوحة', 1, 0),
(593, 15, 'report_st_2', 'تذكرة مغلقة', 'تذكرة مغلقة', 1, 0),
(594, 15, 'report_st_3', 'حجز', 'حجز', 1, 0),
(595, 15, 'report_st_4', 'تعاقد', 'تعاقد', 1, 0),
(596, 15, 'add_user', 'اضيفة بواسطة', 'Add By ', 1, 0),
(597, 15, 'filter_user', 'فلترة موظف', 'Filter Employee ', 1, 0),
(598, 16, 'main_h1', 'متابعة العملاء', 'Customer Follow', 1, 0),
(599, 16, 'listnew', 'بيانات قيد المراجعة', 'Data under review', 1, 0),
(600, 16, 'date_add', 'تاريخ الاضافة', 'Date Add ', 1, 0),
(601, 16, 'user_name', 'اسم الموظف', 'Employee Name', 1, 0),
(602, 16, 'cust_name', 'اسم العميل', 'Customer Name', 1, 0),
(603, 16, 'admin_name', 'اضيف بواسطة', 'Added By', 1, 0),
(604, 16, 'lead_type', 'طريقة التواصل', 'Lead Type', 1, 0),
(605, 16, 'mobile', 'رقم الهاتف', 'Mobile', 1, 0),
(606, 16, 'view_but', 'عرض التفاصيل', 'View Details', 1, 0),
(607, 16, 'fiter_but', 'بحث', 'Search', 1, 0),
(608, 16, 'view_all_user', 'عرض كل الموظفين', 'View All Staff', 1, 0),
(609, 16, 'fast_view', 'مراجعة سريعة', 'Quick review', 1, 0),
(610, 16, 'cust_info', 'بيانات العميل', 'Customer Data', 1, 0),
(611, 16, 'call_info', 'تفاصيل الاتصال', 'Contact Details', 1, 0),
(612, 16, 'f_follow_type', 'نوع المتابعة', 'Type of follow-up', 1, 0),
(613, 16, 'f_follow_state', 'حالة المتابعة', 'Follow-up status', 1, 0),
(614, 16, 'f_follow_date', 'تاريخ المتابعة القادم', 'Next date of follow-up', 1, 0),
(615, 16, 'f_follow_des', 'نص المحادثة', 'Conversation', 1, 0),
(616, 16, 'follow_date_err', 'برجاء التاكد من اختيار تاريخ المتابعة بصورة صحيحة', 'Please make sure to select the date of follow-up correctly', 1, 0),
(617, 16, 'follow_state_err', 'برجاء التأكد من حالة المتابعة', 'Please check the status of follow-up', 1, 0),
(618, 16, 'but_new_cust', 'عميل جديد', 'New Customer', 1, 0),
(619, 16, 'but_follow_today', 'متابعات اليوم', 'Follow-up today', 1, 0),
(620, 16, 'td_follow_date', 'تاريخ المتابعة', 'Follow Date', 1, 0),
(621, 16, 'td_last_notes', 'اخر رد تم اضافته', 'Last Notes', 1, 0),
(622, 16, 'td_c_type2', 'تقيم العميل', 'Evaluate ', 1, 0),
(623, 16, 'but_follow_back', 'متابعات لم تتم', 'No follow-ups', 1, 0),
(624, 16, 'but_follow_next', 'متابعة لاحقا', 'Follow Next', 1, 0),
(625, 16, 'but_unfollow', 'تذاكر معلقة', 'Waiting Ticket ', 1, 0),
(626, 16, 'viewticket_h1', 'عرض تفاصيل متابعة عميل للتذكرة رقم', 'View customer follow-up details for ticket number', 1, 0),
(627, 16, 'list_all_cust', 'عرض العملاء', 'List Customer', 1, 0),
(628, 16, 'email', 'البريد الالكترونى', 'Email', 1, 0),
(629, 16, 'cust_s', 'حالة العميل', 'Customer State', 1, 0),
(630, 16, 'mass_follow_count_1', 'عدد المتابعات اليوم', 'The number of followers today', 1, 0),
(631, 16, 'mass_follow_count_2', 'عدد المتابعات لليوم', 'The number of follow-ups for the day', 1, 0),
(632, 16, 'date_err_2', 'برجاء تحديد التاريخ بصورة صحيحة', 'Please specify the date correctly', 1, 0),
(633, 16, 'ask_help', 'طلب مساعدة', 'Asked Assistant', 1, 0),
(634, 16, 'reason_help', 'سبب طلب المساعدة', 'Reason for requesting help', 1, 0),
(635, 16, 'reason_for_close', 'سبب الاغلاق', 'Reason for Close', 1, 0),
(636, 16, 'change_employee', 'تغير الموظف', 'Change Employee', 1, 0),
(637, 16, 'change_mass1', 'هل انت متاكد من تغير الموظف', 'Are you sure changed employee', 1, 0),
(638, 16, 'change_mass2', 'للعميل', 'For Customer', 1, 0),
(639, 16, 'change_err', 'برجاء تحديد اسم الموظف بصورة صحيحة', 'Please specify the employee  name correctly', 1, 0),
(640, 17, 'h1', 'تفاصيل التذكرة', 'Ticket Details', 1, 0),
(641, 17, 'cust_name', 'اسم العميل', 'Customer Name', 1, 0),
(642, 17, 'cust_mobile', 'رقم الهاتف', 'Mobile', 1, 0),
(643, 17, 'cust_type', 'تقيم العميل', 'Evaluate', 1, 0),
(644, 17, 'emp_name', 'الموظف المختص', 'Competent Employee', 1, 0),
(645, 17, 'cash_id', 'طريقة السداد', 'Method of Payment', 1, 0),
(646, 17, 'date_id', 'ميعاد الاستلام', 'Date of receipt', 1, 0),
(647, 17, 'unit_id', 'النموذج', 'Unit Type', 1, 0),
(648, 17, 'area_id', 'المساحة', 'Area', 1, 0),
(649, 17, 'time_id', 'أنسب وقت للإتصال', 'Best Time to Contact', 1, 0),
(650, 17, 'bestcall_id', 'طريقة التواصل المفضلة', 'Preferred Communication', 1, 0),
(651, 17, 'pro_area', 'الاحياء', 'Loactions', 1, 0),
(652, 17, 'update', 'اضافة متابعة', 'Updating Ticket', 1, 0),
(653, 17, 'add_visit', 'اضافة زيارة', 'Add a Visit', 1, 0),
(654, 17, 'add_rev', 'اضافة حجز', 'Add Reservation', 1, 0),
(655, 17, 'close_tek', 'اغلاق التذكرة', 'Close Ticket', 1, 0),
(656, 17, 'cust_update_info', 'تحديث بيانات العميل', 'Update Client data', 1, 0),
(657, 17, 'visit_date', 'تاريخ الزيارة', 'Visit Date', 1, 0),
(658, 17, 'visit_des', 'تفاصيل الزيارة', 'Visit Details', 1, 0),
(659, 17, 'cust_info_td_h', 'تفاصيل متابعة العميل', 'Customer Follow-up Details', 1, 0),
(660, 17, 't_emp_name', 'اسم الموظف', 'Employee Name', 1, 0),
(661, 17, 't_add_date', 'تاريخ الاضافة', 'Add Date', 1, 0),
(662, 17, 't_follow_type', 'وسيلة المتابعة', 'Follow-up Type', 1, 0),
(663, 17, 't_follow_state', 'الحالة', 'Status', 1, 0),
(664, 17, 't_follow_date', 'تاريخ المتابعة', 'Follow-up Date', 1, 0),
(665, 17, 't_des', 'نص المحادثة', 'Conversation', 1, 0),
(666, 17, 'ticket_mass_update_1', 'انت الان تقوم بتحديث حالة التذكرة رقم', 'You are now updating your ticket status Number', 1, 0),
(667, 17, 'ticket_mass_update_2', 'للعميل', 'For Customer ', 1, 0),
(668, 17, 'f_rev_date', 'تاريخ الحجز', 'Reservations Date', 1, 0),
(669, 17, 'f_rev_date_2', 'تاريخ التعاقد', 'Date of Contract', 1, 0),
(670, 17, 'f_rev_des', 'تفاصيل الحجز', 'Reservations Details', 1, 0),
(671, 17, 'cancel_but', 'الغاء الحجز', 'Cancellation', 1, 0),
(672, 17, 'cancel_date', 'تاريخ الغاء الحجز', 'Cancellation Date', 1, 0),
(673, 17, 'cancel_des', 'سبب الغاء الحجز', 'Reason for Cancellation ', 1, 0),
(674, 17, 'lead_cat', 'الحملة الاعلانية', 'Campaign Name', 1, 0),
(675, 17, 't_info', 'تفاصيل التذكرة', 'Ticket Details', 1, 0),
(676, 17, 'follow_list_1', 'توجد متابعة', 'There is follow-up', 1, 0),
(677, 17, 'follow_list_2', 'لا توجد متابعه', 'No follow-up', 1, 0),
(678, 17, 'addcontract', 'تعاقد', 'Contract', 1, 0),
(679, 17, 'contract_mass', 'وجب التنوية فى حالة تحرير الطلب سيتم اغلاق التذكرة', 'If the contract is completed, the ticket will be closed', 1, 0),
(680, 17, 'contract_date', 'تاريخ تحرير الطلب', 'تاريخ تحرير الطلب', 1, 0),
(681, 17, 'contract_des', 'تفاصيل الطلب', 'تفاصيل الطلب', 1, 0),
(682, 17, 'contract_wait', 'تعاقد معلق', 'Waiting Contract ', 1, 0),
(683, 17, 'close_end', 'تذاكر مغلقة', 'Closed Tickets ', 1, 0),
(684, 17, 'close_review', 'مغلقة للمراجعة', 'Closed for Review', 1, 0),
(685, 17, 'confirmcontract', 'تاكيد التعاقد', 'Confirm contract', 1, 0),
(686, 17, 'cust_data_updated', 'تم تحديث البيانات', 'Data Updated', 1, 0),
(687, 17, 'closing_date', 'تاريخ الاغلاق', 'Closing date', 1, 0),
(688, 17, 'reason_for_closure', 'سبب الاغلاق', 'Reason for closure', 1, 0),
(689, 17, 'previous_tickets', 'تذاكر سابقة للعميل', 'Previous customer tickets', 1, 0),
(690, 17, 'open_ticket', 'فتح تذكرة', 'Open Ticket', 1, 0),
(691, 17, 'open_ticket_err', 'لا يمكن فتح تذكرة جديده لنفس العميل برجاء اغلاق التذكرة المفتوحة اولا', 'Can not open a new ticket to the same customer Please close the open ticket first', 1, 0),
(692, 18, 'close_type_1', 'تعاقد', 'تعاقد', 1, 0),
(693, 18, 'close_type_2', 'ارشفة عميل', 'Archiving Customer', 1, 0),
(694, 18, 'close_type_3', 'خسارة عميل', 'Loss Customer', 1, 0),
(695, 18, 'mass_line_1', 'هل انت متاكد من اغلاق التذكرة رقم', 'Are you sure to close the ticket number', 1, 0),
(696, 18, 'mass_line_2', 'للعميل', 'For the client', 1, 0),
(697, 18, 'mass_line_3', 'برجاء تحديد سبب الاغلاق', 'Please specify the type of Close', 1, 0),
(698, 18, 'close_type', 'نوع الاغلاق', 'Close type', 1, 0),
(699, 18, 'c_type_2', 'تقييم العميل', 'تصنيف العميل', 1, 0),
(700, 18, 'c_type_3', 'سبب الارشفة', 'Archiving Reason', 1, 0),
(701, 18, 'c_type_4', 'سبب الخسارة', 'Loss Reason', 1, 0),
(702, 18, 'close_type_err', 'برجاء تحديد نوع الاغلاق', 'Please specify the type of Close', 1, 0),
(703, 18, 'close_des', 'سبب الاغلاق', 'Close Comment', 1, 0),
(704, 18, 'close_err_1', 'لا يمكن اتمام التعاقد بدون مراجعة بيانات العميل', 'The contract can not be completed without reviewing customer data', 1, 0),
(705, 19, 'main_h1', 'خدمة العملاء', 'خدمة العملاء', 1, 0),
(706, 19, 'follow_up_sales', 'متابعة المبيعات', 'Follow Up Sales', 1, 0),
(707, 19, 'updating_data', 'تحديث البيانات', 'Updating Data', 1, 0),
(708, 19, 'asked_assistant', 'طلب مساعدة', 'Asked Assistant', 1, 0),
(709, 19, 'closed_tickets', 'تذاكر مغلقة للمراجعة', 'Closed Tickets', 1, 0),
(710, 19, 'customer_name', 'اسم العميل', 'Customer Name', 1, 0),
(711, 19, 'employee_name', 'اسم الموظف', 'Employee Name', 1, 0),
(712, 19, 'end_closed', 'التذاكر المغلقة', 'Closed Tickets', 1, 0),
(713, 19, 'closed_for_contracting', 'مغلقة للتعاقد', 'Closed for contracting', 1, 0),
(714, 19, 'closed_for_archiving', 'مغلقة للارشفة', 'Closed for archiving', 1, 0),
(715, 19, 'closed_for_loss', 'مغلقة للخسارة', 'Closed for loss', 1, 0);
INSERT INTO `x_admin_lang_var` (`id`, `cat_id`, `var`, `name`, `name_en`, `state`, `postion`) VALUES
(716, 19, 'comment', 'تعليق خدمة العملاء', 'Customer Service Comment', 1, 0),
(717, 19, 'reopen', 'اعادة فتح التذكرة', 'Reopen the Ticket', 1, 0),
(718, 20, 'lead_type', 'تقرير طريقة التواصل', 'Leads Type Report', 1, 0),
(719, 20, 'lead_sours', 'تقرير مصدر التواصل', 'Leads Sours Report', 1, 0),
(720, 20, 'kind', 'تقرير النوع', 'Kind Report', 1, 0),
(721, 20, 'social', 'تقرير الحالة الاجتماعية', 'Social status report', 1, 0),
(722, 20, 'report_jop', 'تقرير المهنة', 'Jop Report', 1, 0),
(723, 20, 'live', 'تقرير الاقامة', 'Residence Report', 1, 0),
(724, 20, 'country', 'تقارير الجنسية', 'Nationality Reports', 1, 0),
(725, 20, 'country_live', 'تقرير دولة الاقامة', 'Country of Residence Report', 1, 0),
(726, 20, 'city', 'تقرير المحافظات', 'City Report', 1, 0),
(727, 20, 'ticket_state_0', 'تذكرة قيد المراجعة', 'تذكرة قيد المراجعة', 1, 0),
(728, 20, 'ticket_state_1', 'التذكرة مفتوحة', 'التذكرة مفتوحة', 1, 0),
(729, 20, 'ticket_state_2', 'تعاقد معلق', 'تعاقد معلق', 1, 0),
(730, 20, 'h1', 'التقارير', 'Reports', 1, 0),
(731, 20, 'cust_report', 'تقرير العملاء', 'Customer Report', 1, 0),
(732, 20, 'filter_all_cust', 'اختيار كل العملاء', 'Choose All Customer', 1, 0),
(733, 20, 'filter_leads_type', 'اختيار كل طرق التواصل', 'Choose All Leads Type', 1, 0),
(734, 20, 'filter_leads_sours', 'اختيار كل مصادر التواصل', 'Choose All Leads Sours', 1, 0),
(735, 20, 'filter_jop', 'اختيار كل المهن', 'Choose All Jop', 1, 0),
(736, 20, 'filter_kind', 'اختيار كل الجنس', 'Choose All Kind', 1, 0),
(737, 20, 'filter_social', 'اختيار كل الحالات الاجتماعية', 'Choose All Social type', 1, 0),
(738, 20, 'filter_city', 'اختيار كل المحافظات', 'Choose All City', 1, 0),
(739, 20, 'filter_live', 'اختيار كل انواع الاقامة', 'Choose All Live Type', 1, 0),
(740, 20, 'filter_country', 'اختيار كل دول الاقامة', 'Choose All Country', 1, 0),
(741, 20, 'fiter_nationality', 'اختيار كل الجنسيات', 'Choose All Nationality', 1, 0),
(742, 20, 'filter_but', 'فلترة', 'Filter', 1, 0),
(743, 20, 'arr_not_set_name', 'غير محدد', 'Undefined', 1, 0),
(744, 20, 'cust_type_h1', 'تقرير نوع العميل', 'Customer Type Report', 1, 0),
(745, 20, 'cust_type2_h1', 'تقرير تقيمات العملاء', 'Customer Feedback Report', 1, 0),
(746, 20, 'filter_all_cust_2', 'اختار كل التقيمات', 'Chose All Feedback', 1, 0),
(747, 20, 'other_vall', 'اخرى', 'Other', 1, 0),
(748, 20, 'totalcount', 'عدد النتائج', 'Number of Results', 1, 0),
(749, 20, 'ticket_report', 'تقرير التذاكر', 'Ticket Report', 1, 0),
(750, 20, 'from_date', 'من تاريخ', 'From Date', 1, 0),
(751, 20, 'to_date', 'الى تاريخ', 'To Date', 1, 0),
(752, 20, 'employee_name', 'اسم الموظف', 'Employee Name', 1, 0),
(753, 20, 'ticket_state_list', 'حالة التذكرة', 'Ticket State', 1, 0),
(754, 20, 'chose_all_state', 'اختيار كل الحالات', 'Chose All State', 1, 0),
(755, 20, 'employee', 'تقرير الموظفين', 'Employee Report', 1, 0),
(756, 20, 'ticket_state_r', 'تقرير حالة التذاكر', 'Ticket State Report', 1, 0),
(757, 20, 'number_of_visits', 'عدد الزيارت', 'Number of visits', 1, 0),
(758, 20, 'number_of_reservations', 'عدد الحجوزات', 'Number of reservations', 1, 0),
(759, 20, 'reservation_canceled', 'عدد الحجوزات الملغاه', 'Reservation canceled', 1, 0),
(760, 20, 'number_of_contract', 'عدد التعاقدات', 'Number of Contract', 1, 0),
(761, 20, 'campaign_report', 'تقرير الحملات', 'Campaign Report', 1, 0),
(762, 20, 'chose_all_campaign', 'اختار كل الحملات', 'Chose All Campaign', 1, 0),
(763, 20, 'customer_status_for_ticket', 'حالة العميل للتذكرة', 'Customer status for ticket', 1, 0),
(764, 20, 'status_for_ticket_report', 'تقرير حالة العملاء للتذكر', 'Status for ticket Report', 1, 0),
(765, 20, 'reservation_report', 'تقرير الحجوزات', 'Reservation Report', 1, 0),
(766, 20, 'leads_type_report', 'تقرير وسائل التواصل', 'Leads Type Report', 1, 0),
(767, 20, 'lead_sours_report', 'تقرير مصدار التواصل', 'Lead Sours Report', 1, 0),
(768, 20, 'contract_report', 'تقرير التعاقدات', 'Contract Report', 1, 0),
(769, 20, 'visits_report', 'تقرير الزيارات', 'Visits Report', 1, 0),
(770, 20, 'visits_information_mass', 'تفاصيل الزيارات', 'Visits Information', 1, 0),
(771, 20, 'date_added', 'تاريخ الاضافة', 'Date added', 1, 0),
(772, 20, 'date_of_visit', 'تاريخ الزيارة', 'Date of visit', 1, 0),
(773, 20, 'period_of_visit', 'فترة تحقيق الزيارة', 'Period to visit', 1, 0),
(774, 20, 'customer_data', 'بيانات العميل', 'Customer info', 1, 0),
(775, 20, 'visit_details', 'تفاصيل الزيارة', 'Visit details', 1, 0),
(776, 20, 'employee_name_t', 'اسم الموظف', 'Employee Name', 1, 0),
(777, 20, 'evaluation', 'تقيم العميل', 'Evaluation', 1, 0),
(778, 20, 'same_day', 'نفس اليوم', 'Same Day', 1, 0),
(779, 20, 'day', 'يوم', 'Day', 1, 0),
(780, 20, 'week', 'اسبوع', 'Week', 1, 0),
(781, 20, 'month', 'شهر', 'Month', 1, 0),
(782, 20, 'reservation_date', 'تاريخ الحجز', 'Reservation Date', 1, 0),
(783, 20, 'reservation_des', 'تفصيل الحجز', 'Reservation Details', 1, 0),
(784, 20, 'period_of_reservation', 'فترة تحقيق الحجز', 'Period of Reservation', 1, 0),
(785, 20, 'contract_date', 'تاريخ التعاقد', 'Contract Date', 1, 0),
(786, 20, 'period_of_contract', 'فترة تحقيق التعاقد', 'Period of Contract', 1, 0),
(787, 20, 'contract_details', 'تفاصيل التعاقد', 'Contract Details', 1, 0),
(788, 20, 'cancellation_but', 'تقارير الغاء الحجز', 'Cancellation', 1, 0),
(789, 20, 'cancellation_report', 'تقرير الغاء الحجز', 'Cancellation Report', 1, 0),
(790, 20, 'cancellation_date', 'تاريخ الغاء الحجز', 'Cancellation Date', 1, 0),
(791, 20, 'cancellation_details', 'تفاصيل الغاء الحجز', 'Cancellation Details', 1, 0),
(792, 20, 'period_of_cancellation', 'فترة الغاء الحجز', 'Period of Cancellation', 1, 0),
(793, 20, 'payment_methods_report', 'تقرير وسائل الدفع', 'Payment Methods report', 1, 0),
(794, 20, 'chose_all_payment_methods', 'اختيار كل وسائل الدفع', 'Choose All Payment Methods', 1, 0),
(795, 20, 'receipt_period', 'تقرير فترة الاستلام', 'Report Receipt Period', 1, 0),
(796, 20, 'choose_all_receipt_period', 'اختار كل فترات الاستلام', 'Choose All Receipt Period', 1, 0),
(797, 20, 'unit_type_report', 'تقرير نوع الوحدة', 'Unit Type Report', 1, 0),
(798, 20, 'choose_all_unit_type', 'اختار كل انواع الوحدات', 'Choose All Unit Type', 1, 0),
(799, 20, 'unit_area_report', 'تقرير المساحات', 'Unit Area Report', 1, 0),
(800, 20, 'choose_all_unit_area', 'اختار كل المساحات', 'Choose All Unit Area', 1, 0),
(801, 20, 'area_report', 'تقرير الاحياء', 'Area Report', 1, 0),
(802, 20, 'choose_all_area', 'اختيار كل الاحياء', 'Choose All Area', 1, 0),
(803, 20, 'lead_type_t', 'وسيلة التواصل', 'Lead Type', 1, 0),
(804, 20, 'lead_sours_t', 'مصدر التواصل', 'Lead Sours', 1, 0),
(805, 20, 'reservation_details', 'تفاصيل الحجوزات', 'Reservation Details', 1, 0),
(806, 20, 'contract_details_t', 'تفاصيل التعاقدات', 'Contract Details', 1, 0),
(807, 20, 'cancellation_details_t', 'تفاصيل الغاء الحجوزات', 'Cancellation Details', 1, 0),
(808, 20, 'general', 'تقرير عام', 'General Report', 1, 0),
(809, 20, 'events_report', 'تقرير الاحداث', 'Events Report', 1, 0),
(810, 20, 'new_ticket', 'التذاكر الجديدة', 'New Ticket', 1, 0),
(811, 20, 'followup', 'عدد المتابعات', 'Follow Up', 1, 0),
(812, 20, 'clients', 'عدد العملاء', 'Clients', 1, 0),
(813, 20, 'followup_report', 'تقرير المتابعات', 'Follow Up Report', 1, 0),
(814, 20, 'ticket_details', 'تفاصيل التذاكر', 'Ticket Details', 1, 0),
(815, 20, 'last_folo_date', 'اخر تاريخ متابعة', 'Last Follow Date', 1, 0),
(816, 20, 'ticket_period', 'فترة التذكرة', 'Ticket Period', 1, 0),
(817, 20, 'last_follow_up_period', 'فترة اخر متابعة', 'Last follow up period', 1, 0),
(818, 20, 'number_of_tickets', 'عدد التذاكر', 'Number of Tickets', 1, 0),
(819, 20, 'the_number_of_days', 'عدد الايام', 'The Number of days', 1, 0),
(820, 21, 'select_the_sales_section', 'تحديد قسم المبيعات', 'Select the Sales section', 1, 0),
(821, 21, 'chart_results_list', 'عدد النتائج فى المؤشر', 'Chart results List', 1, 0),
(822, 21, 'decrease_filter_size', 'تصغير حجم الفلترة', 'Decrease filter size', 1, 0),
(823, 21, 'filter_results_h1', 'فلترة النتائج', 'Filter Results', 1, 0),
(824, 21, 'report_period', 'تحديد فترة التقرير', 'Define the report period', 1, 0),
(825, 21, 'current_week', 'الاسبوع الحالى', 'Current Week', 1, 0),
(826, 21, 'current_month', 'الشهر الحالى', 'Current Month', 1, 0),
(827, 21, 'campaigns', 'الحملات الاعلانية', 'Campaign Name', 1, 0),
(828, 21, 'ticket_cust', 'حالة العمل للتذكرة', 'Customer status for ticket', 1, 0),
(829, 21, 'jop', 'المهن', 'jop', 1, 0),
(830, 21, 'kind', 'الجنس', 'Kind', 1, 0),
(831, 21, 'social', 'الحالة الاجتماعية', 'Social status', 1, 0),
(832, 21, 'live', 'الاقامة', 'Live status', 1, 0),
(833, 21, 'nationality', 'الجنسية', 'Nationality', 1, 0),
(834, 21, 'country_live', 'دولة الاقامة', 'Country of residence', 1, 0),
(835, 21, 'city', 'المحافظة', 'City', 1, 0),
(836, 22, 'h1', 'ادارة صفحات الهبوط', 'Manage Landing Page', 1, 0),
(840, 22, 'listpage', 'عرض صفحات الهبوط', 'List Page', 1, 0),
(841, 23, 'count_unit_per_page', 'عدد المحتوى فى الصفحة', 'Count Unit Per Page', 1, 0),
(842, 23, 'view_content_by', 'طريقة عرض المحتوى', 'View content By', 1, 0),
(843, 23, 'automatic_delete', 'الحذف التلقائى', 'Automatic Delete', 1, 0),
(844, 23, 'unit_redirect_add', 'اعادة التوجيه بعد الاضافة', 'Redirect After Add', 1, 0),
(845, 23, 'unit_redirect_edit', 'اعادة التوجيه بعد التعديل', 'Redirect After Edit', 1, 0),
(846, 23, 'redirect_settings_len', 'اعدادات العرض واعادة التوجيه', 'List View and Redirect Settings', 1, 0),
(847, 23, 'general_settings_len', 'الاعدادات العامة', 'General Settings', 1, 0),
(848, 23, 'maximum_image_width', 'اقصى عرض للصورة', 'Maximum Image Width', 1, 0),
(849, 23, 'maximum_image_height', 'اقصى ارتفاع للصورة', 'Maximum Image Height', 1, 0),
(850, 23, 'maximum_file_size', 'الحجم المسموح به بالــ  KB', 'Maximum File Size by KB', 1, 0),
(851, 23, 'u_thumbnail_image_upload_type', 'طريقة رفع الصورة المصغرة', 'Thumbnail Image Upload Type', 1, 0),
(852, 23, 'u_image_upload_type', 'طريقة رفع الصورة', 'Image Upload Type', 1, 0),
(853, 23, 'u_image_background_color', 'لون خلفية الصورة', 'Image Background Color', 1, 0),
(854, 23, 'u_image_width', 'عرض الصورة', 'Image width', 1, 0),
(855, 23, 'u_image_height', 'ارتفاع الصورة', 'Image Height', 1, 0),
(856, 23, 'u_thumbnail_image_width', 'عرض الصورة المصغرة', 'Thumbnail Image Width', 1, 0),
(857, 23, 'u_thumbnail_image_height', 'ارتفاع الصورة المصغرة', 'Thumbnail Image Height', 1, 0),
(858, 23, 'u_images_settings', 'اعدادات رفع الصور للقسم', 'Images Settings', 1, 0),
(859, 23, 'count_cat_per_page', 'عدد المجموعات فى الصفحة', 'Count Category Per Page', 1, 0),
(860, 23, 'cat_redirect_add', 'اعادة التوجيه بعد الاضافة', 'Redirect After Add', 1, 0),
(861, 23, 'cat_redirect_edit', 'اعادة التوجيه بعد التعديل', 'Redirect After Edit', 1, 0),
(862, 23, 'unit_add_photo_req_sate', 'اضافة الصورة للقسم', 'Add Photo To Section', 1, 0),
(863, 23, 'u_use_editor_state', 'استخدام محرر النصوص', 'Use Editor', 1, 0),
(864, 23, 'u_editor_settings_change', 'تعديل اعدادات محرر النصوص', 'Editor Settings Change', 1, 0),
(865, 23, 'u_editor_settings_save', 'حفظ اخر تنسيق لمحرر النصوص', 'Save Last Editor Settings', 1, 0),
(866, 23, 'fields_add_video', 'اضافة فيديو', 'Add Video', 1, 0),
(867, 23, 'fields_photo_video_related', 'صور وفيديو ذات صلة', 'Related Photo And Video', 1, 0),
(868, 23, 'fields_change_upload_photo_settings', 'تغيير طريقة رفع الصور', 'Change Upload Photo Settings', 1, 0),
(869, 23, 'fields_add_photo_section_type', 'اضافة صورة المحتوى', 'Add Photo To Section', 1, 0),
(870, 23, 'watermark_name', 'اسم الموقع', 'Site Name', 1, 0),
(871, 23, 'watermark_name_state', 'اضافة اسم الموقع للصورة', 'Add Site Name To Photo', 1, 0),
(872, 23, 'watermark_name_color', 'لون الخط', 'Font Color', 1, 0),
(873, 23, 'watermark_photo_state', 'اضافة العلامة المائية', 'Watermark State', 1, 0),
(874, 23, 'watermark_photo_position', 'مكان طباعة العلامة المائية', 'Watermark Position', 1, 0),
(875, 23, 'watermark_photo_edit', 'تعديل صورة العلامة المائية', 'Edit Watermark Photo', 1, 0),
(876, 23, 'watermark_photo_current', 'العلامة المائية الحالية', 'Current Watermark Photo', 1, 0),
(877, 23, 'morephoto_perpage', 'عدد الصور المعروضة', 'Count Photo Per Page', 1, 0),
(878, 23, 'seo_section_len', 'اعدادات الكلمات الدالة للقسم', 'SEO Section Settings', 1, 0),
(879, 23, 'seo_section_pagename_state', 'عنوان رابط الصفحة', 'URL Page Name', 1, 0),
(880, 23, 'seo_section_pagename_same', 'نفس الاسم', 'Same Name', 1, 0),
(881, 23, 'seo_section_pagename_manually', 'يتم تحديده يدويا', 'Manually Entry', 1, 0),
(882, 23, 'seo_section_pagename_withcat', 'يضاف اليه اسم المجموعة', 'Add Category Name', 1, 0),
(883, 23, 'seo_section_seo_settings', 'ضبط الكلمات الدالة', 'SEO Settings', 1, 0),
(884, 23, 'seo_section_seo_automatically', 'تلقائى', 'Automatically', 1, 0),
(885, 23, 'seo_section_seo_manually', 'يديوى', 'Manually', 1, 0),
(886, 23, 'seo_letter_state', 'طريقة اضافة الاسم', 'Letter State', 1, 0),
(887, 23, 'seo_letter_nochange', 'بدون تعديل', 'No Change', 1, 0),
(888, 23, 'seo_letter_allcapital', 'جميع الحروف Capital', 'All Letter Capital', 1, 0),
(889, 23, 'seo_letter_allsmall', 'جميع الحروف Small', 'All Letter Small', 1, 0),
(890, 23, 'seo_letter_fcapital', 'الحرف الاول Capital', 'First Letter Capital', 1, 0),
(891, 23, 'seo_cat_len', 'اعدادات الكلمات الدالة للمجموعة', 'SEO Category Settings', 1, 0),
(892, 23, 'seo_cat_pagename_same', 'نفس اسم المجموعة', 'Same Category Name', 1, 0),
(893, 23, 'seo_cat_pagename_state', 'عنوان رابط الصفحة', 'URL Page Name', 1, 0),
(894, 23, 'seo_cat_pagename_manually', 'يتم تحديده يدويا', 'Manually Entry', 1, 0),
(895, 23, 'seo_cat_seo_settings', 'ضبط الكلمات الدالة', 'SEO Settings', 1, 0),
(896, 23, 'seo_cat_seo_automatically', 'تلقائى', 'Automatically', 1, 0),
(897, 23, 'seo_cat_seo_manually', 'يدويى', 'Manually', 1, 0),
(898, 23, 'set_tab_state', 'استخدام الــ Tab', 'Use Tab', 1, 0),
(899, 23, 'set_photo_print_state', 'طباعة الصور داخل المحتوى', 'Print Photo in the Content', 1, 0),
(900, 23, 'set_photo_print_align_state', 'طريقة طباعة الصورة فى المحتوى', 'Type Print Photo in the Content', 1, 0),
(901, 23, 'set_photo_print_align', 'بالمحاذة', 'Align', 1, 0),
(902, 23, 'set_photo_print_attop', 'اعلى المحتوى', 'At The Top', 1, 0),
(903, 23, 'relatedphoto_len', 'اعدادات الصور والفيديو ذات الصلة', 'Related Photo And Video Settings', 1, 0),
(904, 23, 'relatedphoto_photo_state', 'طريقة عرض الصور ذات الصلة', 'View Related Photo', 1, 0),
(905, 23, 'relatedphoto_viewall', 'عرض الكل', 'View All', 1, 0),
(906, 23, 'relatedphoto_viewphotalbum', 'عرض البوم صور', 'View Photo Album', 1, 0),
(907, 23, 'relatedphoto_video_state', 'طريقة عرض الفيديوهات ذات الصلة', 'View Related Video', 1, 0),
(908, 23, 'relatedphoto_viewvideolbum', 'عرض البوم الفيدو', 'Video Album', 1, 0),
(909, 23, 'relatedphoto_countalbum_state', 'عدد البوم الصور والفيديو', 'Count Photo Video Album', 1, 0),
(910, 23, 'relatedphoto_countalbum_all', 'عرض الكل', 'View All', 1, 0),
(911, 23, 'relatedphoto_countalbum_less', 'عرض جزء', 'View Less', 1, 0),
(912, 23, 'relatedphoto_desview_state', 'طريقة اضافة الوصف', 'View Description', 1, 0),
(913, 23, 'relatedphoto_desview_up', 'اعلى المحتوى', 'Top of the Content', 1, 0),
(914, 23, 'relatedphoto_desview_down', 'اسفل المحتوى', 'Down Of The Content', 1, 0),
(915, 23, 'fields_change_png_settings', 'تغير حالة العلامة المائية', 'Change Watermark Settings', 1, 0),
(916, 23, 'seo_cat_pagename_same', 'نفس اسم المجموعة', 'Same Category Name', 1, 0),
(917, 23, 'seo_cat_lenss', 'اعدادات الكلمات الدالة للمجموعة', 'SEO Category Settings', 1, 0),
(918, 23, 'count_cat_per_page', 'عدد المجموعات فى الصفحة', 'Count Category Per Page', 1, 0),
(919, 23, 'cat_images_settings', 'اعدادات اضافة صورة المجموعة', 'Category Images Settings', 1, 0),
(920, 23, 'cat_add_photo_req_sate', 'اضافة صورة المجموعة', 'Add Category Photo', 1, 0),
(921, 23, 'cat_statistics_state', 'احصاء المجموعات', 'احصاء المجموعات', 1, 0),
(922, 23, 'u_video_settings_len', 'اعدادات اضافة الفيديو', 'Video Settings', 1, 0),
(923, 23, 'u_video_width', 'عرض ملف الفيديو', 'Video Width', 1, 0),
(924, 23, 'u_video_height', 'ارتفاع ملف الفيديو', 'Video Height', 1, 0),
(925, 23, 'u_youtube_photo_state', 'نسخ صورة اليوتيوب', 'Copy Youtube Photo', 1, 0),
(926, 23, 'google_meta_report', 'عرض اخطاء الكلمات الدالة', 'View Meta Error Report', 1, 0),
(927, 23, 'google_meta_suggestions', 'عرض اقترحات الكلمات الدالة', 'View Keyword Suggestions', 1, 0),
(928, 23, 'no_meta_cat_select', 'لم يتم تحديد مجموعات مقترحة للكلمات الدالة', 'No identify groups Searches for words function', 1, 0),
(929, 23, 'config_metacat_select_all', 'اختيار الكل', 'Select All', 1, 0),
(930, 23, 'view_but', 'عرض', 'View', 1, 0),
(931, 22, 'add_page', 'اضافة صفحة هبوط', 'Add Page', 1, 0),
(932, 22, 'edit_page', 'تعديل صفحة هبوط', 'Edit Page', 1, 0),
(933, 22, 'page_name', 'اسم الصفحة', 'Page Name', 1, 0),
(934, 22, 'campaign', 'الحملة الاعلانية', 'Campaign Name', 1, 0),
(935, 22, 'url', 'رابط الصفحة', 'Page Url', 1, 0),
(936, 22, 'page_title', 'عنوان الصفحة', 'Page Title', 1, 0),
(937, 22, 'details', 'التفاصيل', 'Details', 1, 0),
(938, 22, 'description', 'وصف الصفحة', 'Page Description', 1, 0),
(939, 22, 'name_err', 'اسم الصفحة مستخدم من قبل', 'The page name is already used', 1, 0),
(940, 22, 'url_err', 'رابط الصفحة مستخدم من قبل', 'The page URL is already used', 1, 0),
(941, 22, 'order_page', 'ترتيب الصفحات', 'Order Page', 1, 0),
(942, 22, 'dell', 'حذف صفحة', 'Delete Page', 1, 0),
(943, 22, 'order_block', 'ترتيب المحتوى', 'Order Content', 1, 0),
(944, 22, 'view_content', 'عرض المحتوى', 'View Content', 1, 0),
(945, 22, 'block_type', 'نوع المحتوى', 'Block Type', 1, 0),
(946, 22, 'type_banner', 'اضافة بانر', 'Add Banner', 1, 0),
(947, 22, 'type_text', 'اضافة نص', 'Add Text', 1, 0),
(948, 22, 'type_youtube', 'اضافة فيديو يوتيوب', 'Add YouTube', 1, 0),
(949, 22, 'type_google', 'اضافة موقع جوجل', 'Add Google Location', 1, 0),
(950, 22, 'type_photo', 'اضافة البوم صور', 'Add Photo', 1, 0),
(951, 22, 'type_form', 'اضافة اتصل بنا', 'Add Form', 1, 0),
(952, 22, 'bl_name', 'العنوان', 'Title', 1, 0),
(953, 22, 'contract_err', 'اسم المحتوى العربى او الانجليزى او الـ Id مستخدم من قبل', 'The name of the Arabic or English content or Id is used by', 1, 0),
(954, 22, 'content_title', 'عنوان المحتوى', 'Content Title', 1, 0),
(955, 22, 'content', 'المحتوى', 'Content', 1, 0),
(956, 22, 'video_url', 'رابط الفيديو', 'Video Url', 1, 0),
(957, 22, 'edit_content', 'تعديل محتوى', 'Edit Content', 1, 0),
(958, 22, 'add_cat', 'اضافة مجموعة صور', 'Add a Photo Category', 1, 0),
(959, 22, 'list_cat', 'عرض مجموعة الصور', 'View photo Category', 1, 0),
(960, 22, 'edit_cat', 'تعديل المجموعة', 'Edit Category', 1, 0),
(961, 22, 'dell_cat', 'حذف المجموعة', 'Delete Category', 1, 0),
(962, 22, 'cat_name', 'اسم المجموعة', 'Category Name', 1, 0),
(963, 22, 'add_photo', 'اضافة صورة', 'Add Photo', 1, 0),
(964, 22, 'photo_section_settings', 'اعدادات صورة القسم', 'Photo Section Settings', 1, 0),
(965, 22, 'photo_album_settings', 'اعدادات البوم الصور', 'Photo Album Settings', 1, 0),
(966, 22, 'viw_photo', 'عرض الصور', 'View Photo', 1, 0),
(967, 22, 'photo_name', 'اسم الصور', 'Photo Name', 1, 0),
(968, 22, 'order_photo', 'ترتيب الصور', 'Order Photo', 1, 0),
(969, 22, 'edit_photo', 'تعديل صورة', 'Edit Photo', 1, 0),
(970, 22, 'mob_h1', 'اعدادات رسالة ترحيب نسخة الموبايل', 'Mobile Welcome Message', 1, 0),
(971, 22, 'mob_num', 'رقم الموبايل', 'Mobile Number', 1, 0),
(972, 22, 'mob_title', 'عنوان رسالة الترحيب', 'Message Title', 1, 0),
(973, 22, 'mob_des', 'رسالة الترحيب', 'Message Details', 1, 0),
(974, 22, 'mob_state', 'الحالة', 'State', 1, 0),
(975, 22, 'welcome_err', 'برجاء اضافة رسالة الترحيب', 'Please Add Welcome Message', 1, 0),
(976, 22, 'google_h1', 'اعدادات الصفحة لمحرك البحث', 'Page settings for the search engine', 1, 0),
(977, 22, 'photo_zoom', 'تكبير الصور', 'Photo Zoom', 1, 0),
(978, 22, 'view_photo_name', 'عرض اسم الصور', 'View Photo Name', 1, 0),
(979, 22, 'view_photo_details', 'عرض تفاصيل الصورة', 'View Photo Details', 1, 0),
(980, 22, 'address', 'العنوان', 'Address', 1, 0),
(981, 22, 'phone', 'ارقارم التواصل', 'Contact Numbers', 1, 0),
(982, 22, 'view_url', 'عرض الصفحة', 'View Page', 1, 0),
(983, 15, 'facebook', 'فيس بوك', 'FaceBook', 1, 0),
(984, 15, 'landingpage', 'صفحات الهبوط', 'Landing Page', 1, 0),
(985, 22, 'date_add', 'التاريخ', 'Date', 1, 0),
(986, 22, 'customer_data', 'بيانات العميل', 'Customer Data', 1, 0),
(987, 22, 'lead_info', 'تفاصيل', 'Lead Info', 1, 0),
(988, 22, 'list_new_date', 'عرض البيانات الجديدة', 'List New Date', 1, 0),
(989, 22, 'list_old_date', 'عرض البيانات القديمة', 'List Old Date', 1, 0),
(990, 22, 'transfer_data', 'نقل البيانات', 'Transfer Data', 1, 0),
(991, 22, 'export_data', 'تصدير البيانات', 'Export Data', 1, 0),
(992, 22, 'export', 'تصدير', 'Export', 1, 0),
(993, 22, 'export_err', 'برجاء تحديد البيانات التى سيتم تصديرها', 'Please specify the data to be exported', 1, 0),
(994, 22, 'data_type', 'تحديد نوع البيانات', 'Select the data type', 1, 0),
(995, 22, 'all_data', 'تصدير كل البيانات', 'Export All Data', 1, 0),
(996, 22, 'client_data', 'تصدير بيانات العميل فقط', 'Export only client data', 1, 0),
(997, 22, 'image_postion', 'مكان عرض الصورة', 'Image Postion', 1, 0),
(998, 22, 'postion_top', 'اعلى المحتوى', 'Top Content', 1, 0),
(999, 22, 'postion_below', 'اسفل المحتوى', 'Below the content', 1, 0),
(1000, 22, 'next_to_the_content', 'بجانب المحتوى', 'Next to the content', 1, 0),
(1001, 22, 'image_size', 'حجم الصورة', 'Image size', 1, 0),
(1002, 22, 'h1_javecode', 'اضافة اكواد المتابعة', 'Add code to follow', 1, 0),
(1003, 22, 'h1_thanks', 'تفاصيل صفحة الشكر', 'Thanks page details', 1, 0),
(1004, 22, 'site_url', 'رباط الموقع', 'WebSite Url', 1, 0),
(1005, 2, 'emptypage', 'خطأ فى تحديد المحتوى', 'Error determining content', 1, 0),
(1006, 12, 'mod_lppage', 'صفحات الهبوط', 'Landing Page', 1, 0),
(1007, 6, 'default_image', 'الصور الافتراضية', 'Default Image', 1, 0),
(1008, 6, 'web_state', 'حالة الموقع', 'Web State', 1, 0),
(1009, 6, 'open', 'مفتوح', 'Open', 1, 0),
(1010, 6, 'closed', 'مغلق', 'Closed', 1, 0),
(1011, 6, 'basic_settings', 'الاعدادات الاساسية للموقع', 'The basic settings of the site', 1, 0),
(1012, 6, 'site_name', 'اسم الموقع', 'Site Name', 1, 0),
(1013, 6, 'site_url', 'رابط الموقع', 'Site Url', 1, 0),
(1014, 6, 'close_message', 'رسالة الاغلاق', 'Close Message', 1, 0),
(1015, 6, 'opening_state', 'افتتاح الموقع فى حالة الاغلاق', 'Opening State', 1, 0),
(1016, 6, 'manually', 'يدويا', 'Manually', 1, 0),
(1017, 6, 'automatically', 'تلقائيا', 'Automatically', 1, 0),
(1018, 6, 'right_mode', 'الروابط النصية', 'Right Mode', 1, 0),
(1019, 6, 'open_date', 'تاريخ افتتاح الموقع', 'Open Date', 1, 0),
(1020, 6, 'language_settings', 'اعدادات اللغة', 'Language settings', 1, 0),
(1021, 6, 'allow_language_change', 'السماح بتغير اللغة', 'Allow language change', 1, 0),
(1022, 6, 'default_language', 'اللغة الافتراضية', 'Default language', 1, 0),
(1023, 6, 'arabic', 'اللغة العربية', 'Arabic', 1, 0),
(1024, 6, 'english', 'اللغة الانجليزية', 'English', 1, 0),
(1025, 6, 'social', 'اعدادات مواقع المشاركة', 'Settings of Social sites', 1, 0),
(1026, 6, 'sharing_sites', 'عرض مواقع المشاركة فى المحتوى', 'View content sharing sites', 1, 0),
(1027, 6, 'logo_photo', 'شعار الموقع', 'Web site Logo', 1, 0),
(1028, 6, 'photo_header', 'هيدير الموقع', 'Web Site Header', 1, 0),
(1029, 6, 'li_chang_lang', 'English', 'عربى', 1, 0),
(1030, 15, 'total', 'الاجمالى', 'Total', 1, 0),
(1031, 15, 'err_lead_cat', 'برجاء تحديد الحملة الاعلانية', 'Please select an ad campaign', 1, 0),
(1032, 15, 'err_sel_content', 'لم يتم تحديد محتوى للنقل برجاء تحديد المحتوى', 'No content selected for transport Please select content', 1, 0),
(1033, 2, 'check_the_date', 'برجاء مراجعة التاريخ', 'Please check the date', 1, 0),
(1034, 19, 'ignore_but', 'تجاهل', 'Ignore', 1, 0),
(1035, 16, 'evaluation', 'تقيم العميل', 'Evaluation', 1, 0),
(1036, 16, 'customer_information', 'بيانات العميل', 'Customer Information', 1, 0),
(1037, 16, 'visits_but', 'الزيارات', 'Visits', 1, 0),
(1038, 16, 'reservations_but', 'الحجوزات', 'Reservations', 1, 0),
(1039, 13, 'country', 'الدول', 'Country', 1, 0),
(1040, 13, 'city', 'المحافظات', 'City', 1, 0),
(1041, 13, 'country_add', 'اضافة دولة', 'Country Add', 1, 0),
(1042, 13, 'country_list', 'عرض الدول', 'Country List', 1, 0),
(1043, 13, 'country_edit', 'تعديل دولة', 'Country Edit', 1, 0),
(1044, 13, 'country_dell', 'حذف دولة', 'Delete Country', 1, 0),
(1045, 13, 'update', 'تحديث البيانات', 'Update Date', 1, 0),
(1046, 2, 'config', 'اعدادات القسم', 'Settings', 1, 0),
(1047, 13, 'update_date_mass', 'تم تحديث البيانات بنجاح', 'Data updated successfully', 1, 0),
(1048, 13, 'city_add', 'اضافة محافظة', 'City Add', 1, 0),
(1049, 13, 'city_list', 'عرض المحافظات', 'City List', 1, 0),
(1050, 13, 'city_edit', 'تعديل محافظة', 'City Edit', 1, 0),
(1051, 13, 'delete_city', 'حذف محافظة', 'Delete City', 1, 0),
(1052, 11, 'live_op', 'برجاء تحديد نوع الاقامة', 'Please specify the type of stay', 1, 0),
(1053, 11, 'specify_nationality', 'برجاء تحديد الجنسية', 'Please specify nationality', 1, 0),
(1054, 11, 'please_specify_your_country', 'برجاء تحديد دولة الاقامة', 'Please specify your country', 1, 0),
(1055, 24, 'h1', 'نسخ احتياطي', 'Back Up', 1, 0),
(1056, 24, 'list', 'عرض النسخ الاحتياطية', 'View Backups Files', 1, 0),
(1057, 24, 'add', 'اضافة نسخط احتياطية', 'Create New Back up', 1, 0),
(1058, 24, 'dell', 'حذف الملف', 'Delete File', 1, 0),
(1059, 24, 'download', 'تحميل الملف', 'Download File', 1, 0),
(1060, 24, 'add_date', 'تاريخ الاضافة', 'Add Date', 1, 0),
(1061, 24, 'file_name', 'اسم الملف', 'File Name', 1, 0),
(1062, 24, 'method', 'طريقة النسخ', 'Back up Method', 1, 0),
(1063, 24, 'automatic', 'تلقائى', 'Automatic', 1, 0),
(1064, 24, 'manually', 'يدويا', 'Manually', 1, 0),
(1065, 24, 'transfer', 'حالة النقل', 'Transfer Status', 1, 0),
(1066, 16, 'change_date', 'تغير تاريخ التذكرة', 'Change Date', 1, 0),
(1067, 16, 'change_date_mass', 'هل انت متاكد من تغيير تاريخ فتح التذكرة رقم', 'Are you sure to change the ticket opening date', 1, 0),
(1068, 16, 'current_date', 'التاريخ الحالى', 'Current date', 1, 0),
(1069, 16, 'select_the_new_date', 'تحديد التاريخ الجديد', 'Select The new date', 1, 0),
(1070, 20, 't_totalcount_new', 'اجمالى عدد التذاكر', 'Total number of tickets', 1, 0),
(1071, 20, 't_review', 'التذاكر قيد المراجعة', 'Tickets under review', 1, 0),
(1072, 20, 't_open', 'التذاكر المفتوحة', 'Tickets open', 1, 0),
(1073, 20, 'close_review', 'التذاكر المغلقة للمراجعة', 'Closed for review', 1, 0),
(1074, 20, 'close', 'التذاكر المغلقة', 'Closed Tickets', 1, 0),
(1075, 20, 'report_ticket', 'تقرير التذاكر', 'Ticket Report', 1, 0),
(1076, 20, 'today_report', 'التقرير اليوميى', 'Daily Report', 1, 0),
(1077, 20, 'follow_report', 'تقرير المتابعات', 'Follow-up report', 1, 0),
(1078, 20, 'total_follow', 'اجمالى المتابعات', 'Total follow', 1, 0),
(1079, 20, 'follow_new_tickets', 'متابعات للتذاكرالجديدة', 'New tickets', 1, 0),
(1080, 20, 'old_tickets_follow', 'متابعات التذاكر السابقة', 'Old Tickets Follow', 1, 0),
(1081, 20, 'number_of_clients', 'عدد العملاء', 'Number of clients', 1, 0),
(1082, 20, 'ticket_date', 'تاريخ التذكرة', 'Ticket Date', 1, 0),
(1083, 20, 'details_of_todays_tickets', 'تفاصيل متابعات تذاكر اليوم', 'Details of todays tickets', 1, 0),
(1084, 20, 'previous_tickets', 'تفاصيل متابعات تذاكر سابقة', 'Previous Tickets', 1, 0),
(1085, 20, 'followreport', 'تقرير المتابعات', 'Follow Report', 1, 0),
(1086, 20, 'ticketsreport', 'تقارير التذاكر', 'Tickets Report', 1, 0),
(1087, 20, 'chart_new_follow', 'متابعات التذاكر الجديدة', 'New Ticket Follow', 1, 0),
(1088, 20, 'old_ticket_follow', 'متابعات التذاكرالسابقة', 'Old Ticket Follow', 1, 0),
(1089, 25, 'h1', 'الصفحة الرئيسية', 'Dashboard', 1, 0),
(1090, 25, 'general_statistics', 'احصائيات عامة', 'General Statistics', 1, 0),
(1091, 25, 'today_statistics', 'احصائية اليوم', 'Today statistics', 1, 0),
(1092, 25, 'number_of_clients', 'عدد العملاء', 'Number of clients', 1, 0),
(1093, 19, 'closed_tickets_h1', 'اغلاق تذكرة', 'Closed Tickets', 1, 0),
(1094, 19, 'change_close_status', 'تغيير حالة الاغلاق', 'Change Close status', 1, 0),
(1095, 19, 'add_follow', 'اضافة متابعة', 'اضافة متابعة', 1, 0),
(1096, 19, 'close_type_1', 'اجمالى التعاقد', 'Total Contract', 1, 0),
(1097, 19, 'close_type_2', 'اجمالى الارشفة', 'Total Archives', 1, 0),
(1098, 19, 'close_type_3', 'اجمالى الخسارة', 'Total loss', 1, 0),
(1099, 19, 'sales_close', 'اغلاق المبيعات', 'Sales Close', 1, 0),
(1100, 19, 'customer_service_close', 'اغلاق خدمة العملاء', 'Customer Service', 1, 0),
(1101, 2, 'max_day_err_01', 'برجاء تحديد فترة اقل من', 'Please specify a period less than', 1, 0),
(1102, 2, 'max_day_err_02', 'يوم لكى تتمكن من عرض المحتوى', 'Day in order to view the content', 1, 0),
(1103, 20, 'chose_all_date_receipt', 'اختيار كل فترات الاستلام', 'Select all delivery periods', 1, 0),
(1104, 20, 'annual_report', 'التقرير السنوى', 'Annual Report', 1, 0),
(1105, 16, 'lead_info', 'تفاصيل', 'Lead Info', 1, 0),
(1106, 16, 'view_leads_info', 'عرض تفاصيل', 'View Leads Info', 1, 0),
(1107, 13, 'reason_add', 'اضافة سبب لفتح التذكرة', 'اضافة سبب لفتح التذكرة', 1, 0),
(1108, 13, 'reason_list', 'عرض اسباب فتح التذكرة', 'عرض اسباب فتح التذكرة', 1, 0),
(1109, 13, 'reason_dell', 'حذف سبب فتح التذكرة', 'حذف سبب فتح التذكرة', 1, 0),
(1110, 13, 'reason_edit', 'تعديل سبب فتح التذكرة', 'تعديل سبب فتح التذكرة', 1, 0),
(1111, 13, 'reason_but', 'سبب فتح التذكرة', 'سبب فتح التذكرة', 1, 0),
(1112, 17, 'priority_1', 'عادى', 'Normal', 1, 0),
(1113, 17, 'priority_2', 'متوسط', 'medium', 1, 0),
(1114, 17, 'priority_3', 'هام', 'Important', 1, 0),
(1115, 17, 'priority_sel_name', 'درجة الاهمية', 'Priority', 1, 0),
(1116, 26, 'district', 'District', 'District', 1, 0),
(1117, 26, 'service_type', 'Service type', 'Service type', 1, 0),
(1118, 26, 'campaign_name', 'Campaign Name', 'Campaign Name', 1, 0),
(1119, 26, 'request_type', 'Request Type', 'Request Type', 1, 0),
(1120, 26, 'request_information', 'Request Information', 'Request Information', 1, 0),
(1121, 26, 'follow_calltime', 'وقت الاتصال', 'Call Time', 1, 0),
(1122, 26, 'budget', 'Budget', 'Budget', 1, 0),
(1123, 11, 'add_new_ticket', 'فتح تذكرة جديدة', 'اضافة تذكرة جديدة', 1, 0),
(1124, 17, 'crunt_t_state', 'حالة التذكرة', 'حالة التذكرة', 1, 0),
(1125, 11, 'customers_service', 'خدمة العملاء', 'Customers Service', 1, 0),
(1126, 17, 't_reason', 'سبب فتح التذكرة', 'سبب فتح التذكرة', 1, 0),
(1127, 19, 'custservice_t_list', 'عرض العملاء', 'عرض العملاء', 1, 0),
(1128, 20, 'closedticket', 'تقرير الاغلاق', 'تقرير الاغلاق', 1, 0),
(1129, 20, 'closedticket_r', 'تقارير الاغلاق', 'تقارير الاغلاق', 1, 0),
(1130, 11, 'exportcust', 'تصدير البيانات', 'ExportCust', 1, 0),
(1131, 2, 'cust_cat', 'قسم خدمة العملاء', 'قسم خدمة العملاء', 1, 0),
(1132, 19, 'reportsales', 'التقرير اليومي خدمة قبل البيع', 'التقرير اليومي خدمة قبل البيع', 1, 0),
(1133, 19, 'reportcust', 'التقرير اليوميى لقسم خدمة العملاء', 'التقرير اليوميى لقسم خدمة العملاء', 1, 0),
(1134, 19, 'reportsales_moth', 'التقرير الشهرى خدمة قبل البيع', 'التقرير الشهرى خدمة قبل البيع', 1, 0),
(1135, 19, 'reportfollow_cust', 'التقرير الشهرى لقسم خدمة العملاء', 'التقرير الشهرى لقسم خدمة العملاء', 1, 0),
(1136, 27, 'h1', 'ادارة الرسائل', 'ادارة الرسائل', 1, 0),
(1137, 27, 'send_ar', 'رسالة عربى', 'رسالة عربى', 1, 0),
(1138, 27, 'send_en', 'رسالة انجليزى', 'رسالة انجليزى', 1, 0),
(1139, 27, 'arr_mass_1', 'عدد ا رسالة', 'عدد ا رسالة', 1, 0),
(1140, 27, 'arr_mass_2', 'عدد 2 رسالة', 'عدد 2 رسالة', 1, 0),
(1141, 27, 'arr_mass_3', 'عدد 3 رسالة', 'عدد 3 رسالة', 1, 0),
(1142, 27, 'ar_count', 'عدد الرسائل العربى', 'عدد الرسائل العربى', 1, 0),
(1143, 27, 'en_count', 'عدد الرسائل الانجليزى', 'عدد الرسائل الانجليزى', 1, 0),
(1144, 27, 'sms_c_name', 'اسم الحملة', 'اسم الحملة', 1, 0),
(1145, 27, 'send_sms_but', 'ارسال الرسالة', 'ارسال الرسالة', 1, 0),
(1146, 27, 'h1_send', 'ارسال حملة اعلانية جديدة |', 'ارسال حملة اعلانية جديدة', 1, 0),
(1147, 27, 'sms_type_1', 'رسالة عربى', 'رسالة عربى', 1, 0),
(1148, 27, 'sms_type_2', 'رسالة انجليزى', 'رسالة انجليزى', 1, 0),
(1149, 27, 'username', 'User Name', 'User Name', 1, 0),
(1150, 27, 'password', 'Password', 'Password', 1, 0),
(1151, 27, 'sendername', 'Sender Name', 'Sender Name', 1, 0),
(1152, 27, 'send_date', 'تاريخ الارسال', 'تاريخ الارسال', 1, 0),
(1153, 27, 'send_type', 'نوع الارسال', 'نوع الارسال', 1, 0),
(1154, 27, 'count', 'عدد العملاء', 'عدد العملاء', 1, 0),
(1155, 27, 'total', 'عدد الارقام', 'عدد الارقام', 1, 0),
(1156, 27, 'report', 'تقارير', 'تقارير', 1, 0),
(1157, 27, 'mass', 'الرسالة', 'الرسالة', 1, 0),
(1158, 2, 'morephoto_err_mass', 'حدث خطأ فى تحميل الملف', 'There was an error loading the file', 1, 0),
(1159, 2, 'morephoto_done_mass', 'تم تحميل الملف بنجاح', 'This file was upload Successfully', 1, 0),
(1160, 2, 'morephoto_count_file', 'عدد الملفات :', 'File Count :', 1, 0),
(1161, 2, 'morephoto_count_done', 'عدد الملفات التى تم تحميلها :', 'Number of files uploaded :', 1, 0),
(1162, 2, 'morephoto_count_err', 'عدد الملفات التى لم يتم تحميلها :', 'Number of files not uploaded :', 1, 0),
(1163, 2, 'incorrect_type_of_file', 'لابد ان يكون امتداد الصورة JPG GIF PNG', 'Image must be JPG GIF PNG', 1, 0),
(1164, 2, 'file_too_big', 'لابد ان يكون حجم الملف اقل من', 'The file size must be less than', 1, 0),
(1165, 2, 'uploaded_missing', 'لابد من اضافة صورة', 'You must add a Photo', 1, 0),
(1166, 2, 'image_too_wide', 'لابد ان يكون اقصى عرض للصورة', 'Must be the maximum width of the image', 1, 0),
(1167, 2, 'image_too_tall', 'لابد ان يكون اقصى ارتفاع للصورة', 'Must be the maximum height of the image', 1, 0),
(1168, 2, 'h1_list', 'عرض', 'List', 1, 0),
(1169, 2, 'h1_add', 'Add', 'Add', 1, 0),
(1170, 2, 'h1_edit', 'Edit', 'Edit', 1, 0),
(1171, 2, 'h1_dell', 'Delete', 'Delete', 1, 0),
(1172, 2, 'menu_settings', 'الاعدادات', 'Settings', 1, 0),
(1173, 2, 'but_order', 'Sort Content', 'Sort Content', 1, 0),
(1174, 2, 'h1_order', 'Sort Content', 'Sort Content', 1, 0),
(1175, 2, 'seo_h1', 'Page Settings for the Search Engine', 'Page Settings for the Search Engine', 1, 0),
(1176, 2, 'seo_page_url', 'Page Url', 'Page Url', 1, 0),
(1177, 2, 'seo_page_title', 'Page Title', 'Page Title', 1, 0),
(1178, 2, 'seo_description', 'Page Description', 'Page Description', 1, 0),
(1179, 2, 'mainfilde_name', 'Name', 'Name', 1, 0),
(1180, 2, 'mainfilde_des', 'Description', 'Description', 1, 0),
(1181, 2, 'sort', 'Sort', 'Sort', 1, 0),
(1182, 2, 'seo_error_h1', 'Seo Error', 'Seo Error', 1, 0),
(1183, 2, 'seo_page_name', 'Page Name', 'Page Name', 1, 0),
(1184, 2, 'seo_page_des', 'Page Description', 'Page Description', 1, 0),
(1185, 2, 'mainfilde_category', 'Category', 'Category', 1, 0),
(1186, 2, 'seo_page_keyword', 'Page Keywords', 'Page Keywords', 1, 0),
(1187, 6, 'email_add_new_h1', 'Add New Account', 'Add New Account', 1, 0),
(1188, 6, 'email_account_name', 'Account Name', 'Account Name', 1, 0),
(1189, 6, 'email_site_name', 'Site Name', 'Site Name', 1, 0),
(1190, 6, 'email_email', 'Email', 'Email', 1, 0),
(1191, 6, 'email_server_name', 'Server Name', 'Server Name', 1, 0),
(1192, 6, 'email_port', 'Port', 'Port', 1, 0),
(1193, 6, 'email_username', 'User Name', 'User Name', 1, 0),
(1194, 6, 'email_password', 'Password', 'Password', 1, 0),
(1195, 6, 'email_list', 'List Email Account', 'List Email Account', 1, 0),
(1196, 6, 'email_edit', 'Edit Email Account', 'Edit Email Account', 1, 0),
(1197, 6, 'but_web_config', 'Web Config', 'Web Config', 1, 0),
(1198, 6, 'but_email_account', 'Email Account', 'Email Account', 1, 0),
(1199, 6, 'but_meta_tags', 'Meta Tags', 'Meta Tags', 1, 0),
(1200, 6, 'but_photosize', 'Photo Size', 'Photo Size', 1, 0),
(1201, 6, 'photo_size_name', 'الاسم', 'Name', 1, 0),
(1202, 6, 'image_dimensions', 'مقاسات الصورة', 'Image Dimensions', 1, 0),
(1203, 6, 'watermark_h1', 'العلامة المائية', 'Watermark', 1, 0),
(1204, 6, 'watermark_text', 'Watermark Text', 'Watermark Text', 1, 0),
(1205, 6, 'watermark_text_state', 'Watermark Text State', 'Watermark Text State', 1, 0),
(1206, 6, 'watermark_photo_state', 'Watermark  Photo State', 'Watermark  Photo State', 1, 0),
(1207, 6, 'watermark_position', 'Watermark Position', 'Watermark Position', 1, 0),
(1208, 6, 't_thumbnail', 'ابعاد الصورة المصغرة', 'Thumbnail Dimensions', 1, 0),
(1209, 6, 't_photo', 'ابعاد الصورة', 'Photo Dimensions', 1, 0),
(1210, 6, 'upload_photo_type', 'طريقة رفع الصورة للقسم', 'Upload Photo Type', 1, 0),
(1211, 6, 'photo_file_rename', 'اعادة تسمية الملف', 'Rename File', 1, 0),
(1212, 6, 'photo_quality', 'دقة رفع الصورة', 'Upload Quality', 1, 0),
(1213, 6, 'meta_catid', 'CatId', 'CatId', 1, 0),
(1214, 6, 'meta_page_title', 'Page Title', 'Page Title', 1, 0),
(1215, 6, 'meta_page_description', 'Page Description', 'Page Description', 1, 0),
(1216, 28, 'main_h1', 'Manage Web Site', 'Manage Web Site', 1, 0),
(1217, 28, 'banner_menu', 'Manage Banner', 'Manage Banner', 1, 0),
(1218, 28, 'banner_price', 'Starting Price', 'Starting Price', 1, 0),
(1219, 28, 'banner_title', 'Title', 'Title', 1, 0),
(1220, 28, 'banner_url', 'Read More Url', 'Read More Url', 1, 0),
(1221, 28, 'banner_url_type', 'Url Type', 'Url Type', 1, 0),
(1222, 28, 'banner_url_type_1', 'Same Page', 'Same Page', 1, 0),
(1223, 28, 'banner_url_type_2', 'New Page', 'New Page', 1, 0),
(1224, 28, 'developers_menu', 'Manage Developers', 'Manage Developers', 1, 0),
(1225, 28, 'h1_config_banner', 'Banner Settings', 'Banner Settings', 1, 0),
(1226, 28, 'h1_config_developers', 'Developers Settings', 'Developers Settings', 1, 0),
(1227, 28, 'banner_cat_menu', 'Banner Category', 'Banner Category', 1, 0),
(1228, 12, 'sales_group', 'فريق المبيعات', 'Sales Group', 1, 0),
(1229, 12, 'mod_pipeline', 'Pipeline', 'Pipeline', 1, 0),
(1230, 12, 'mod_sales_menu', 'Sales Menu', 'Sales Menu', 1, 0),
(1231, 12, 'mod_team_leader', 'مشرف عام قسم المبيعات', 'Team Leader', 1, 0),
(1232, 12, 'mod_closed_cases', 'Closed Cases', 'Closed Cases', 1, 0),
(1233, 12, 'changepassword', 'تغيير كلمة المرور', 'Change Password', 1, 0),
(1234, 12, 'active_team_leader', 'تفعيل خاصية مشرف المبيعات', 'Active Team Leader', 1, 0),
(1235, 12, 'unactive_team_leader', 'تعطيل خاصية مشرف المبيعات', 'UnActive Team Leader', 1, 0),
(1236, 12, 'profile_h1', 'الملف الشخصى', 'User Profile', 1, 0),
(1237, 12, 'pass_exp_err_mass_1', 'كلمة المرور تنتهى صلاحيتها فى ', 'Your Password will Expire Soon in', 1, 0),
(1238, 12, 'pass_exp_err_mass_2', 'برجاء تغيير كلمة المرور فى اقرب وقت ', 'Please Change it ASAP', 1, 0),
(1239, 12, 'pass_exp_err_mass_3', 'كلمة المرور منتهية الصلاحية يجب تغير كلمة المرور حتى تتمكن من اتمام عملية التسجيل', 'Your Password Has Expired To continue you must change your password', 1, 0),
(1240, 12, 'old_password', 'كلمة المرور الحالية', 'Old Password', 1, 0),
(1241, 12, 'new_password', 'كلمة المرور الجديدة', 'New Password', 1, 0),
(1242, 12, 'confirm_your_new_password', 'تأكيد كلمة المرور', 'Confirm Your New Password', 1, 0),
(1243, 12, 'new_password_err', 'كلمة المرور لابد ان على رقم وحرف كابيتال وحرف اسمول على الاقل', 'Password must contain at least one lower case letter, one upper case letter and one digit', 1, 0),
(1244, 12, 'password_does_not_match', 'كلمة المرور غير متطابقة ', 'Password does not match', 1, 0),
(1245, 12, 'but_login_information', 'بيانات تسجيل الدخول ', 'Login Information', 1, 0),
(1246, 12, 'pass_last_change', 'اخر تعديل ', 'Last Change', 1, 0),
(1247, 12, 'pass_status', 'حالة كلمة المرور', 'Password Status', 1, 0),
(1248, 12, 'user_profile', 'الملف الشخصى ', 'User Profile', 1, 0),
(1249, 12, 'no_online_user', 'لا يوجد مستخدمين حاليا ', 'No Online User', 1, 0),
(1250, 12, 'online_user', 'المستخدمين المتواجدين حاليا', 'Online User', 1, 0),
(1251, 12, 'force_change_password', 'فرض تغيير كلمة المرور', 'Force Change Password', 1, 0),
(1252, 12, 'password_expired', 'كلمة المرور منتهية الصلاحية', 'Password Expired', 1, 0),
(1253, 12, 'expired_day', 'يوم', 'Day', 1, 0),
(1254, 12, 'change_code', 'تغيير كود التحقق', 'Change Authentication Code', 1, 0),
(1255, 12, 'auth_m_01', 'عزيزى', 'Dear', 1, 0),
(1256, 12, 'auth_m_02', 'لقد قمنا بتحديث نظام تسجيل الدخول\r\nاسم التطبيق: Authy 2-Factor Authentication\r\nيرجى تنزيل التطبيق واستخدام رمز الاستجابة السريعة لتكوين الإعدادات تلقائيًا\r\nأو استخدم \"رمز المصادقة\" لضبط الإعدادات يدويًا', 'We have updated the login system \r\nApp Name :  Authy 2-Factor Authentication\r\nPlease download the application and use QR Code to configure settings automatically\r\nOr use the Authentication Code to manually adjust the settings', 1, 0),
(1257, 12, 'auth_m_03', 'كود التوثيق الخاص بك هو', 'Your Authentication Code is', 1, 0),
(1258, 11, 'religion_h1', 'الديانة', 'Religion', 1, 0),
(1259, 11, 'religion_muslim', 'مسلم', 'Muslim', 1, 0),
(1260, 11, 'religion_christian', 'مسيحى', 'Christian', 1, 0),
(1261, 11, 'address', 'العنوان', 'Address', 1, 0),
(1262, 22, 'pageedit', 'تعديل الصفحة', 'Page Edit', 1, 0),
(1263, 22, 'edit_tracking_code', 'تعديل اكواد التتبع', 'Edit Tracking Code', 1, 0),
(1264, 22, 'edit_mobile_welcome', 'تعديل رسالة ترحيب الموبايل', 'Edit Mobile Welcome', 1, 0),
(1265, 22, 'edit_contact_form', 'تعديل فورم اتصل بنا', 'Edit Contact Form', 1, 0),
(1266, 22, 'save_order', 'حفظ الترتيب', 'Save Order', 1, 0),
(1267, 22, 'add_multiple_photo', 'اضافة صور جماعية', 'Add Multiple Photo', 1, 0),
(1268, 24, 'full_backup_photo', 'نسخ كامل للصورة', 'Full Back Up Photo', 1, 0),
(1269, 24, 'monthly_backup_photo', 'نسخ شهرية للصور', 'Monthly Back Up Photo', 1, 0),
(1270, 24, 'file_size', 'حجم الملف', 'File Size', 1, 0),
(1271, 24, 'create_full_back_up', 'انشاء نسخة جديد', 'Create Full Back Up', 1, 0),
(1272, 24, 'create_monthly_back_up', 'انشاء نسخة جديده', 'Create Monthly Back Up', 1, 0),
(1273, 24, 'copy_file', 'نسخ الملف', 'Copy File', 1, 0),
(1274, 25, 'welcome', 'اهلا وسهلا بك', 'Welcome Back', 1, 0),
(1275, 25, 'logout', 'تسجيل الخروج', 'LogOut', 1, 0),
(1276, 3, 'menu_sort', 'ترتيب القوائم', 'Menu Sort', 1, 0),
(1277, 3, 'adminmenu_h1', 'ادارة القوائم', 'ادارة القوائم', 1, 0),
(1278, 3, 'control_panel', 'خصائص لوحة التحكم', 'خصائص لوحة التحكم', 1, 0),
(1279, 3, 'save_order', 'حفظ الترتيب', 'حفظ الترتيب', 1, 0),
(1280, 3, 'menu_for_site_manager', 'قائمة خاصة بمدير الموقع', 'قائمة خاصة بمدير الموقع', 1, 0),
(1281, 15, 'importleads_total', 'اجمالى العدد', 'اجمالى العدد', 1, 0),
(1282, 15, 'total_right', 'اجمالى البيانات الصحيحة', 'اجمالى البيانات الصحيحة', 1, 0),
(1283, 15, 'wrong_data', 'اجمالى البيانات الخطاء', 'اجمالى البيانات الخطاء', 1, 0),
(1284, 15, 'add_file_xlx', 'اضافة الملف برجاء التاكد من ان يكون الامتداد هو xls', 'اضافة الملف برجاء التاكد من ان يكون الامتداد هو xls', 1, 0),
(1285, 15, 'import_c_h1', 'اعدادات استيراد الملف', 'اعدادات استيراد الملف', 1, 0),
(1286, 15, 'import_name', 'الاسم', 'الاسم', 1, 0),
(1287, 15, 'import_email', 'البريد الالكترونى', 'البريد الالكترونى', 1, 0),
(1288, 15, 'import_mobile', 'رقم الموبايل', 'رقم الموبايل', 1, 0),
(1289, 15, 'import_mobile_2', 'رقم الموبايل الاضافى', 'رقم الموبايل الاضافى', 1, 0),
(1290, 15, 'import_jop', 'الوظيفة', 'الوظيفة', 1, 0),
(1291, 15, 'import_area', 'المساحة', 'المساحة', 1, 0),
(1292, 15, 'import_edu', 'نوع الدورة', 'نوع الدورة', 1, 0),
(1293, 15, 'delete_leads', 'حذف العملاء الجدد', 'Delete Leads', 1, 0),
(1294, 15, 'delete_all', 'حذف الكل', 'Delete All', 1, 0),
(1295, 15, 'employee_results', 'انت الان تقوم بعرض النتائج الخاصة بالموظف', 'You are now viewing the results for the employee', 1, 0),
(1296, 17, 'follow_calltime', 'موعد الاتصال', 'Call Time', 1, 0),
(1297, 17, 'request_information', 'التفاصيل', 'التفاصيل', 1, 0),
(1298, 2, 'list', 'عرض', 'عرض', 1, 0),
(1299, 2, 'name', 'الاسم', 'Name', 1, 0),
(1300, 2, 'feature_is_not_available', 'هذه الخاصية غير متاحة برجاء مراجعة خدمة العملاء', 'This feature is not available. Please check customer service', 1, 0),
(1301, 7, 'flo_edit', 'تعديل الدور', 'تعديل الدور', 1, 0),
(1302, 19, 'report_menu', 'التقارير', 'Reports', 1, 0),
(1303, 12, 'custserv_group', 'خدمة العملاء', 'خدمة العملاء', 1, 0),
(1304, 12, 'mod_custserv_leader', 'مشرف عام خدمة العملاء', 'مشرف عام خدمة العملاء', 1, 0),
(1305, 12, 'mod_custserv_supper', 'خدمة عملاء كامل الصلاحيات', 'خدمة عملاء كامل الصلاحيات', 1, 0),
(1306, 12, 'unactive_custserv_leader', 'تعطيل مشرف عام خدمة العملاء', 'تعطيل مشرف عام خدمة العملاء', 1, 0),
(1307, 12, 'active_custserv_leader', 'تفعيل مشرف عام خدمة العملاء', 'تفعيل مشرف عام خدمة العملاء', 1, 0),
(1308, 29, 'main_h1', 'التذاكر المغلقة', 'التذاكر المغلقة', 1, 0),
(1309, 2, 'config_h1', 'اعدادات القسم', 'اعدادات القسم', 1, 0),
(1310, 29, 'totalcount', 'اجمالى التذاكر المغلقة', 'اجمالى التذاكر المغلقة', 1, 0),
(1311, 2, 'data_tabel', 'جدول البيانات', 'Data Tabel', 1, 0),
(1312, 2, 'data_tabel_max', 'اقصى محتوى لجدول البيانات', 'اقصى محتوى لجدول البيانات', 1, 0),
(1313, 29, 'old_ticket_h1', 'تفاصيل تذكرة رقم', 'تفاصيل تذكرة رقم', 1, 0),
(1314, 19, 'but', 'خدمة العملاء', 'خدمة العملاء', 1, 0),
(1315, 19, 'salesfollow_but', 'متابعة المبيعات', 'متابعة المبيعات', 1, 0),
(1316, 2, 'from_date', 'من تاريخ', 'من تاريخ', 1, 0),
(1317, 2, 'to_date', 'الى تاريخ', 'الى تاريخ', 1, 0),
(1318, 2, 'fiter_but', 'فلترة', 'فلترة', 1, 0),
(1319, 19, 'salesfollow_h1', 'متابعة المبيعات', 'متابعة المبيعات', 1, 0),
(1320, 2, 'view_des_but', 'عرض التفاصيل', 'عرض التفاصيل', 1, 0),
(1321, 19, 'closed_follow_h1', 'متابعة تذاكر مغلقة', 'متابعة تذاكر مغلقة', 1, 0),
(1322, 11, 'tab_notes', 'ملاحظات العميل', 'ملاحظات العميل', 1, 0),
(1323, 11, 'notes_add_but', 'اضافة ملاحظة جديدة', 'اضافة ملاحظة جديدة', 1, 0),
(1324, 11, 'notes_des', 'الملاحظة', 'الملاحظة', 1, 0),
(1325, 11, 'dell_notes_h1', 'حذف ملاحظات العملاء', 'حذف ملاحظات العملاء', 1, 0),
(1326, 11, 'notes_dell_confim', 'هل انت متاكد من حذف هذه الملاحظة', 'هل انت متاكد من حذف هذه الملاحظة', 1, 0),
(1327, 17, 'add_new_ticket', 'اضافة تذكرة جديدة', 'اضافة تذكرة جديدة', 1, 0),
(1328, 2, 'ajex_delete', 'الحذف التلقائى', 'الحذف التلقائى', 1, 0),
(1329, 2, 'active_mode', 'حجب المحتوى المعطل', 'حجب المحتوى المعطل', 1, 0),
(1330, 12, 'userphoto_view', 'عرض صورة البروفيل', 'عرض صورة البروفيل', 1, 0),
(1331, 12, 'cat_config', 'اعدادات المجموعات', 'اعدادات المجموعات', 1, 0),
(1332, 12, 'user_config', 'اعدادات الاعضاء', 'اعدادات الاعضاء', 1, 0),
(1333, 12, 'profile_photo', 'صورة', 'صورة', 1, 0),
(1334, 11, 'religion_notset', 'لا استطيع التحديد', 'لا استطيع التحديد', 1, 0),
(1335, 11, 'search_by_code', 'البحث برقم العميل', 'البحث برقم العميل', 1, 0),
(1336, 15, 'list_import_leads', 'عرض العملاء الجدد من ملفات', 'List Import Leads', 1, 0),
(1337, 15, 'delete_new_leads', 'حذف من العملاء الجدد', 'Delete New Leads', 1, 0),
(1338, 15, 'importleads', 'اضافة ملف جديد', 'import leads', 1, 0),
(1339, 15, 'list_wrong_data', 'عرض البيانات الخطاء', 'List Wrong Data', 1, 0),
(1340, 15, 'delete_all_data', 'حذف جميع البيانات', 'Delete All Data', 1, 0),
(1341, 15, 'delete_repeat_leads', 'حذف من البيانات المكرره', 'Delete Repeat Leads', 1, 0),
(1342, 15, 'delete_existing_clients', 'حذف من العملاء الحاليين', 'Delete Existing Clients', 1, 0),
(1343, 15, 'export_new_leads', 'تصدير العملاء الجدد', 'Export New Leads', 1, 0),
(1344, 15, 'export_existing_clients', 'تصدير العملاء الحاليين', 'Export Existing Clients', 1, 0),
(1345, 15, 'export_all', 'تصدير الكل', 'Export All', 1, 0),
(1346, 15, 'delete_all_data_mass', 'هل انت متاكد من حذف جميع البيانات الموجودة حاليا..', 'Are you sure you want to delete All Data', 1, 0),
(1347, 13, 'catname', 'اسم المجموعة', 'اسم المجموعة', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_admin_menu`
--

CREATE TABLE `x_admin_menu` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cat_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `freestyle` int(11) DEFAULT '0',
  `web_admin` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  `count_unit` int(11) DEFAULT '0',
  `count_unit_a` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `x_admin_menu`
--

INSERT INTO `x_admin_menu` (`id`, `name`, `name_en`, `cat_id`, `icon`, `freestyle`, `web_admin`, `state`, `count_unit`, `count_unit_a`, `postion`) VALUES
(3, 'الاعدادات', 'Web Config', 'config', 'fa-cogs', 0, 1, 1, 2, 2, 8),
(4, 'ضبط لغة التحكم', 'Admin Lang', 'admin_lang', 'fa-language', 1, 0, 1, 6, 6, 14),
(5, 'ضبط لغة الموقع', 'WebSite Lang', 'web_lang', 'fa-text-width', 0, 0, 1, 6, 6, 15),
(6, 'ضبط القوائم', 'Manage Menu', 'admin_menu', 'fa-bars', 1, 0, 1, 6, 6, 17),
(11, 'ادارة المشروعات', 'Manage Prohect', 'project', 'fa-building-o', 0, 0, 1, 7, 7, 11),
(12, 'ادارة التعاقدات', 'ادارة التعاقدات', 'contract', 'fa-paperclip', 0, 0, 1, 7, 6, 12),
(13, 'ادارة العملاء', 'Manage Customer', 'customer', 'fa-address-card', 0, 0, 1, 5, 5, 6),
(14, 'الاعضاء والصلاحيات', 'User &amp; Permission', 'permission', 'fa-lock', 0, 0, 1, 4, 4, 13),
(15, 'خدمة العملاء', 'Customer Service', 'custserv', 'fa-ticket', 0, 0, 1, 3, 3, 3),
(16, 'متابعة العملاء', 'Customer Follow', 'salesdep', 'fa-volume-control-phone', 0, 0, 1, 7, 7, 0),
(17, 'ادارة البيانات', 'Manage Data', 'managedate', 'fa-files-o', 0, 0, 1, 16, 7, 16),
(18, 'اضافة اتصال', 'Add New Leads', 'hotline', 'fa-phone-square', 0, 0, 1, 3, 2, 1),
(19, 'توزيع الاتصالات', 'Manage Leads', 'leads', 'fa-random', 0, 0, 1, 5, 1, 7),
(20, 'التقارير', 'Report', 'report', 'fa-bar-chart-o', 0, 0, 1, 12, 12, 10),
(21, 'صفحات الهبوط', 'Landing Page', 'lppage', 'fa-html5', 0, 0, 1, 7, 7, 9),
(22, 'ارسال SMS', 'Send SMS', 'sendsms', 'fa-comment-o', 0, 0, 1, 4, 4, 5),
(23, 'التذاكر المغلقة', 'Closed Tickets', 'closedticket', 'fa-times', 0, 0, 1, 2, 2, 4),
(24, 'خدمة قبل البيع', 'خدمة قبل البيع', 'salesfollow', 'fa-users', 0, 0, 1, 4, 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `x_admin_menu_sub`
--

CREATE TABLE `x_admin_menu_sub` (
  `id` int(11) NOT NULL,
  `cat_id` int(11) DEFAULT '0',
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name_en` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `views` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `admin_view` int(11) DEFAULT '0',
  `state` int(11) DEFAULT '0',
  `postion` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `x_admin_menu_sub`
--

INSERT INTO `x_admin_menu_sub` (`id`, `cat_id`, `name`, `name_en`, `path`, `views`, `admin_view`, `state`, `postion`) VALUES
(4, 6, 'اضافة القوائم الفرعية', 'Add SubMenu', 'Menu', 'Add', 0, 1, 2),
(6, 6, 'عرض القوائم الفرعية', 'List Sub Menu', 'Menu', 'List', 0, 1, 3),
(9, 3, 'الاعدادات الرئيسية', 'Web Config', 'Config', 'WebConfig', 0, 1, 0),
(10, 4, 'اضافة مجموعة', 'Add Category', 'LangAdmin', 'Cat_Add', 0, 1, 0),
(11, 4, 'عرض المجموعات', 'List Category', 'LangAdmin', 'Cat_List', 0, 1, 1),
(12, 4, 'الاعدادات', 'Config', 'LangAdmin', 'Config', 0, 1, 4),
(13, 4, 'اضافة محتوى', 'Add Content', 'LangAdmin', 'Add', 0, 1, 2),
(14, 4, 'عرض المحتوى', 'List Content', 'LangAdmin', 'List', 0, 1, 3),
(15, 4, 'تحديث ملفات اللغة', 'Update Language', 'LangAdmin', 'UpdateLang', 0, 1, 5),
(16, 6, 'اضافة مجموعة', 'Add Category', 'Menu', 'Cat_Add', 0, 1, 0),
(17, 6, 'عرض المجموعات', 'List Category', 'Menu', 'Cat_List', 0, 1, 1),
(18, 6, 'ترتيب القوائم', 'Sort Menu', 'Menu', 'Cat_Postion', 0, 1, 4),
(19, 6, 'الاعدادات', 'Config', 'Menu', 'Config', 0, 1, 5),
(20, 5, 'اضافة مجموعة', 'Add Category', 'LangWeb', 'Cat_Add', 0, 1, 0),
(21, 5, 'عرض المجموعات', 'List Category', 'LangWeb', 'Cat_List', 0, 1, 1),
(22, 5, 'الاعدادات', 'Config', 'LangWeb', 'Config', 0, 1, 4),
(23, 5, 'اضافة محتوى', 'Add Content', 'LangWeb', 'Add', 0, 1, 2),
(24, 5, 'عرض المحتوى', 'List Content', 'LangWeb', 'List', 0, 1, 3),
(25, 5, 'تحديث ملفات اللغة', 'Update Language', 'LangWeb', 'UpdateLang', 0, 1, 5),
(46, 3, 'الصور الافتراضية', 'Default Image', 'Config', 'MainPhoto', 0, 1, 1),
(47, 11, 'اضافة مشروع', 'Add Project', 'Project', 'Add', 0, 1, 1),
(48, 11, 'عرض المشروعات', 'List Project', 'Project', 'List', 0, 1, 2),
(49, 11, 'عرض الوحدات', 'List Unit', 'Project', 'UnitList', 0, 1, 3),
(50, 11, 'اضافة جدول اسعار', 'اضافة جدول اسعار', 'Project', 'Price_Add', 0, 1, 4),
(51, 11, 'عرض جداول الاسعار', 'عرض جداول الاسعار', 'Project', 'Price_List', 0, 1, 5),
(52, 11, 'ادارة الاحياء', 'ادارة الاحياء', 'Project', 'AreaList', 0, 1, 0),
(53, 12, 'حجوزات معلقة', 'حجوزات معلقة', 'Contract', 'Reservation_List', 0, 1, 2),
(54, 13, 'اضافة عميل', 'Add Customer', 'Customer', 'Add', 0, 1, 0),
(55, 13, 'عرض العملاء', 'List Customer', 'Customer', 'Current', 0, 1, 1),
(56, 14, 'اضافة مجموعة', 'Add Group', 'Permission', 'Cat_Add', 0, 1, 0),
(57, 14, 'عرض المجموعات', 'List Groups', 'Permission', 'Cat_List', 0, 1, 0),
(58, 14, 'عرض المستخدمين', 'List  Users', 'Permission', 'List', 0, 1, 0),
(59, 14, 'اضافة مستخدم', 'Add User', 'Permission', 'Add', 0, 1, 0),
(60, 12, 'حجوزات ملغاه', 'حجوزات ملغاه', 'Contract', 'Canceled', 0, 1, 3),
(61, 12, 'استمارة تعاقد', 'استمارة تعاقد', 'Contract', 'Contract', 0, 1, 4),
(62, 12, 'تحرير استمارة', 'تحرير استمارة', 'Contract', 'List', 0, 1, 1),
(63, 12, 'تحرير استمارة تعاقد', 'تحرير استمارة تعاقد', 'Contract', 'Tabel_Cont', 0, 0, 5),
(64, 11, 'اعدادات القسم', 'اعدادات القسم', 'Project', 'Config', 0, 1, 6),
(66, 12, 'عرض جدول الوحدادت', 'عرض جدول الوحدادت', 'Contract', 'ListUnit', 0, 1, 0),
(67, 12, 'التعاقدات الملغاه', 'التعاقدات الملغاه', 'Contract', 'ContractD', 0, 1, 6),
(69, 16, 'متابعات اليوم', 'Follow-up today', 'SalesDep', 'ListToday', 0, 1, 2),
(70, 17, 'طريقة التواصل', 'Lead Type', 'ManageDate', 'ListLeadType', 0, 1, 3),
(71, 17, 'مصدر التواصل', 'Leads Sours', 'ManageDate', 'ListLeadSours', 0, 1, 0),
(72, 17, 'حالات العملاء', 'Customer cases', 'ManageDate', 'CustSubList', 0, 1, 4),
(73, 18, 'اضافة اتصال جديد', 'Add New Customer', 'HotLine', 'Add', 0, 1, 0),
(74, 19, 'توزيع الاتصالات الجديدة', 'Distribution of new customers', 'Leads', 'List', 0, 1, 0),
(75, 18, 'عرض الاتصالات', 'List Customer', 'HotLine', 'List', 0, 1, 2),
(76, 19, 'تقارير التوزيع', 'Distribution Report', 'Leads', 'ReportDate', 0, 0, 1),
(77, 16, 'عميل جديد', 'New Customer', 'SalesDep', 'ListNew', 0, 1, 1),
(78, 16, 'عرض العملاء', 'List Customer', 'SalesDep', 'ListAllCust', 0, 1, 0),
(79, 17, 'الحالة الاجتماعية', 'Social status', 'ManageDate', 'ListSocial', 0, 0, 5),
(80, 17, 'المساحات', 'Area', 'ManageDate', 'ListArea', 0, 0, 9),
(81, 17, 'مواعيد الاستلام', 'Date of receipt', 'ManageDate', 'ListDate', 0, 0, 6),
(82, 17, 'النماذج', 'Models', 'ManageDate', 'ListUnit', 0, 0, 8),
(83, 17, 'طرق السداد', 'Methods of payment', 'ManageDate', 'ListCash', 0, 0, 7),
(84, 17, 'وقت الاتصال', 'Best Time To Call', 'ManageDate', 'ListTime', 0, 0, 10),
(85, 17, 'افضل تواصل', 'Better connect', 'ManageDate', 'ListBestcall', 0, 0, 11),
(86, 17, 'الوظائف', 'job', 'ManageDate', 'ListJop', 0, 0, 2),
(87, 16, 'متابعات لم تتم', 'No follow-ups', 'SalesDep', 'ListBack', 0, 1, 3),
(88, 16, 'تقارير يوميى', 'Daily reports', 'SalesDep', 'Report', 0, 1, 4),
(90, 13, 'الاعدادات', 'Setting', 'Customer', 'Config', 0, 1, 4),
(91, 13, 'فلترة العملاء', 'Customer Filter', 'Customer', 'FilterCust', 0, 1, 2),
(92, 20, 'تقرير العملاء', 'Customer Report', 'Report', 'CustView', 0, 1, 1),
(93, 20, 'تقرير التذاكر', 'Ticket Report', 'Report', 'TicketRport', 0, 1, 2),
(94, 20, 'تقرير الزيارات', 'Visits Report', 'Report', 'Visits', 0, 1, 3),
(95, 20, 'تقرير التعاقدات', 'Contract Report', 'Report', 'Contract', 0, 1, 5),
(96, 20, 'تقرير مصدار التواصل', 'Lead Sours Report', 'Report', 'LeadSours', 0, 1, 7),
(97, 20, 'تقرير وسائل التواصل', 'Leads Type Report', 'Report', 'LeadType', 0, 1, 8),
(98, 20, 'تقرير الحجوزات', 'Reservation Report', 'Report', 'Reservation', 0, 1, 4),
(99, 20, 'الاعدادات', 'Config', 'Report', 'Config', 0, 1, 9),
(100, 20, 'تقرير الغاء الحجز', 'Cancellation Report', 'Report', 'Cancellation', 0, 1, 6),
(101, 20, 'تقرير عام', 'General Report', 'Report', 'General', 0, 1, 0),
(102, 13, 'بحث عن عميل', 'Customer Search', 'Customer', 'Search', 0, 1, 3),
(103, 18, 'اضافة سريعة', 'Fast Add Customer', 'HotLine', 'FastAdd', 0, 0, 1),
(105, 17, 'الحملات الاعلانية', 'Ad Campaigns', 'ManageDate', 'LeadCat', 0, 1, 1),
(106, 21, 'عرض الصفحات', 'List Page', 'Landing', 'ListPage', 0, 1, 0),
(107, 21, 'اضافة صفحة', 'Add Page', 'Landing', 'PageAdd', 0, 1, 1),
(108, 21, 'ترتيب الصفحات', 'Order Page', 'Landing', 'PageOrder', 0, 1, 2),
(109, 21, 'عرض مجموعات الصور', 'View Photo Category', 'Landing', 'PhotoCat', 0, 1, 3),
(110, 21, 'اضافة صورة', 'Add Photo', 'Landing', 'AddPhoto', 0, 1, 5),
(111, 21, 'الاعدادات', 'Config', 'Landing', 'Config', 0, 1, 6),
(112, 21, 'عرض الصور', 'View Photo', 'Landing', 'PhotoList', 0, 1, 4),
(113, 19, 'الاعدادات', 'Config', 'Leads', 'Config', 0, 0, 4),
(114, 19, 'فيس بوك', 'FaceBook Leads', 'Leads', 'FaceBook', 0, 0, 2),
(115, 19, 'صفحات الهبوط', 'Landing Page', 'Leads', 'LandingPage', 0, 0, 3),
(116, 15, 'الاعدادات', 'Config', 'CustService', 'Config', 0, 1, 6),
(117, 17, 'الدول', 'Country', 'ManageDate', 'Country', 0, 0, 12),
(118, 17, 'المحافظات', 'City', 'ManageDate', 'City', 0, 1, 13),
(119, 17, 'الاعدادات', 'Config', 'ManageDate', 'Config', 0, 1, 14),
(120, 16, 'تقرير المتابعات', 'Follow Report', 'SalesDep', 'FollowReport', 0, 1, 5),
(121, 16, 'تقرير التذاكر', 'Tickets Report', 'SalesDep', 'TicketsReport', 0, 1, 6),
(122, 15, 'خدمة العملاء', 'خدمة العملاء', 'CustService', 'TCustService', 0, 1, 2),
(123, 17, 'اسباب فتح التذكرة', 'اسباب فتح التذكرة', 'ManageDate', 'ListOpenReason', 0, 1, 0),
(124, 20, 'التقرير السنوى', 'التقرير السنوى', 'Report', 'Annual', 0, 1, 0),
(125, 20, 'تقرير الاغلاق', 'تقرير الاغلاق', 'Report', 'ClosedTicket', 0, 1, 0),
(126, 15, 'التقارير', 'Report', 'CustService', 'Reports', 0, 1, 3),
(129, 22, 'رسالة عربى', 'رسالة عربى', 'SMS', 'Send_AR', 0, 1, 0),
(130, 22, 'الاعدادات', 'Config', 'SMS', 'Config', 0, 1, 3),
(131, 22, 'رسالة انجليزى', 'رسالة انجليزى', 'SMS', 'Send_EN', 0, 1, 1),
(132, 22, 'تقارير', 'تقارير', 'SMS', 'Report', 0, 1, 2),
(133, 23, 'الاعدادات', 'Config', 'ClosedTicket', 'Config', 0, 1, 1),
(134, 23, 'عرض التذاكر', 'List Closed Ticket', 'ClosedTicket', 'List&amp;ClearFilter', 0, 1, 0),
(135, 24, 'تحديث البيانات', 'تحديث البيانات', 'SalesFollow', 'Updating', 0, 0, 0),
(136, 24, 'طلبات المساعدة', 'طلبات المساعدة', 'SalesFollow', 'Assistant', 0, 0, 0),
(137, 24, 'تذاكر مغلقة للمراجعة', 'تذاكر مغلقة للمراجعة', 'SalesFollow', 'CloseReview', 0, 1, 0),
(138, 24, 'متابعة تذاكر مغلقة', 'متابعة تذاكر مغلقة', 'SalesFollow', 'CloseFollow', 0, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `x_back_up`
--

CREATE TABLE `x_back_up` (
  `id` int(11) NOT NULL,
  `date_add` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type` int(11) DEFAULT '0',
  `b_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `date_month` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `path` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `x_back_up`
--

INSERT INTO `x_back_up` (`id`, `date_add`, `name`, `type`, `b_type`, `date_month`, `path`, `state`) VALUES
(12, '1570572000', 'EtNewSystem_2019-10-09_02-01-12', 1, 'sql', NULL, 'EtNewSystem_2019-10-09_02-01-12.zip', 1),
(13, '1570572000', 'EtNewSystem_2019-10-09_02-01-19', 1, 'sql', NULL, 'EtNewSystem_2019-10-09_02-01-19.zip', 1),
(14, '1570572000', 'EtNewSystem_2019-10-09_02-16-28', 1, 'sql', NULL, 'EtNewSystem_2019-10-09_02-16-28.zip', 1),
(15, '1570572000', 'EtNewSystem_2019-10-09_11-48-45', 1, 'sql', NULL, 'EtNewSystem_2019-10-09_11-48-45.zip', 1),
(16, '1570572000', 'EtNewSystem_2019-10-09_22-50-38', 1, 'sql', NULL, 'EtNewSystem_2019-10-09_22-50-38.zip', 1),
(17, '1570658400', 'EtNewSystem_2019-10-10_14-16-46', 1, 'sql', NULL, 'EtNewSystem_2019-10-10_14-16-46.zip', 1),
(18, '1571004000', 'EtNewSystem_2019-10-14_21-30-47', 1, 'sql', NULL, 'EtNewSystem_2019-10-14_21-30-47.zip', 1),
(19, '1571522400', 'EtNewSystem_2019-10-20_16-35-31', 1, 'sql', NULL, 'EtNewSystem_2019-10-20_16-35-31.zip', 1),
(20, '1572127200', 'EtNewSystem_2019-10-27_15-55-47', 1, 'sql', NULL, 'EtNewSystem_2019-10-27_15-55-47.zip', 1),
(21, '1572127200', 'EtNewSystem_2019-10-27_15-56-37', 1, 'sql', NULL, 'EtNewSystem_2019-10-27_15-56-37.zip', 1),
(22, '1572645600', 'EtNewSystem_2019-11-02_17-37-27', 1, 'sql', NULL, 'EtNewSystem_2019-11-02_17-37-27.zip', 1),
(23, '1572645600', 'EtNewSystem_2019-11-02_17-38-14', 1, 'sql', NULL, 'EtNewSystem_2019-11-02_17-38-14.zip', 1),
(24, '1572645600', 'EtNewSystem_2019-11-02_17-38-26', 1, 'sql', NULL, 'EtNewSystem_2019-11-02_17-38-26.zip', 1),
(25, '1572818400', 'EtNewSystem_2019-11-04_12-14-25', 1, 'sql', NULL, 'EtNewSystem_2019-11-04_12-14-25.zip', 1),
(26, '1573509600', 'EtNewSystem_2019-11-12_10-52-11', 1, 'sql', NULL, 'EtNewSystem_2019-11-12_10-52-11.zip', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `config`
--
ALTER TABLE `config`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_cat`
--
ALTER TABLE `config_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_data`
--
ALTER TABLE `config_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_meta`
--
ALTER TABLE `config_meta`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_photo`
--
ALTER TABLE `config_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_notes`
--
ALTER TABLE `customer_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_sub`
--
ALTER TABLE `customer_sub`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_ticket`
--
ALTER TABLE `cust_ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cust_ticket_des`
--
ALTER TABLE `cust_ticket_des`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cust_id` (`cust_id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `date_add` (`date_add`);

--
-- Indexes for table `c_leads`
--
ALTER TABLE `c_leads`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `facebook_data`
--
ALTER TABLE `facebook_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fi_city`
--
ALTER TABLE `fi_city`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fi_country`
--
ALTER TABLE `fi_country`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_lead_sours`
--
ALTER TABLE `fs_lead_sours`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_lead_type`
--
ALTER TABLE `fs_lead_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_report_chart`
--
ALTER TABLE `fs_report_chart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_ticket_closed`
--
ALTER TABLE `fs_ticket_closed`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_ticket_cust`
--
ALTER TABLE `fs_ticket_cust`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fs_ticket_state`
--
ALTER TABLE `fs_ticket_state`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `f_cust_subtype`
--
ALTER TABLE `f_cust_subtype`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `f_cust_type`
--
ALTER TABLE `f_cust_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `f_live`
--
ALTER TABLE `f_live`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landpage`
--
ALTER TABLE `landpage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landpage_block`
--
ALTER TABLE `landpage_block`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landpage_data`
--
ALTER TABLE `landpage_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landpage_photo`
--
ALTER TABLE `landpage_photo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `landpage_photo_cat`
--
ALTER TABLE `landpage_photo_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project`
--
ALTER TABLE `project`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_area`
--
ALTER TABLE `project_area`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_floor`
--
ALTER TABLE `project_floor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_floor_name`
--
ALTER TABLE `project_floor_name`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_price`
--
ALTER TABLE `project_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `project_unit`
--
ALTER TABLE `project_unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reservation`
--
ALTER TABLE `reservation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_ticket`
--
ALTER TABLE `sales_ticket`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sales_ticket_des`
--
ALTER TABLE `sales_ticket_des`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cust_id` (`cust_id`),
  ADD KEY `cat_id` (`cat_id`),
  ADD KEY `date_add` (`date_add`);

--
-- Indexes for table `sms_report`
--
ALTER TABLE `sms_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- Indexes for table `user_group`
--
ALTER TABLE `user_group`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_permission`
--
ALTER TABLE `user_permission`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_regulations`
--
ALTER TABLE `user_regulations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x_admin_lang_cat`
--
ALTER TABLE `x_admin_lang_cat`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x_admin_lang_var`
--
ALTER TABLE `x_admin_lang_var`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x_admin_menu`
--
ALTER TABLE `x_admin_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x_admin_menu_sub`
--
ALTER TABLE `x_admin_menu_sub`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `x_back_up`
--
ALTER TABLE `x_back_up`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `config`
--
ALTER TABLE `config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_cat`
--
ALTER TABLE `config_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `config_data`
--
ALTER TABLE `config_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=286;

--
-- AUTO_INCREMENT for table `config_meta`
--
ALTER TABLE `config_meta`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `config_photo`
--
ALTER TABLE `config_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=98;

--
-- AUTO_INCREMENT for table `customer_notes`
--
ALTER TABLE `customer_notes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer_sub`
--
ALTER TABLE `customer_sub`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cust_ticket`
--
ALTER TABLE `cust_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `cust_ticket_des`
--
ALTER TABLE `cust_ticket_des`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `c_leads`
--
ALTER TABLE `c_leads`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `facebook_data`
--
ALTER TABLE `facebook_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fi_city`
--
ALTER TABLE `fi_city`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `fi_country`
--
ALTER TABLE `fi_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=241;

--
-- AUTO_INCREMENT for table `fs_lead_sours`
--
ALTER TABLE `fs_lead_sours`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fs_lead_type`
--
ALTER TABLE `fs_lead_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fs_report_chart`
--
ALTER TABLE `fs_report_chart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `fs_ticket_closed`
--
ALTER TABLE `fs_ticket_closed`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fs_ticket_cust`
--
ALTER TABLE `fs_ticket_cust`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fs_ticket_state`
--
ALTER TABLE `fs_ticket_state`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `f_cust_subtype`
--
ALTER TABLE `f_cust_subtype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `f_cust_type`
--
ALTER TABLE `f_cust_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `f_live`
--
ALTER TABLE `f_live`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `landpage`
--
ALTER TABLE `landpage`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `landpage_block`
--
ALTER TABLE `landpage_block`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `landpage_data`
--
ALTER TABLE `landpage_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `landpage_photo`
--
ALTER TABLE `landpage_photo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `landpage_photo_cat`
--
ALTER TABLE `landpage_photo_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project`
--
ALTER TABLE `project`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_area`
--
ALTER TABLE `project_area`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_floor`
--
ALTER TABLE `project_floor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_floor_name`
--
ALTER TABLE `project_floor_name`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_price`
--
ALTER TABLE `project_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `project_unit`
--
ALTER TABLE `project_unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reservation`
--
ALTER TABLE `reservation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sales_ticket`
--
ALTER TABLE `sales_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;

--
-- AUTO_INCREMENT for table `sales_ticket_des`
--
ALTER TABLE `sales_ticket_des`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=441;

--
-- AUTO_INCREMENT for table `sms_report`
--
ALTER TABLE `sms_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user_group`
--
ALTER TABLE `user_group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_permission`
--
ALTER TABLE `user_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `user_regulations`
--
ALTER TABLE `user_regulations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `x_admin_lang_cat`
--
ALTER TABLE `x_admin_lang_cat`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `x_admin_lang_var`
--
ALTER TABLE `x_admin_lang_var`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1348;

--
-- AUTO_INCREMENT for table `x_admin_menu`
--
ALTER TABLE `x_admin_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `x_admin_menu_sub`
--
ALTER TABLE `x_admin_menu_sub`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=139;

--
-- AUTO_INCREMENT for table `x_back_up`
--
ALTER TABLE `x_back_up`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
